﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class charDetailsDisp : MonoBehaviour {
    public GameObject plObj;
    public GameObject[] ValueDisplayObjects;

	// Use this for initialization
	void Start () {
        plObj = GameObject.Find("Player_Object");
        ValueDisplayObjects[0].GetComponent<Text>().text = plObj.GetComponent<player_stats>().myActiveProfile.UserName;
        ValueDisplayObjects[1].GetComponent<Text>().text = plObj.GetComponent<player_stats>().myActiveProfile.Level.ToString();
        ValueDisplayObjects[2].GetComponent<Text>().text = plObj.GetComponent<player_stats>().myActiveProfile.Experience.ToString();
        ValueDisplayObjects[3].GetComponent<Text>().text = plObj.GetComponent<player_stats>().myActiveProfile.PlayerStats[0].ToString();
        ValueDisplayObjects[4].GetComponent<Text>().text = plObj.GetComponent<player_stats>().myActiveProfile.PlayerStats[1].ToString();
        ValueDisplayObjects[5].GetComponent<Text>().text = plObj.GetComponent<player_stats>().myActiveProfile.PlayerStats[2].ToString();
        ValueDisplayObjects[6].GetComponent<Text>().text = plObj.GetComponent<player_stats>().myActiveProfile.PlayerStats[3].ToString();
        ValueDisplayObjects[7].GetComponent<Text>().text = plObj.GetComponent<player_stats>().myActiveProfile.PlayerStats[4].ToString();
        ValueDisplayObjects[8].GetComponent<Text>().text = plObj.GetComponent<player_stats>().myActiveProfile.PlayerStats[5].ToString();
        ValueDisplayObjects[9].GetComponent<Text>().text = plObj.GetComponent<player_stats>().myActiveProfile.PlayerStats[6].ToString();
        ValueDisplayObjects[10].GetComponent<Text>().text = plObj.GetComponent<player_stats>().GetHPValues();
        ValueDisplayObjects[11].GetComponent<Text>().text = plObj.GetComponent<player_stats>().GetWPValues();
    }

    private void Awake()
    {
    }

    void OnEnable()
    {
        ValueDisplayObjects[0].GetComponent<Text>().text = plObj.GetComponent<player_stats>().myActiveProfile.UserName;
        ValueDisplayObjects[1].GetComponent<Text>().text = plObj.GetComponent<player_stats>().myActiveProfile.Level.ToString();
        ValueDisplayObjects[2].GetComponent<Text>().text = plObj.GetComponent<player_stats>().myActiveProfile.Experience.ToString();
        ValueDisplayObjects[3].GetComponent<Text>().text = plObj.GetComponent<player_stats>().myActiveProfile.PlayerStats[0].ToString();
        ValueDisplayObjects[4].GetComponent<Text>().text = plObj.GetComponent<player_stats>().myActiveProfile.PlayerStats[1].ToString();
        ValueDisplayObjects[5].GetComponent<Text>().text = plObj.GetComponent<player_stats>().myActiveProfile.PlayerStats[2].ToString();
        ValueDisplayObjects[6].GetComponent<Text>().text = plObj.GetComponent<player_stats>().myActiveProfile.PlayerStats[3].ToString();
        ValueDisplayObjects[7].GetComponent<Text>().text = plObj.GetComponent<player_stats>().myActiveProfile.PlayerStats[4].ToString();
        ValueDisplayObjects[8].GetComponent<Text>().text = plObj.GetComponent<player_stats>().myActiveProfile.PlayerStats[5].ToString();
        ValueDisplayObjects[9].GetComponent<Text>().text = plObj.GetComponent<player_stats>().myActiveProfile.PlayerStats[6].ToString();
        ValueDisplayObjects[10].GetComponent<Text>().text = plObj.GetComponent<player_stats>().GetHPValues();
        ValueDisplayObjects[11].GetComponent<Text>().text = plObj.GetComponent<player_stats>().GetWPValues();
    }



	// Update is called once per frame
	void Update () {
        if (GameObject.Find("Player_Object").GetComponent<player_stats>().myanim.GetBool("GamePlayActive") && transform.gameObject.activeInHierarchy)
            gameObject.SetActive(false);
    }
}
