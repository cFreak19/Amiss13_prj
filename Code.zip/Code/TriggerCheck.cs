﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
 

public class TriggerCheck : MonoBehaviour {
    public GameObject IncController;
    public string RequiredObjN;
    public int OrderInLine;
    private bool IsActive = false;

	// Use this for initialization
	void Start () {
		
	}

    private void OnTriggerEnter(Collider other)
    {
        if (other.transform.gameObject.name == RequiredObjN)
        {
            IsActive = true;
            IncController.GetComponent<StoryCheck>().SetActivity(IsActive, OrderInLine);
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.transform.gameObject.name == RequiredObjN)
        {
            IsActive = false;
            IncController.GetComponent<StoryCheck>().SetActivity(IsActive, OrderInLine);
        }
    }

	
	// Update is called once per frame
	void Update () {
		
	}
}
