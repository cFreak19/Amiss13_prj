﻿using UnityEngine;
using System.Collections;
using System;
using UnityEngine.UI;

public class WeaponUnlock : interactable {
    public int itemno;
    private GameObject plObj;
    public bool DestroyOnUse;

    public override void GetHit(int atck)
    {

    }

    public override void InfPrompt()
    {

    }

    // Use this for initialization
    void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
    public override void Use()
    {
        plObj.GetComponent<InvController>().AcquireWeapon(itemno);
        if (DestroyOnUse)
            Destroy(this.gameObject);
    }

    public override void InfDisplay(GameObject DispAnchor)
    {
        DispAnchor.GetComponent<Text>().text = GObjectName;
        //GUI.Label(new Rect(DispAnchor.x + 10, DispAnchor.y + 10, 640, 128), GObjectName);
    }
}
