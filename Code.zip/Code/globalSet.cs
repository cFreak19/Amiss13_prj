﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
 

public class globalSet : MonoBehaviour {

    public string GeneralShotdownString;
    public bool TriggerOn;


    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (TriggerOn)
        {
            TriggerOn = false;
            GameObject[] myobjects = GameObject.FindGameObjectsWithTag(GeneralShotdownString);
            for (int a = 0; a< myobjects.Length; a++)
            {
                if (myobjects[a].activeInHierarchy)
                    myobjects[a].SetActive(false);
                else
                    myobjects[a].SetActive(true);
            }
        }		
	}
}
