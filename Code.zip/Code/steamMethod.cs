﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Steamworks;
 
using System.Text;

public class SteamPrSpecs
{
    public ulong SteamIDlng;
    public int SteamChLevel, SteamChTotalSurplus, SteamChInfluencePt, SteamChExperience;
    public int[] SteamChRuneRanks = new int[13];
    public List<bool> GameSkinULs = new List<bool>();

    public void MakeFresh()
    {
        SteamChLevel = 0;
        SteamChTotalSurplus = 0;
        SteamChInfluencePt = 0;
        for ( int a = 0; a < SteamChRuneRanks.Length; a++)
        {
            SteamChRuneRanks[a] = 0;
        }
        SteamChRuneRanks[0] = 1;
        SteamChRuneRanks[4] = 1;
        SteamChRuneRanks[8] = 1;
        SteamChExperience = 0;
    }
}

public class steamMethod : MonoBehaviour
{
    private string steamUName = "";
    private CSteamID steamUID;
    private Texture2D customAvatar;
    private byte[] cloudSave = new byte[64];


    protected Callback<GameOverlayActivated_t> m_GameOverlayActivated;
    protected Callback<SteamAPICall_t> m_RequestUstat;
    protected CallResult<GSStatsReceived_t> m_ReceiveUstat = new CallResult<GSStatsReceived_t>();
    protected SteamAPICall_t m_ReadCloudSave;
    protected Callback<HTML_StartRequest_t> BrowserRequest;
    protected Callback<HTML_BrowserReady_t> BrowserReadyCb;
    protected Callback<HTML_JSAlert_t> BrowserJSAlert;
    protected Callback<HTML_JSConfirm_t> BrowserJSConf;
    protected Callback<HTML_FileOpenDialog_t> BrowserFileOP;
    protected Callback<ScreenshotReady_t> ScreenGrabbed;

    private EResult myUStats;

    public string GetSteamUN()
    {
        return steamUName;
    }
    void Start()
    {
        SteamScreenshots.HookScreenshots(false);
    }

    

    public Texture2D GetSmallSteamAvatar(CSteamID steamID)
    {
            int AvaNo = SteamFriends.GetSmallFriendAvatar(steamID);
            uint avaSnW, avaSnH;
            SteamUtils.GetImageSize(AvaNo, out avaSnW, out avaSnH);
            byte[] imagerawdata = new byte[avaSnW * avaSnH * 4];
            Debug.Log(avaSnW.ToString() + "  ::  " + avaSnH.ToString());
            Texture2D ReceivingImage = new Texture2D(int.Parse(avaSnW.ToString()), int.Parse(avaSnH.ToString()), TextureFormat.RGBA32, false);
            if (SteamUtils.GetImageRGBA(AvaNo, imagerawdata, 32 * 32 * 4 * sizeof(char)))
                ReceivingImage.LoadRawTextureData(imagerawdata);
            ReceivingImage.Apply();
            return ReceivingImage;
    }
    
    public Texture2D GetCachedAvatar()
    {
        return customAvatar;
    }
    public bool CheckForCloudSave()
    {
            return SteamRemoteStorage.FileExists(steamUName + "_online.save");
    }

    public void StoreOnCloud(UserProfile steamProfile)
    {
            if (CheckForCloudSave())
            {
                string SerializedGData = steamProfile.Level.ToString() + "," + steamProfile.SurplusPt.ToString() + "," + steamProfile.Experience + ",";
                for (int a = 0; a < steamProfile.RuneRanks.Length - 1; a++)
                {
                    SerializedGData += steamProfile.RuneRanks[a].ToString() + ",";
                }
                char[] myGCharacters = SerializedGData.ToCharArray();
                byte[] myGData = new byte[myGCharacters.Length];

                SteamRemoteStorage.FileWrite(steamUName + "_online.save", myGData, 64);
            }
    }

    public void WebsiteOnOverlay()
    {
            SteamFriends.ActivateGameOverlayToWebPage("http://www.sim-plistic.com/Amiss_13_theCurse/blog/");
    }

    string GetStrUntilComma(string Total, int startingIndex)
    {
            int theIndex = startingIndex;
            string theResult = "";
            while (Total[theIndex] != ',')
            {
                theResult += Total[theIndex];
                theIndex++;
            }
            return theResult;
    }

    public SteamPrSpecs LoadFromCloud()
    {
            if (SteamRemoteStorage.FileExists(steamUName + "_online.save"))
            {
                m_ReadCloudSave = SteamRemoteStorage.FileReadAsync(steamUName + "_online.save", 0, 64);
                if (SteamRemoteStorage.FileReadAsyncComplete(m_ReadCloudSave, cloudSave, 64))
                {
                    string OP = Encoding.UTF8.GetString(cloudSave);
                    int checkCursor = 0;
                    SteamPrSpecs output = new SteamPrSpecs();
                    string next;
                    next = GetStrUntilComma(OP, checkCursor);
                    output.SteamChLevel = int.Parse(next);
                    checkCursor += next.Length + 1;
                    next = GetStrUntilComma(OP, checkCursor);
                    output.SteamChTotalSurplus = int.Parse(next);
                    checkCursor += next.Length + 1;
                    for (int a = 0; a < 13; a++)
                    {
                        next = GetStrUntilComma(OP, checkCursor);
                        output.SteamChRuneRanks[a] = int.Parse(next);
                        checkCursor += next.Length + 1;
                    }
                    output.SteamChExperience = int.Parse(GetStrUntilComma(OP, checkCursor));
                    return output;
                }
                else
                    return new SteamPrSpecs();
            }
            else
            {
                Debug.Log("No cloud saves found.");
                return new SteamPrSpecs();
            }
    }

    public void UpAchiCount(string Achi_Argument)
    {
            float progress;
            SteamGameServerStats.GetUserStat(steamUID, Achi_Argument, out progress);
            SteamGameServerStats.SetUserStat(steamUID, Achi_Argument, progress++);
        }

        public string GetSUname()
        {
            return steamUName;
        }

        private void OnEnable()
        {
            if (SteamManager.Initialized)
            {
                m_GameOverlayActivated = Callback<GameOverlayActivated_t>.Create(OnGameOverlayActivated);
                //GetComponent<SteamNetwork>().StartOnlineInteraction(steamUID);
            }
    }

    private void ScreenShotReady(ScreenshotReady_t pCallback)
    {
        if (pCallback.m_eResult == EResult.k_EResultOK)
        {
            
        }
    }

    private void OnHtmlRequest(HTML_StartRequest_t pCallback)
    {
            SteamHTMLSurface.AllowStartRequest(pCallback.unBrowserHandle, true);
    }

    private void OnCloudRead(RemoteStorageFileReadAsyncComplete_t pCallback)
    {
            if (pCallback.m_eResult == EResult.k_EResultOK)
            {
                SteamRemoteStorage.FileReadAsyncComplete(pCallback.m_hFileReadAsync, cloudSave, pCallback.m_cubRead);
            }
            else
                Debug.Log("Cloud file request result: " + pCallback.m_eResult.ToString());
    }

    private void OnStatReceive(GSStatsReceived_t pCallback)
    {
            myUStats = pCallback.m_eResult;
        }

        private void OnNumberOfCurrentPlayers(NumberOfCurrentPlayers_t pCallback, bool bIOFailure)
        {
            if (pCallback.m_bSuccess != 1 || bIOFailure)
            {
                Debug.Log("There was an error retrieving the NumberOfCurrentPlayers.");
            }
            else
            {
                Debug.Log("The number of players playing your game: " + pCallback.m_cPlayers);
            }
    }

    private void Awake()
    {
            DontDestroyOnLoad(gameObject);
    }

    private void OnGameOverlayActivated(GameOverlayActivated_t pCallback)
    {
            if (pCallback.m_bActive != 0)
            {
                if (GameObject.Find("Player_Object"))
                {
                    GameObject.Find("Player_Object").GetComponent<Animator>().SetBool("GamePlayActive", false);
                }
            }
            else
            {
                if (GameObject.Find("Player_Object"))
                {
                    GameObject.Find("Player_Object").GetComponent<Animator>().SetBool("GamePlayActive", true);
                }
            }
    }

        void Update()
        {
            if (Input.GetButtonDown("ScreenGrab"))
            {
                SteamScreenshots.TriggerScreenshot();
            }
            if (GameObject.Find("titleInitiator") && (SteamManager.Initialized)&&(steamUName.Length < 1))
            {
                steamUID = SteamUser.GetSteamID();
                steamUName = SteamFriends.GetPersonaName();
                Debug.Log(steamUName);
                GetComponent<UProfiler>().LoadData();
                GameObject.Find("titleInitiator").GetComponent<GameMainMenu>().steamUN = steamUName;
                customAvatar = GetSmallSteamAvatar(steamUID);
                GameObject.Find("titleInitiator").GetComponent<GameMainMenu>().steamAvatar = customAvatar;
                GetComponent<WayBase>().steamAvatar = customAvatar;
                GameObject.Find("titleInitiator").GetComponent<GameMainMenu>().ConnectedCall();
            }
        }
    }