﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityStandardAssets.Characters.ThirdPerson;
using A13_theCurse_GameConst;

public class jVane_npc : automated
{
    [Header("BaseRequirements")]
    // stand, move, hit, get hit animations.
    public Animator mymodelAnimator;
    UnityEngine.AI.NavMeshAgent navmAgent;
    ThirdPersonCharacter character;
    public Transform target, player;
    public string preferredTarTagS = "";

    [Header("CombatSpecs")]
    public bool leaps, isAllied;
    public float observeRange, swingTime, jumpPower;
    public int healthMult, willMult;
    public float mMult = 0;
    public float SwingRange;
    public GameObject[] preferredTargets = new GameObject[1];


    [Header("Character Stats")]
    private stat[] npcstats = new stat[7];

    [Tooltip("Endurance/Strength/Alignment/Wisdom/Dexterity/Fortitude/Denial")]
    public int[] npc_statPerLv = new int[7];

    private bool IsOccupied, isWandering, isLeaping, isConstricting, isCharmed;
    private int currentWPtarget;

    public int ExistsInChP = 0;

    public GameObject[] ExtraGObj = new GameObject[1]; // 0: md smiley

    public GameObject[] WayPointObjects = new GameObject[1];

    public GameObject[] attackGFX = new GameObject[1];

    public GameObject projectilePrefab;

    public int criticalAnimationNumber;

    public AudioClip meleeSwing, faint, emoteVA, smash;

    public bool storyprogression = false;

    public bool taskIncrement = false;

    public GUIStyle myFsize;

    public void CritCamInit()
    {
        CancelInvoke("AttackRotation");
        IsOccupied = true;
        mymodelAnimator.SetBool("swinging", false);
        mymodelAnimator.SetBool("casting", false);
        GetComponent<CapsuleCollider>().enabled = false;
        transform.rotation = Quaternion.Euler((player.position - transform.position).normalized);
        mymodelAnimator.SetBool("struggle", true);
    }

    public override void Interact()
    {

    }

    public void CritCamResolve()
    {
        GetComponent<CapsuleCollider>().enabled = false;
        mymodelAnimator.SetBool("struggle", false);
        if (curHP > 0)
        {
            IsOccupied = false;
        }
    }

    public override void Init()
    {
        npcstats[0] = new stat();
        npcstats[0].statName = "Endurance";
        npcstats[0].statAmount = 12;
        npcstats[1] = new stat();
        npcstats[1].statName = "Strength";
        npcstats[1].statAmount = 12;
        npcstats[2] = new stat();
        npcstats[2].statName = "Alignment";
        npcstats[2].statAmount = 2;
        npcstats[3] = new stat();
        npcstats[3].statName = "Wisdom";
        npcstats[3].statAmount = 11;
        npcstats[4] = new stat();
        npcstats[4].statName = "Dexterity";
        npcstats[4].statAmount = 6;
        npcstats[5] = new stat();
        npcstats[5].statName = "Fortitude";
        npcstats[5].statAmount = 8;
        npcstats[6] = new stat();
        npcstats[6].statName = "Denial";
        npcstats[6].statAmount = 2;
        for (int a = 0; a < 7; a++)
        {
            npcstats[a].statAmount += npc_statPerLv[a] * level;
        }
        navmAgent = GetComponent<UnityEngine.AI.NavMeshAgent>();
        navmAgent.updateRotation = false;
        navmAgent.updatePosition = true;
        character = GetComponent<ThirdPersonCharacter>();
        maxHP = (npcstats[0].statAmount + npcstats[0].statBonus) * healthMult;
        maxWP = (npcstats[4].statAmount + npcstats[4].statBonus) * willMult;
        curHP = maxHP;
        maxWP = curWP;
        HRegen = Mathf.FloorToInt(float.Parse(npcstats[0].getTotalStat().ToString()) / 40); ;
        if (hasWP)
            WRegen = (npcstats[4].statAmount + npcstats[4].statBonus) / 40;
        IsOccupied = false;
        //player = GameObject.Find("Player_Object").transform;
        isConstricting = false;
        InvokeRepeating("EffectCheck", 1.5f, 1.5f);
        InvokeRepeating("Regenerate", 5f, 5f);
        mymodelAnimator.SetBool("IsActive", true);
    }

    void Regenerate()
    {
        curHP += HRegen;
        if (curHP > maxHP)
            curHP = maxHP;
        if (hasWP)
            curWP += WRegen;
        if (curWP > maxWP)
            curWP = maxWP;
    }

    void Start()
    {
            Init();
    }

    public override void GetHurt(int a)
    {
        IsOccupied = true;
        int incDmg = a;
        Debug.Log("Attempting " + incDmg.ToString() + " on " + NPCname);
        int modifiedD = Mathf.FloorToInt(float.Parse(incDmg.ToString()) * float.Parse(((100 - npcstats[5].statAmount) / 100).ToString()));
        curHP -= modifiedD; //check mitigation done by fortitude
        Debug.Log(NPCname + "received " + /*(incDmg * (100 - npcstats[5].statAmount) / 100).ToString()*/ modifiedD.ToString() + " physical damage.");
        if (curHP <= 0)
        {
            curHP = 0;
            Faint();
        }
        IsOccupied = false;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.transform.gameObject.GetComponent<spellContent>())
        {
            spellContent affectingSpell = other.transform.gameObject.GetComponent<spellContent>();
            affectingSpell.target = this.transform.gameObject;
            affectingSpell.Activate();
        }
    }
    public override void GetCast(Applied_Effect eff)
    {
        IsOccupied = true;
        curHP -= eff.GetDamage() * ((100 - npcstats[5].statAmount * 2) / 100);
        if ((hasWP) && (eff.mytype == GameConstants.EffectType.Burn))
        {
            curWP -= eff.GetDamage() * ((100 - npcstats[5].statAmount) / 50);
            CurrentlyApplying.Add(eff);
        }
        if (curHP <= 0)
        {
            curHP = 0;
            Faint();
        }
        if (eff.mytype == GameConstants.EffectType.Modify)
        {
            CurrentlyApplying.Add(eff);
        }
        IsOccupied = false;
    }

    public override void GetHurt(Applied_Effect eff)
    {
        curHP -= eff.GetDamage() * npcstats[5].statAmount / 100;
        if (curHP <= 0)
        {
            curHP = 0;
            Faint();
        }
    }

    void Faint()
    {
        if (faint != null)
        {
            GetComponent<AudioSource>().clip = faint;
            GetComponent<AudioSource>().Play();
        }
        CancelInvoke();
        mymodelAnimator.SetBool("IsActive", false);
        GetComponent<CapsuleCollider>().enabled = false;
        transform.Find("PoolEmitter").GetComponent<ParticleSystem>().Play();
        GameObject.FindGameObjectWithTag("Player").GetComponent<player_stats>().BattleOff();
        StartCoroutine(Disappear());
        AchiStatInc();
        GameObject.Find("Player_Object").GetComponent<InvController>().AcquireItem(GetComponent<Lootable>().PickAtRandom());
        if (taskIncrement)
        {
            GameObject.FindGameObjectWithTag("GameController").GetComponent<WayBase>().TaskIncrement(false);
        }
    }

    IEnumerator Disappear()
    {
        yield return new WaitForSeconds(25f);
        Destroy(gameObject);
    }

    void AttackRotation()
    {
        if (navmAgent.remainingDistance <= SwingRange)
        {
            if (curHP < maxHP * 40 / 100)
                StartCoroutine(Throw());
            else
                StartCoroutine(Punch());
        }
        else
                CancelInvoke("AttackRotation");
    }

    void Leap()
    {
        isLeaping = true;
        mymodelAnimator.SetBool("leaping", true);
        GetComponent<Rigidbody>().AddForce((transform.forward * 3 + new Vector3(0, jumpPower, 0)), ForceMode.Impulse);
        StartCoroutine(SwingFail());
    }

    IEnumerator SwingFail()
    {
        yield return new WaitForSeconds(1f);
        mymodelAnimator.SetBool("swinging", false);
    }

    IEnumerator Punch()
    {
        if (IsOccupied)
        {
            CancelInvoke("AttackRotation");
            StopCoroutine(Punch());
        }
        if (meleeSwing != null)
        {
            GetComponent<AudioSource>().clip = meleeSwing;
            GetComponent<AudioSource>().Play();
        }
            isLeaping = false;
        mymodelAnimator.SetInteger("attackN", 0);
            mymodelAnimator.SetBool("swinging", true);
            yield return new WaitForSeconds(0.1F);
            if ((navmAgent.remainingDistance < SwingRange) && (!IsOccupied))
            {
                 if (target.gameObject.GetComponent<simple_npc>())
                {
                    int atmptDamage = npcstats[1].getTotalStat() + npcstats[0].getTotalStat() / 10;
                    target.transform.gameObject.GetComponent<simple_npc>().GetHurt(atmptDamage);
                    if (target.gameObject.GetComponent<Rigidbody>())
                        target.gameObject.GetComponent<Rigidbody>().AddForce(transform.forward * 20 + new Vector3(0,5,0), ForceMode.Impulse);
                }
            }
            else
            {
                CancelInvoke("AttackRotation");
            }
            mymodelAnimator.SetBool("swinging", false);
        if (target.gameObject.GetComponent<simple_npc>().curHP <= 0)
            CancelInvoke("AttackRotation");
    }

    IEnumerator Smash()
    {
        if (IsOccupied)
            CancelInvoke("AttackRotation");
        if (meleeSwing != null)
        {
            GetComponent<AudioSource>().clip = smash;
            GetComponent<AudioSource>().Play();
        }
        isLeaping = false;
        mymodelAnimator.SetInteger("attackN", 1);
        mymodelAnimator.SetBool("swinging", true);
        yield return new WaitForSeconds(0.15F);
        if ((navmAgent.remainingDistance < SwingRange) && (!IsOccupied))
        {
           if (target.transform.gameObject.GetComponent<simple_npc>())
           {
               int atmptDamage = npcstats[1].getTotalStat() *3 + npcstats[0].statAmount / 10;
               target.transform.gameObject.GetComponent<simple_npc>().GetHurt(atmptDamage);
                if (target.gameObject.GetComponent<Rigidbody>())
                    target.gameObject.GetComponent<Rigidbody>().AddExplosionForce(20, target.position, 5, 5, ForceMode.Impulse);
           }
        }
        else
        {
            CancelInvoke("AttackRotation");
        }
        mymodelAnimator.SetBool("swinging", false);
        if (target.gameObject.GetComponent<simple_npc>().curHP <= 0)
            CancelInvoke("AttackRotation");
    }

    IEnumerator Throw()
    {
        if (IsOccupied)
            CancelInvoke("AttackRotation");
        isLeaping = false;
        mymodelAnimator.SetInteger("attackN", 1);
        mymodelAnimator.SetBool("swinging", true);
        yield return new WaitForSeconds(0.1F);
        if ((navmAgent.remainingDistance < SwingRange) && (!IsOccupied) && (!isCharmed))
        {
                int atmptDamage = (npcstats[1].statAmount + npcstats[1].statBonus) / 2 + npcstats[0].statAmount / 10;
                target.transform.gameObject.GetComponent<simple_npc>().GetHurt(atmptDamage);
                if (target.transform.gameObject.GetComponent<Rigidbody>())
                {
                    yield return new WaitForSeconds(0.1f);
                    target.transform.gameObject.GetComponent<Rigidbody>().AddForce(transform.forward * -8 + new Vector3(0, 15, 0), ForceMode.Impulse);
                }
        }
        else
        {
            CancelInvoke("AttackRotation");
            mymodelAnimator.SetBool("swinging", false);
            StopCoroutine(Throw());
        }
        mymodelAnimator.SetBool("swinging", false);
        if (target.gameObject.GetComponent<simple_npc>().curHP <= 0)
            CancelInvoke("AttackRotation");
    }

    void EffectCheck()
    {
        if (CurrentlyApplying.Count > 0)
        {
            for (int a = 0; a < CurrentlyApplying.Count; a++)
            {
                if ((CurrentlyApplying[a] != null) && (CurrentlyApplying[a].remTurns > 0))
                {
                    switch (CurrentlyApplying[a].mytype)
                    {
                        case GameConstants.EffectType.Burn:
                            GetHurt(CurrentlyApplying[a]);
                            break;
                        case GameConstants.EffectType.Curse:
                            npcstats[CurrentlyApplying[a].statSlot].statBonus = -1 * CurrentlyApplying[a].GetDamage() / 5;
                            break;
                        case GameConstants.EffectType.Daze:
                            mMult = CurrentlyApplying[a].GetDamage();
                            break;
                        case GameConstants.EffectType.Modify:
                            // Regenerate, Burn willpower etc.
                            break;
                        default:
                            break;
                    }
                    CurrentlyApplying[a].remTurns--;
                    if (CurrentlyApplying[a].remTurns <= 0)
                        CurrentlyApplying.RemoveAt(a);
                }
                else
                {
                    CurrentlyApplying.RemoveAt(a);
                }
            }
            StartCoroutine(Revert());
        }
    }

    IEnumerator Revert()
    {
        yield return new WaitForSeconds(1.5f);
        for (int a = 0; a < npcstats.Length; a++)
        {
            npcstats[a].statBonus = 0;
        }
        mMult = 0;
    }

    bool IsFacing()
    {
        if (Quaternion.Angle(transform.rotation, Quaternion.Euler(player.rotation.eulerAngles * -1)) < 30)
            return true;
        else
            return false;
    }

    int GetClosestPreferredTarget()
    {
        preferredTargets = GameObject.FindGameObjectsWithTag(preferredTarTagS);
        float closestDistance = observeRange;
        int closestNumber = -1;
        for (int a = 0; a < preferredTargets.Length; a++)
        {
            float thisDistance = Vector3.Distance(preferredTargets[a].transform.position, transform.position);
            if ((thisDistance < closestDistance)&&(preferredTargets[a].GetComponent<simple_npc>().curHP > 0))
            {
                closestDistance = thisDistance;
                closestNumber = a;
            }
        }
        return closestNumber;
    }

    void Update()
    {
        if (GetComponent<Rigidbody>().velocity.y == 0)
        {
            mymodelAnimator.SetBool("leaping", false);
        }
        if ((curHP > 0) && (!IsOccupied))
        {
            int closestOrder = GetClosestPreferredTarget();
            if (closestOrder != -1)
                target = preferredTargets[closestOrder].transform;
            else
            {
                target = transform;
                CancelInvoke("AttackRotation");
                mymodelAnimator.SetBool("swinging", false);
                player.gameObject.GetComponent<player_stats>().BattleOff();
            }

            if (Vector3.Distance(transform.position, target.position) < observeRange)
            {
                if ((leaps) && (!isLeaping) && (navmAgent.remainingDistance > navmAgent.stoppingDistance))
                {
                    isLeaping = true;
                    Leap();
                }
                else
                {
                    if (navmAgent.remainingDistance <= navmAgent.stoppingDistance)
                    {
                        mymodelAnimator.SetBool("OnTheMove", false);
                        if (isLeaping)
                        {
                            StartCoroutine(Smash());
                            isLeaping = false;
                        }
                        else if(!IsInvoking("AttackRotation"))
                            InvokeRepeating("AttackRotation", swingTime, swingTime);
                    }
                    else
                    {
                        if (!mymodelAnimator.GetBool("swinging"))
                        {
                            CancelInvoke("AttackRotation");
                            mymodelAnimator.SetBool("OnTheMove", true);
                        }
                    }
                }

                if (target != null)
                    navmAgent.SetDestination(target.position);
                else
                    navmAgent.SetDestination(gameObject.transform.position);

                if (navmAgent.remainingDistance > navmAgent.stoppingDistance)
                {
                    mymodelAnimator.SetBool("OnTheMove", true);
                    character.Move(navmAgent.desiredVelocity * (1 - mMult), false, false);
                }
                else
                {
                    character.Move(Vector3.zero, false, false);
                }
            }
            else if (GetClosestPreferredTarget() != -1)
            {
                int closestIndex = GetClosestPreferredTarget();
                target = preferredTargets[closestIndex].transform;

                if ((leaps) && (!isLeaping))
                {
                    isLeaping = true;
                    Leap();
                }
                else
                {

                    if (navmAgent.remainingDistance <= navmAgent.stoppingDistance)
                    {
                        mymodelAnimator.SetBool("OnTheMove", false);
                        if (isLeaping)
                        {
                            StartCoroutine(Smash());
                        }
                        else
                            InvokeRepeating("AttackRotation", swingTime, swingTime);
                    }
                    else
                    {
                        if (!mymodelAnimator.GetBool("swinging"))
                        {
                            CancelInvoke("AttackRotation");
                            mymodelAnimator.SetBool("OnTheMove", true);
                        }
                    }
                }

                if (target != null)
                    navmAgent.SetDestination(target.position);
                else
                    navmAgent.SetDestination(gameObject.transform.position);

                if (navmAgent.remainingDistance > navmAgent.stoppingDistance)
                {
                    mymodelAnimator.SetBool("OnTheMove", true);
                    character.Move(navmAgent.desiredVelocity * (1 - mMult), false, false);
                }
                else
                {
                    character.Move(Vector3.zero, false, false);
                }
            }

        }
    }



    void Roam()
    {
        if (isWandering)
        {
            navmAgent.SetDestination(WayPointObjects[UnityEngine.Random.Range(0, WayPointObjects.Length)].transform.position);
        }
    }

    
}
