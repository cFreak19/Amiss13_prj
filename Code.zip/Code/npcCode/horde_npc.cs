﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityStandardAssets.Characters.ThirdPerson;
using A13_theCurse_GameConst;

public class horde_npc : automated
{
    [Header("BaseRequirements")]
    // stand, move, hit, get hit animations.    
    UnityEngine.AI.NavMeshAgent navmAgent;
    ThirdPersonCharacter character;
    public Transform target, player;

    [Header("CombatSpecs")]
    public float observeRange, swingTime, jumpPower;
    public int healthMult, willMult;
    private float ConstCounter;

    [Header("Character Stats")]
    private stat[] npcstats = new stat[7];

    [Tooltip("Endurance/Strength/Alignment/Wisdom/Dexterity/Fortitude/Denial")]
    public int[] npc_statPerLv = new int[7];

    private int currentWPtarget;

    public GameObject[] ExtraGObj = new GameObject[1]; // 0: md smiley

    public GameObject[] WayPointObjects = new GameObject[1];

    public int criticalAnimationNumber;
    public AudioClip travelSound, faint, emoteVA;
    public bool taskIncrement = false;


    public override void Interact()
    {

    }

    public override void Init()
    {
        npcstats[0] = new stat();
        npcstats[0].statName = "Endurance";
        npcstats[0].statAmount = 10;
        npcstats[1] = new stat();
        npcstats[1].statName = "Strength";
        npcstats[1].statAmount = 6;
        npcstats[2] = new stat();
        npcstats[2].statName = "Alignment";
        npcstats[2].statAmount = 1;
        npcstats[3] = new stat();
        npcstats[3].statName = "Wisdom";
        npcstats[3].statAmount = 9;
        npcstats[4] = new stat();
        npcstats[4].statName = "Dexterity";
        npcstats[4].statAmount = 10;
        npcstats[5] = new stat();
        npcstats[5].statName = "Fortitude";
        npcstats[5].statAmount = 5;
        npcstats[6] = new stat();
        npcstats[6].statName = "Denial";
        npcstats[6].statAmount = 5;
        for (int a = 0; a < 7; a++)
        {
            npcstats[a].statAmount += npc_statPerLv[a] * level;
        }
        navmAgent = GetComponent<UnityEngine.AI.NavMeshAgent>();
        navmAgent.updateRotation = false;
        navmAgent.updatePosition = true;
        character = GetComponent<ThirdPersonCharacter>();
        maxHP = (npcstats[0].statAmount + npcstats[0].statBonus) * healthMult;
        maxWP = (npcstats[4].statAmount + npcstats[4].statBonus) * willMult;
        curHP = maxHP;
        maxWP = curWP;
        target = transform;

        InvokeRepeating("EffectCheck", 1.5f, 1.5f);
    }

    void Start()
    {
        Init();
    }

    public override void GetHurt(int a)
    {
        //immune
    }

    void OnTriggerEnter(Collider other)
    {
        //immune

    }
    public override void GetCast(Applied_Effect eff)
    {
        //immune
    }

    public override void GetHurt(Applied_Effect eff)
    {
        //immune
    }

    void Faint()
    {
        //immune
    }

    IEnumerator Disappear()
    {
        yield return new WaitForSeconds(40f);
    }

    void AttackRotation()
    {
        if (navmAgent.remainingDistance <= navmAgent.stoppingDistance)
        {
            StartCoroutine(Swing());
        }
        else
        {
            CancelInvoke("AttackRotation");
        }
    }

    void Leap()
    {
        //ishorde
    }

    IEnumerator SwingFail()
    {
        yield return new WaitForSeconds(1f);
        CancelInvoke();
    }

    private void Constrict()
    {
        //ishorde
    }

    IEnumerator Swing()
    {
        yield return new WaitForSeconds(0.5f);
        int atmptDamage = npcstats[1].getTotalStat() * level;
        player.gameObject.GetComponent<player_stats>().GetHurt(atmptDamage);
        Debug.Log(NPCname + ": attempting swing for " + atmptDamage.ToString());
    }

    void EffectCheck()
    {
        //immune
    }

    IEnumerator Revert()
    {
        yield return new WaitForSeconds(1.5f);
        for (int a = 0; a < npcstats.Length; a++)
        {
            npcstats[a].statBonus = 0;
        }

    }

    bool IsFacing()
    {
        if (Quaternion.Angle(transform.rotation, Quaternion.Euler(player.rotation.eulerAngles * -1)) < 30)
            return true;
        else
            return false;
    }

    void Update()
    {
        if (player.gameObject.GetComponent<player_stats>().myanim.GetBool("GamePlayActive"))
        {
            if (Vector3.Distance(target.position, player.position) < observeRange)
            {
                target = player;

                GameObject.Find("Player_Object").GetComponent<player_stats>().BattleOn();
                target = GameObject.Find("Player_Object").transform;
                if (navmAgent.remainingDistance <= navmAgent.stoppingDistance)
                {
                    InvokeRepeating("AttackRotation", swingTime, swingTime);
                }
                else
                {
                    CancelInvoke();
                }

                if (target != null)
                    navmAgent.SetDestination(target.position);
                else
                    navmAgent.SetDestination(gameObject.transform.position);

                if (navmAgent.remainingDistance > navmAgent.stoppingDistance)
                {
                    character.Move(navmAgent.desiredVelocity, false, false);
                }
                else
                {
                    character.Move(Vector3.zero, false, false);
                }
            }
            else
            {
                target = null;
            }

        }
    }





}
