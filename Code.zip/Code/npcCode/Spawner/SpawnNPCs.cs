﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnNPCs : MonoBehaviour {
    public GameObject[] npcPrefabs = new GameObject[1];
    public int npcLevel, spawnAmnt;
    public float SpawnRate;

    public Rect theXZspawnRect;
    public string AltTarTag = "";
    public bool ObserveMap;

    public GameObject PlayerObj;


    private GameObject[] spawned_npcs;


	// Use this for initialization
	void Start () {
        spawned_npcs = new GameObject[spawnAmnt];
        InvokeRepeating("SpawnAtmpt", SpawnRate, SpawnRate);
	}

	Vector3 getRandomPosInRect()
    {
        return new Vector3(UnityEngine.Random.Range(theXZspawnRect.x, theXZspawnRect.x + theXZspawnRect.width),0, UnityEngine.Random.Range(theXZspawnRect.y, theXZspawnRect.y + theXZspawnRect.height));
    }   
      

    void SpawnAtmpt()
    {
        for (int a = 0; a < spawnAmnt; a++)
        {
            if (spawned_npcs[a] == null)
            {
                spawned_npcs[a] = Instantiate(npcPrefabs[UnityEngine.Random.Range(0, npcPrefabs.Length)], transform.position + getRandomPosInRect(), Quaternion.identity) as GameObject;
                spawned_npcs[a].GetComponent<simple_npc>().level = npcLevel;
                spawned_npcs[a].GetComponent<simple_npc>().player = PlayerObj.transform;
                if (ObserveMap)
                    spawned_npcs[a].GetComponent<simple_npc>().observeRange = 250;
                if (AltTarTag.Length > 1)
                {
                    spawned_npcs[a].GetComponent<simple_npc>().preferredTarTagS = AltTarTag;
                }
                spawned_npcs[a].GetComponent<simple_npc>().Init();
            }
        }
    }

}
