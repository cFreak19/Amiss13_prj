﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.Characters.ThirdPerson;
using A13_theCurse_GameConst;
 

public class watcherNPC : automated {
    public Animator myanim;
    public float NoticeDist;
    UnityEngine.AI.NavMeshAgent navmAgent;
    ThirdPersonCharacter character;
    public Transform target, player;
    public float observeRange, swingTime;
    public GameObject plObj;
    private int fleeC;
    public float mMult;
    private bool flee = false;
    public stat[] npcstats = new stat[6];
    public GameObject[] bloodsplatterObjs = new GameObject[1];

    public override void Interact()
    {

    }

    public override void Init()
    {
        navmAgent = GetComponent<UnityEngine.AI.NavMeshAgent>();
        navmAgent.updateRotation = false;
        navmAgent.updatePosition = true;
        character = GetComponent<ThirdPersonCharacter>();
        maxHP = (npcstats[0].statAmount + npcstats[0].statBonus) * 3;
        curHP = maxHP;
        maxHP = (npcstats[4].statAmount + npcstats[4].statBonus) * 4;
        maxWP = curWP;
    }

    void Awake()
    {
        Init();
    }
    public override void GetHurt(Applied_Effect myeff)
    {

    }
    public override void GetCast(Applied_Effect eff)
    {
        curHP -= eff.GetDamage() * ((100 - npcstats[6].statAmount * 2) / 100);
        if ((hasWP) && (eff.mytype == GameConstants.EffectType.Modify))
        {
            curWP -= eff.GetDamage() * ((100 - npcstats[6].statAmount) / 50);
        }
        if (curHP <= 0)
        {
            curHP = 0;
        }
    }

    public override void GetHurt(int amount)
    {
        curHP -= amount * ((100 - npcstats[5].statAmount * 2) / 100);
        if (curHP <= 0)
        {
            curHP = 0;
        }

    }
    

    // Use this for initialization
    void Start () {
    }
	
    void Flee()
    {
        if (fleeC < 45)
        {
            fleeC++;
            transform.Rotate(0, 4, 0);
        }
        transform.position += transform.forward * 1.2f;
    }
	// Update is called once per frame
	void Update () {
		if (Vector3.Distance(plObj.transform.position,transform.position)< NoticeDist)
        {
            fleeC = 0;
            myanim.SetBool("OnTheMove", true);
            flee = false;
        }

        if ((myanim.GetBool("OnTheMove"))&&(Vector3.Distance(plObj.transform.position, transform.position) > NoticeDist))
        {
            if ((navmAgent.remainingDistance > navmAgent.stoppingDistance) && (navmAgent.remainingDistance > navmAgent.stoppingDistance))
            {
                character.Move(navmAgent.desiredVelocity * -1 * (1 - mMult), false, false);
                myanim.SetBool("OnTheMove", true);
            }
            else
            {
                character.Move(Vector3.zero, false, false);
            }
        }
	}
}
