﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class projectile : MonoBehaviour {
    public int RawDamageHeld;
    public GameObject meshObj, EffInstPrefab, AimGOBJ;
    public bool CastOut;
    public float ForceMagnitude;
    public Vector3 ForceVector, targetPos;
    public bool targeted = false;
    public bool isexplosive = false;
    public bool isTrigger = false;
    public bool disableOnC = false;

	void Start () {
		
	}
	
	void Update () {
        if (targeted && (targetPos != null))
        {
            if (Vector3.Distance(transform.position,targetPos) > 1.5f)
            {
                GetComponent<Rigidbody>().AddForce((targetPos - transform.position).normalized * ForceMagnitude, ForceMode.Impulse);
            }
        }
        if (CastOut)
            Destroy(gameObject);
	}

    void OnTriggerEnter(Collider other)
    {
        if (other.transform.gameObject.tag == "Player")
        {
            other.transform.gameObject.GetComponent<player_stats>().GetHurt(RawDamageHeld);
            meshObj.GetComponent<BoxCollider>().enabled = false;

        }

        if (isexplosive)
            GetComponent<Rigidbody>().AddExplosionForce(ForceMagnitude, transform.position, 6f);

        if (EffInstPrefab)
        {
            Instantiate(EffInstPrefab, transform.position, Quaternion.identity);
        }
        if (disableOnC)
            GetComponent<BoxCollider>().enabled = false;
        Destroy(AimGOBJ);
    }

    void OnCollisionEnter(Collision mycol)
    {
        if (mycol.transform.gameObject.tag == "Player")
        {
            mycol.transform.gameObject.GetComponent<player_stats>().GetHurt(RawDamageHeld);
            meshObj.GetComponent<BoxCollider>().enabled = false;

        }

        if (isexplosive)
            GetComponent<Rigidbody>().AddExplosionForce(ForceMagnitude,transform.position,6f);

        if (EffInstPrefab)
        {
            Instantiate(EffInstPrefab, transform.position, Quaternion.identity);
        }
        if (disableOnC)
            GetComponent<BoxCollider>().enabled = false;
        Destroy(AimGOBJ);
    }
}
