﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.Characters.ThirdPerson;
using A13_theCurse_GameConst;
 

public class simple_civilAI : automated {

    public Animator mymodelAnimator;
    UnityEngine.AI.NavMeshAgent navmAgent;
    ThirdPersonCharacter character;
    public Transform target, player;
    public stat[] npcstats = new stat[6];
    public GameObject[] bloodsplatterObjs = new GameObject[1];
    public GameObject[] WayPointObjects = new GameObject[4];
    private int targetSelection = 0;
    private bool wandering = false;

    public override void Init()
    {
        navmAgent = GetComponent<UnityEngine.AI.NavMeshAgent>();
        navmAgent.updateRotation = false;
        navmAgent.updatePosition = true;
        character = GetComponent<ThirdPersonCharacter>();
        maxHP = (npcstats[0].statAmount + npcstats[0].statBonus) * 3;
        curHP = maxHP;
        maxWP = curWP;
        if (wandering)
            navmAgent.SetDestination(WayPointObjects[0].transform.position);
    }

    public override void Interact()
    {

    }

    public override void GetHurt(int a)
    {
        curHP -= a * npcstats[4].statAmount / 100;
        for (int b = 0; b < bloodsplatterObjs.Length; b++)
        {
            bloodsplatterObjs[b].GetComponent<ParticleSystem>().Play();
        }
        if (curHP <= 0)
        {
            curHP = 0;
            //Faint();
        }
    }

    public override void GetCast(Applied_Effect eff)
    {
        curHP -= eff.GetDamage() * ((100 - npcstats[5].statAmount * 2) / 100);
        if ((hasWP) && (eff.mytype == GameConstants.EffectType.Modify))
        {
            curWP -= eff.GetDamage() * ((100 - npcstats[5].statAmount) / 50);
        }
        if (curHP <= 0)
        {
            curHP = 0;
        }
    }
    public override void GetHurt(Applied_Effect eff)
    {
        curHP -= eff.GetDamage() * npcstats[5].statAmount / 100;
        if (curHP <= 0)
        {
            curHP = 0;
            //Faint();
        }
    }
    // Use this for initialization
    void Start () {
		
	}
    void Awake()
    {
        Init();
    }

    // Update is called once per frame
    void Update () {
		if (wandering)
        {
            if (Vector3.Distance(transform.position, navmAgent.destination) <= 0.5f)
            {
                targetSelection++;
                targetSelection %= WayPointObjects.Length;
                navmAgent.SetDestination(WayPointObjects[targetSelection].transform.position);
                mymodelAnimator.SetBool("onTheMove", true);
            }
        }
	}
}
