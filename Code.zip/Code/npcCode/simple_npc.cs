﻿using System.Collections;
using UnityEngine;
using UnityStandardAssets.Characters.ThirdPerson;
using A13_theCurse_GameConst;
 

public class simple_npc : automated
{
    [Header("BaseRequirements")]
    // stand, move, hit, get hit animations.
    public Animator mymodelAnimator;
    UnityEngine.AI.NavMeshAgent navmAgent;
    ThirdPersonCharacter character;
    public Transform target, player;
    public string preferredTarTagS = "";

    [Header("CombatSpecs")]
    public bool isAsleep, isPassive, isMadnessDriven, attackMagical, constricts, leaps, separateCombatAnimations, canWanderAround;
    public float observeRange, swingTime, chargeSpeed, PinTime, jumpPower;
    public int healthMult, willMult;
    public float mMult = 0;
    public float SwingRange;
    private float ConstCounter;
    public GameObject pinLoc;
    public Applied_Effect[] spellsList = new Applied_Effect[1];
    public GameObject[] preferredTargets = new GameObject[1];
    public int[] attackAniObjects = new int[1];
    private GameObject BurnPcleParent;


    [Header("Character Stats")]
    private stat[] npcstats = new stat[7];

    [Tooltip("Endurance/Strength/Alignment/Wisdom/Dexterity/Fortitude/Denial")]
    public int[] npc_statPerLv = new int[7];

    private bool IsOccupied = false;
    private bool isWandering = false;
    private bool isLeaping = false;
    private bool isConstricting = false;
    private bool isCharmed = false;
    private int currentWPtarget;

    public int ExistsInChP = 0;

    public GameObject[] ExtraGObj = new GameObject[1]; // 0: md smiley

    public GameObject[] WayPointObjects = new GameObject[1];

    public GameObject[] attackGFX = new GameObject[1];

    public GameObject projectilePrefab;
    public GameObject Dazedparticles;

    public int criticalAnimationNumber;
    public AudioClip meleeSwing, faint, emoteVA;
    public bool storyprogression = false;
    public bool taskIncrement = false;
    public GUIStyle myFSize;

    public void CritCamInit()
    {
        if (player == null)
            player = GameObject.Find("Player_Object").transform;
        CancelInvoke("AttackRotation");
        player.gameObject.GetComponent<player_stats>().BattleOff();
        IsOccupied = true;
        mymodelAnimator.SetBool("swinging", false);
        mymodelAnimator.SetBool("casting", false);
        GetComponent<CapsuleCollider>().enabled = false;
        transform.rotation = Quaternion.Euler((player.position - transform.position).normalized);
        mymodelAnimator.SetBool("struggle", true);
    }

    public override void Interact()
    {

    }

    public void CritCamResolve()
    {
        GetComponent<CapsuleCollider>().enabled = false;
        mymodelAnimator.SetBool("struggle", false);
        if (curHP > 0)
        {
            IsOccupied = false;
        }
    }

    public override void Init()
    {
        npcstats[0] = new stat();
        npcstats[0].statName = "Endurance";
        npcstats[0].statAmount = 10;
        npcstats[1] = new stat();
        npcstats[1].statName = "Strength";
        npcstats[1].statAmount = 6;
        npcstats[2] = new stat();
        npcstats[2].statName = "Alignment";
        npcstats[2].statAmount = 1;
        npcstats[3] = new stat();
        npcstats[3].statName = "Wisdom";
        npcstats[3].statAmount = 9;
        npcstats[4] = new stat();
        npcstats[4].statName = "Dexterity";
        npcstats[4].statAmount = 10;
        npcstats[5] = new stat();
        npcstats[5].statName = "Fortitude";
        npcstats[5].statAmount = 5;
        npcstats[6] = new stat();
        npcstats[6].statName = "Denial";
        npcstats[6].statAmount = 5;

        for (int a = 0; a < killRew.Count; a++)
        {
            killRew[a].rewardedAmntorNumber *= level / 2;
        }
        for (int a = 0; a < 7; a++)
        {
            npcstats[a].statAmount += npc_statPerLv[a] * level;
        }
        navmAgent = GetComponent<UnityEngine.AI.NavMeshAgent>();
        navmAgent.updateRotation = false;
        navmAgent.updatePosition = true;
        character = GetComponent<ThirdPersonCharacter>();
        maxHP = (npcstats[0].statAmount + npcstats[0].statBonus) * healthMult;
        maxWP = (npcstats[4].statAmount + npcstats[4].statBonus) * willMult;
        curHP = maxHP;
        maxWP = curWP;
        HRegen = Mathf.FloorToInt(float.Parse(npcstats[0].getTotalStat().ToString()) / 40);
        if (hasWP)
            WRegen = (npcstats[4].statAmount + npcstats[4].statBonus) / 20;
        target = transform;
        IsOccupied = false;
        //player = GameObject.Find("Player_Object").transform;
        if (isMadnessDriven)
        {
            mymodelAnimator.SetBool("isMD", true);
            GetComponent<CapsuleCollider>().height = 3;
            GetComponent<CapsuleCollider>().center.Set(0, 1.95f, 0);
            navmAgent.height = 3;
            navmAgent.baseOffset = -0.5f;
        }
        isConstricting = false;
        InvokeRepeating("EffectCheck", 1.5f, 1.5f);
        InvokeRepeating("Regenerate", 10f, 10f);
        mymodelAnimator.SetBool("IsActive", true);
        for (int a = 0; a < spellsList.Length; a++)
        {
            spellsList[a].wisbonus = npcstats[3].statAmount + npcstats[3].statBonus;
        }
    }

    void Regenerate()
    {
        curHP += HRegen;
        if (curHP > maxHP)
            curHP = maxHP;
        if (hasWP)
            curWP += WRegen;
        if (curWP > maxWP)
            curWP = maxWP;
    }

    void Start()
    {
        if (gameObject.tag == "bleeds")
            BurnPcleParent = transform.Find("BurnParticles").gameObject;
        Init();
    }

    public void GetAmbushed()
    {
        float AngleDiff = Vector3.Angle(transform.forward,transform.position - player.position); //check if player is behind the npc
        if ((AngleDiff < 0)&&(isCharmed))
        {
            Faint();
        }
    }

    public override void GetHurt(int a)
    {
        IsOccupied = true;
        bool isLethalAttack = false;
        if ((isPassive) || (isCharmed))
        {
            CancelInvoke("Roam");
            isPassive = false;
            isWandering = false;
            isLethalAttack = true;
        }
        int incDmg = a;
        if (isLethalAttack)
            incDmg *= 5;
        int totalDealt = Mathf.FloorToInt(float.Parse(incDmg.ToString()) * float.Parse(((100 - npcstats[5].getTotalStat()) / 100f).ToString()));
        //player.gameObject.GetComponent<player_stats>().myActiveProfile.autosave.AddLogEntry("Player dealt " + totalDealt.ToString() + " on " + NPCname);
        curHP = curHP - totalDealt;
        if (curHP <= 0)
        {
            curHP = 0;
            Faint();
        }
        IsOccupied = false;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.transform.gameObject.GetComponent<spellContent>())
        {
            spellContent affectingSpell = other.transform.gameObject.GetComponent<spellContent>();
            affectingSpell.target = this.transform.gameObject;
            affectingSpell.Activate();
        }

    }

    public override void GetCast(Applied_Effect eff)
    {
        IsOccupied = true;

        //player.gameObject.GetComponent<player_stats>().myActiveProfile.autosave.AddLogEntry("Player cast " + eff.GetDamage().ToString() + " on " + NPCname);
        curHP -= eff.GetDamage() * ((100 - npcstats[5].statAmount * 2) / 100);
        if ((hasWP) && (eff.mytype == GameConstants.EffectType.Burn))
        {
            curWP -= eff.GetDamage() * ((100 - npcstats[5].statAmount) / 50);
            CurrentlyApplying.Add(eff);
        }
        if (curHP <= 0)
        {
            curHP = 0;
            Faint();
        }
        if (eff.mytype == GameConstants.EffectType.Modify)
        {
            CurrentlyApplying.Add(eff);
        }

        IsOccupied = false;
    }

    public override void GetHurt(Applied_Effect eff)
    {
        curHP -= eff.GetDamage() * npcstats[5].getTotalStat() / 100;
        //player.gameObject.GetComponent<player_stats>().myActiveProfile.autosave.AddLogEntry("Player cast " + eff.GetDamage().ToString() + " on " + NPCname);
        if (curHP <= 0)
        {
            curHP = 0;
            Faint();
        }
    }

    void Faint()
    {
        if (mymodelAnimator.GetBool("struggle"))
            CritCamResolve();
        CancelInvoke();
        if (faint != null)
        {
            GetComponent<AudioSource>().clip = faint;
            GetComponent<AudioSource>().Play();
        }
        mymodelAnimator.SetBool("IsActive", false);
        GetComponent<CapsuleCollider>().enabled = false;
        transform.Find("PoolEmitter").GetComponent<ParticleSystem>().Play();
        GameObject.FindGameObjectWithTag("Player").GetComponent<player_stats>().BattleOff();
        //player.gameObject.GetComponent<player_stats>().myActiveProfile.autosave.AddLogEntry("Player knocked out " + NPCname);
        StartCoroutine(Disappear());
        AchiStatInc();
        CancelInvoke();
        GameObject.Find("targetthingy").GetComponent<targetFocus>().RemoveHosTarget(transform);
        if (Vector3.Distance(player.position, transform.position) < observeRange)
        {
            GameObject.FindGameObjectWithTag("Player").GetComponent<InvController>().AcquireItem(GetComponent<Lootable>().PickAtRandom());
            for (int a = 0; a < killRew.Count; a++)
                player.gameObject.GetComponent<InvController>().GrantReward(killRew[a]);
        }
        string achiText = "";
        switch (type)
        {
            case GameConstants.CreatureType.Ancient:
                achiText = "kAncient";
                break;
            case GameConstants.CreatureType.Humanoid:
                achiText = "kHum";
                break;
            case GameConstants.CreatureType.Mystical:
                achiText = "kMystical";
                break;
            case GameConstants.CreatureType.Unknown:
                achiText = "kUKnown";
                break;
            case GameConstants.CreatureType.Wild:
                achiText = "kWild";
                break;
            default:
                break;
        }
        //GameObject.FindGameObjectWithTag("GameController").GetComponent<steamMethod>().UpAchiCount(achiText);
        if (taskIncrement)
        {
            GameObject.FindGameObjectWithTag("GameController").GetComponent<WayBase>().TaskIncrement(false);
        }
        GetComponent<CapsuleCollider>().enabled = false;
        GetComponent<Rigidbody>().velocity = Vector3.zero;
        navmAgent.enabled = false;
        GetComponent<ThirdPersonCharacter>().enabled = false;
        gameObject.GetComponent<simple_npc>().enabled = false;
    }

    IEnumerator Disappear()
    {
        yield return new WaitForSeconds(12f);
        GameObject.Find("targetthingy").GetComponent<targetFocus>().RemoveHosTarget(transform);
        Destroy(gameObject);
    }

    void AttackRotation()
    {
        if (!mymodelAnimator.GetBool("casting"))
        {
            if (navmAgent.remainingDistance <= navmAgent.stoppingDistance)
            {
                StartCoroutine(Swing());
            }
            else
            {
                CancelInvoke("AttackRotation");
                player.gameObject.GetComponent<player_stats>().BattleOff();
            }
        }
    }

    void Leap()
    {
        isLeaping = true;
        GetComponent<Rigidbody>().AddForce((transform.forward * 3 + new Vector3(0, jumpPower, 0)), ForceMode.Impulse);
        StartCoroutine(SwingFail());
    }

    IEnumerator SwingFail()
    {
        yield return new WaitForSeconds(1f);
        mymodelAnimator.SetBool("swinging", false);
    }

    private void Constrict()
    {
        isLeaping = false;
        if (ConstCounter > 0)
        {
            mymodelAnimator.SetBool("constriction", true);
            isConstricting = true;
            player.transform.position = pinLoc.transform.position;
            player.transform.gameObject.GetComponent<player_stats>().GetDazed();
            int damage = npcstats[1].getTotalStat() / 4;
            player.transform.gameObject.GetComponent<player_stats>().GetHurt(damage);
            ConstCounter -= 0.5f;
        }
        else
        {
            mymodelAnimator.SetBool("constriction", false);
            CancelInvoke("Constrict");
            isConstricting = false;
        }
    }

    void SpellRotation()
    {
        if ((GettheFirstSuitable() > -1) && (!mymodelAnimator.GetBool("swinging")))
        {
            if (navmAgent.remainingDistance < navmAgent.stoppingDistance)
                StartCoroutine(SpellCast());
            else
            {
                CancelInvoke("SpellRotation");
                player.gameObject.GetComponent<player_stats>().BattleOff();
            }
        }
    }

    int GettheFirstSuitable()//listed for priority
    {
        for (int a = 0; a < spellsList.Length; a++)
        {
            if ((curWP > spellsList[a].WCost) && (navmAgent.remainingDistance < spellsList[a].range))
            {
                return a;
            }
        }
        return -1;
    }

    IEnumerator SpellCast()
    {
        if (IsOccupied)
        {
            CancelInvoke("SpellRotation");
            player.gameObject.GetComponent<player_stats>().BattleOff();
        }
        if (meleeSwing != null)
        {
            GetComponent<AudioSource>().clip = meleeSwing;
            GetComponent<AudioSource>().Play();
        }
        isLeaping = false;
        mymodelAnimator.SetBool("casting", true);
        yield return new WaitForSeconds(0.5F);
        if ((navmAgent.remainingDistance < navmAgent.stoppingDistance) && (!IsOccupied))
        {
            if (target.gameObject.tag == "Player")
            {
                int spellN = GettheFirstSuitable();
                if (spellN == -1)
                {
                    int atmptDamage;
                    if (!attackMagical)
                        atmptDamage = npcstats[1].statAmount + npcstats[1].statBonus + npcstats[0].statAmount / 10;
                    else
                        atmptDamage = npcstats[3].getTotalStat();
                    GameObject myspell = Instantiate(projectilePrefab, transform.position + transform.forward, Quaternion.identity) as GameObject;
                    myspell.GetComponent<spellContent>().result = spellsList[spellN];
                    myspell.GetComponent<spellContent>().target = player.gameObject;
                    myspell.GetComponent<spellContent>().direction = target.position - transform.position - transform.forward;
                    curWP -= spellsList[spellN].WCost;
                }
                else
                {
                    player.gameObject.GetComponent<player_stats>().GetHurt(0);
                }
            }
        }
        else
        {
            CancelInvoke("SpellRotation");
            player.gameObject.GetComponent<player_stats>().BattleOff();
        }
        mymodelAnimator.SetBool("casting", false);
    }

    IEnumerator Swing()
    {

        if (IsOccupied)
            StopCoroutine(Swing());
        if (meleeSwing != null)
        {
            GetComponent<AudioSource>().clip = meleeSwing;
            GetComponent<AudioSource>().Play();
        }
        if (!constricts)
        {
            isLeaping = false;
            mymodelAnimator.SetBool("swinging", true);
            yield return new WaitForSeconds(0.3F);
            if ((navmAgent.remainingDistance < navmAgent.stoppingDistance) && (!IsOccupied) && (!isCharmed))
            {
                int atmptDamage;
                if (!attackMagical)
                    atmptDamage = npcstats[1].getTotalStat() + npcstats[0].statAmount / 10;
                else
                {
                    atmptDamage = npcstats[3].getTotalStat();
                    if (attackAniObjects.Length > 0)
                    {
                        for (int a = 0; a < attackAniObjects.Length; a++)
                        {
                            ExtraGObj[attackAniObjects[a]].GetComponent<ParticleSystem>().Play();
                        }
                    }
                }
                Debug.Log(NPCname + ": attempting swing for " + atmptDamage.ToString());
                if ((target.gameObject.tag == "Player") && (IsFacing()))
                {
                    player.gameObject.GetComponent<player_stats>().GetHurt(atmptDamage);
                }
                else if (target.gameObject.GetComponent<automated>())
                {

                    target.gameObject.GetComponent<automated>().GetHurt(atmptDamage);
                }
                else if (target.gameObject.GetComponent<jVane_npc>())
                {
                    target.gameObject.GetComponent<jVane_npc>().GetHurt(atmptDamage);
                }
            }
            else
            {
                CancelInvoke("AttackRotation");
                player.gameObject.GetComponent<player_stats>().BattleOff();
            }
            mymodelAnimator.SetBool("swinging", false);
        }

    }




    void EffectCheck()
    {
        if (isCharmed)
            isCharmed = false;
        if (CurrentlyApplying.Count > 0)
        {
            for (int a = 0; a < CurrentlyApplying.Count; a++)
            {
                if ((CurrentlyApplying[a] != null) && (CurrentlyApplying[a].remTurns > 0))
                {
                    switch (CurrentlyApplying[a].mytype)
                    {
                        case GameConstants.EffectType.Burn:
                            BurnPcleParent.transform.Find("Sparks").gameObject.SetActive(false);
                            BurnPcleParent.transform.Find("Sparks").gameObject.SetActive(true);
                            BurnPcleParent.transform.Find("Sparks").gameObject.GetComponent<ParticleSystem>().Play();
                            GetHurt(CurrentlyApplying[a]);
                            break;
                        case GameConstants.EffectType.Curse:
                            npcstats[CurrentlyApplying[a].statSlot].statBonus = -1 * CurrentlyApplying[a].GetDamage() / 5;
                            BurnPcleParent.transform.Find("Empower").gameObject.SetActive(false);
                            BurnPcleParent.transform.Find("Empower").gameObject.SetActive(true);
                            BurnPcleParent.transform.Find("Empower").gameObject.GetComponent<ParticleSystem>().Play();
                            break;
                        case GameConstants.EffectType.Daze:
                            BurnPcleParent.transform.Find("ShockingStatic").gameObject.SetActive(false);
                            BurnPcleParent.transform.Find("ShockingStatic").gameObject.SetActive(true);
                            BurnPcleParent.transform.Find("ShockingStatic").gameObject.GetComponent<ParticleSystem>().Play();
                            mMult = CurrentlyApplying[a].GetDamage();
                            Dazedparticles.SetActive(true);
                            break;
                        case GameConstants.EffectType.Modify:
                            // Regenerate, Burn willpower etc.
                            break;
                        default:
                            break;
                    }
                    CurrentlyApplying[a].remTurns--;
                    if (CurrentlyApplying[a].remTurns <= 0)
                        CurrentlyApplying.RemoveAt(a);
                }
                else
                {
                    CurrentlyApplying.RemoveAt(a);
                }
            }
            StartCoroutine(Revert());
        }
    }

    IEnumerator Revert()
    {
        yield return new WaitForSeconds(1.5f);
        for (int a = 0; a < npcstats.Length; a++)
        {
            npcstats[a].statBonus = 0;
        }
        mMult = 0;
        Dazedparticles.SetActive(false);
    }

    bool IsFacing()
    {
        if (Quaternion.Angle(transform.rotation, Quaternion.Euler(player.rotation.eulerAngles * -1)) < 30)
            return true;
        else
            return false;
    }

    int GetClosestPreferredTarget()
    {
        if (preferredTarTagS.Length > 0)
            preferredTargets = GameObject.FindGameObjectsWithTag(preferredTarTagS);
        else
            return -1;
        float closestDistance = observeRange;
        int closestNumber = -1;
        for (int a = 0; a < preferredTargets.Length; a++)
        {
            float thisDistance = Vector3.Distance(preferredTargets[a].transform.position, transform.position);
            bool isAlive = false;
            if (preferredTargets[a].GetComponent<simple_npc>())
            {
                if (preferredTargets[a].GetComponent<simple_npc>().curHP > 0)
                    isAlive = true;
            }
            else if (preferredTargets[a].GetComponent<jVane_npc>())
            {
                if (preferredTargets[a].GetComponent<jVane_npc>().curHP > 0)
                    isAlive = true;
            }
            if ((thisDistance < closestDistance) && (isAlive))
            {
                closestDistance = thisDistance;
                closestNumber = a;
            }
        }
        return closestNumber;
    }

    void Update()
    {
        if ((curHP > 0) && (!IsOccupied) && (!isAsleep) && (!isPassive) && (!isConstricting))
        {
            if ((Vector3.Distance(transform.position, player.position) > observeRange) && (target == null || target == transform))
            {
                int closestOrder = GetClosestPreferredTarget();
                if (closestOrder != -1)
                    target = preferredTargets[closestOrder].transform;
                else
                {
                    target = null;
                    CancelInvoke("AttackRotation");
                    if (mymodelAnimator.GetBool("swinging"))
                    {
                        mymodelAnimator.SetBool("swinging", false);
                        player.gameObject.GetComponent<player_stats>().BattleOff();
                    }
                }
            }
            else if (target != player)
            {
                target = player;
            }


            if (target != null)
            {
                if (Vector3.Distance(transform.position, target.position) < observeRange)
                {
                    navmAgent.SetDestination(target.position);
                    if (target == player)
                        GameObject.Find("Player_Object").GetComponent<player_stats>().BattleOn();
                    if ((leaps) && (!isLeaping))
                    {
                        isLeaping = true;
                        Leap();
                    }
                    else
                    {
                        if (separateCombatAnimations)
                        {
                            if (!mymodelAnimator.GetBool("InCombat"))
                                mymodelAnimator.SetBool("InCombat", true);
                        }
                        if (navmAgent.remainingDistance <= navmAgent.stoppingDistance)
                        {
                            mymodelAnimator.SetBool("OnTheMove", false);
                            if (isLeaping && constricts)
                            {
                                isConstricting = true;
                                ConstCounter = PinTime;
                                InvokeRepeating("Constrict", 0.5f, 0.5f);
                            }
                            else if (!IsInvoking("AttackRotation"))
                                InvokeRepeating("AttackRotation", swingTime, swingTime);
                        }
                    }
                }
                else
                {
                    if (!mymodelAnimator.GetBool("swinging"))
                    {
                        CancelInvoke("AttackRotation");
                        player.gameObject.GetComponent<player_stats>().BattleOff();
                        mymodelAnimator.SetBool("OnTheMove", true);
                    }
                    if ((curHP > 0) && (player.gameObject.GetComponent<player_stats>().myanim.GetBool("GamePlayActive")) && (!IsOccupied) && ((isAsleep) || (isPassive)))
                    {
                        if (isAsleep)
                        {

                        }
                        else if (isPassive)
                        {
                            if (canWanderAround)//roam
                            {
                                if (navmAgent.remainingDistance < 2)
                                {
                                    isWandering = true;
                                    Roam();
                                }
                                else
                                {
                                    if ((navmAgent.remainingDistance > navmAgent.stoppingDistance) && (isWandering))
                                    {
                                        mymodelAnimator.SetBool("OnTheMove", true);
                                        character.Move(navmAgent.desiredVelocity * (1 - mMult), false, false);
                                    }
                                    else
                                    {
                                        mymodelAnimator.SetBool("OnTheMove", false);
                                        character.Move(Vector3.zero, false, false);
                                    }
                                }
                            }
                        }
                    }
                    if (curHP > 0)
                    {
                        if (navmAgent.remainingDistance > navmAgent.stoppingDistance)
                        {
                            mymodelAnimator.SetBool("OnTheMove", true);
                            character.Move(navmAgent.desiredVelocity * (1 - mMult), false, false);
                        }
                        else
                        {
                            character.Move(Vector3.zero, false, false);
                        }
                    }

                }
            }
            //if ((GetClosestPreferredTarget() != -1) && (Vector3.Distance(transform.position, player.position) > observeRange))
            //{
            //    int closestIndex = GetClosestPreferredTarget();
            //    target = preferredTargets[closestIndex].transform;

            //    if ((leaps) && (!isLeaping))
            //    {
            //        isLeaping = true;
            //        Leap();
            //    }
            //    else
            //    {
            //        if ((separateCombatAnimations) && (!mymodelAnimator.GetBool("InCombat")))
            //        {
            //            mymodelAnimator.SetBool("InCombat", true);
            //        }

            //        if (navmAgent.remainingDistance <= navmAgent.stoppingDistance)
            //        {
            //            mymodelAnimator.SetBool("OnTheMove", false);
            //            if (isLeaping && constricts)
            //            {
            //                isConstricting = true;
            //                ConstCounter = PinTime;
            //                InvokeRepeating("Constrict", 0.5f, 0.5f);
            //            }
            //            else if (!IsInvoking("AttackRotation"))
            //            {
            //                InvokeRepeating("AttackRotation", swingTime, swingTime);
            //                if ((isMadnessDriven) && (emoteVA != null) && (ExtraGObj[0] != null))
            //                {
            //                    mymodelAnimator.SetBool("animating", true);
            //                    ExtraGObj[0].GetComponent<gate>().GameplayTrigger();
            //                    GetComponent<AudioSource>().clip = emoteVA;
            //                    GetComponent<AudioSource>().Play();
            //                    mymodelAnimator.SetBool("animating", false);
            //                    ExtraGObj[0].GetComponent<gate>().GameplayTrigger();
            //                }
            //            }
            //        }
            //        else
            //        {
            //            if (mymodelAnimator.GetBool("swinging"))
            //            {
            //                CancelInvoke("AttackRotation");
            //                player.gameObject.GetComponent<player_stats>().BattleOff();
            //                mymodelAnimator.SetBool("OnTheMove", true);
            //            }
            //        }
            //    }

            //    if (target != null)
            //        navmAgent.SetDestination(target.position);
            //    else
            //        navmAgent.SetDestination(gameObject.transform.position);


            //    //else
            //    //{
            //    //    character.Move(Vector3.zero, false, false);
            //    //}
            //}
        }
    }



    void Roam()
    {
        if (isWandering)
        {
            navmAgent.SetDestination(WayPointObjects[UnityEngine.Random.Range(0, WayPointObjects.Length)].transform.position);
        }
    }

    //void OnGUI()
    //{
    //        if (Vector3.Distance(player.position,transform.position)< observeRange)
    //        {

    //        Vector2 targetFramePos = Camera.main.WorldToScreenPoint(transform.position);
    //    	GUI.DrawTexture(new Rect(targetFramePos.x, Screen.height - targetFramePos.y - 160, 204, 70), frameText);
    //    	GUI.DrawTexture(new Rect(targetFramePos.x + 40, Screen.height - targetFramePos.y - 130, 90 * float.Parse(curHP.ToString()) / float.Parse(maxHP.ToString()), 6), hbart);
    //    	GUI.Label(new Rect(targetFramePos.x, Screen.height - targetFramePos.y - 140, 110, 24), curHP.ToString() + "/" + maxHP.ToString(), myFSize);
    //    	}
    //}
}
