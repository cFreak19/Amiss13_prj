﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityStandardAssets.Characters.ThirdPerson;
using A13_theCurse_GameConst;

public class amy_npc : automated
{
    [Header("BaseRequirements")]
    // stand, move, hit, get hit animations.
    public Animator mymodelAnimator;
    UnityEngine.AI.NavMeshAgent navmAgent;
    ThirdPersonCharacter character;
    public Transform target, player;

    [Header("CombatSpecs")]
    public bool canCharm, isFleeing;
    public float observeRange, swingTime;
    public int healthMult, willMult;
    public float mMult;
    private float ConstCounter;
    public GameObject pinLoc;

    [Header("Character Stats")]
    private stat[] npcstats = new stat[7];

    [Tooltip("Endurance/Strength/Alignment/Wisdom/Dexterity/Fortitude/Denial")]
    public int[] npc_statPerLv = new int[7];

    private bool IsOccupied;
    
    public GameObject[] ExtraGObj = new GameObject[1]; // 0: mask back, 1: mask front

    public GameObject[] WayPointObjects = new GameObject[1];
    private int waypointCounter = 0;

    public float MaxAllowedDistance, distanceToAdvanceNext;


    public int criticalAnimationNumber;
    
    public AudioClip meleeSwing, faint, emoteVA;

    


    public override void Interact()
    {
        //charm nearest pack
    }

    public void CritCamResolve()
    {
        GetComponent<CapsuleCollider>().enabled = false;
        mymodelAnimator.SetBool("struggle", false);
        if (curHP > 0)
        {
            IsOccupied = false;
        }
    }

    public override void Init()
    {
        npcstats[0] = new stat();
        npcstats[0].statName = "Endurance";
        npcstats[0].statAmount = 10;
        npcstats[1] = new stat();
        npcstats[1].statName = "Strength";
        npcstats[1].statAmount = 4;
        npcstats[2] = new stat();
        npcstats[2].statName = "Alignment";
        npcstats[2].statAmount = 1;
        npcstats[3] = new stat();
        npcstats[3].statName = "Wisdom";
        npcstats[3].statAmount = 8;
        npcstats[4] = new stat();
        npcstats[4].statName = "Dexterity";
        npcstats[4].statAmount = 10;
        npcstats[5] = new stat();
        npcstats[5].statName = "Fortitude";
        npcstats[5].statAmount = 5;
        npcstats[6] = new stat();
        npcstats[6].statName = "Denial";
        npcstats[6].statAmount = 5;
        for (int a = 0; a < 7; a++)
        {
            npcstats[a].statAmount += npc_statPerLv[a] * level;
        }
        navmAgent = GetComponent<UnityEngine.AI.NavMeshAgent>();
        navmAgent.updateRotation = false;
        navmAgent.updatePosition = true;
        character = GetComponent<ThirdPersonCharacter>();
        maxHP = (npcstats[0].statAmount + npcstats[0].statBonus) * healthMult;
        maxWP = (npcstats[4].statAmount + npcstats[4].statBonus) * willMult;
        curHP = maxHP;
        maxWP = curWP;
        target = transform;
        IsOccupied = false;
        //player = GameObject.Find("Player_Object").transform;
        InvokeRepeating("EffectCheck", 1.5f, 1.5f);
        mymodelAnimator.SetBool("IsActive", true);
    }

    void Start()
    {
        Init();
    }

    public override void  GetHurt(int a)
    {
        IsOccupied = true;

        int incDmg = a;
        
        curHP -= incDmg * ((100-npcstats[5].statAmount) / 100); //check mitigation done by fortitude
        Debug.Log(NPCname + "received " + (incDmg * ((100 - npcstats[5].statAmount) / 100)).ToString() + " physical damage.");
        
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.transform.gameObject.GetComponent<spellContent>())
        {
            spellContent affectingSpell = other.transform.gameObject.GetComponent<spellContent>();
            affectingSpell.target = this.transform.gameObject;
            affectingSpell.Activate();
        }
        
    }
    public override void GetCast(Applied_Effect eff)
    {

    }

    public override void GetHurt(Applied_Effect eff)
    {
        curHP -= eff.GetDamage() * npcstats[5].statAmount / 100;
        if (curHP <= 0)
        {
            curHP = 0;
            Faint();
        }
    }

    void Faint()
    {
        if (faint != null)
        {
            GetComponent<AudioSource>().clip = faint;
            GetComponent<AudioSource>().Play();
        }
        mymodelAnimator.SetBool("IsActive", false);
        
    }

    IEnumerator Disappear()
    {
        yield return new WaitForSeconds(40f);
    }

    void AttackRotation()
    {
        if (navmAgent.remainingDistance <= navmAgent.stoppingDistance)
        {
            StartCoroutine(Swing());
        }
        else
        {
            CancelInvoke("AttackRotation");
        }
    }

 

    IEnumerator SwingFail ()
    {
        yield return new WaitForSeconds(1f);
        mymodelAnimator.SetBool("swinging", false);
    }

   

    IEnumerator Swing()
    {
        if (IsOccupied)
            CancelInvoke("AttackRotation");
        if (meleeSwing != null)
        {
            GetComponent<AudioSource>().clip = meleeSwing;
            GetComponent<AudioSource>().Play();
        }
            mymodelAnimator.SetBool("swinging", true);
            yield return new WaitForSeconds(0.5F);
            if ((navmAgent.remainingDistance < navmAgent.stoppingDistance) && (!IsOccupied))
            {
                RaycastHit mytarget;
                if (Physics.Raycast(transform.position + new Vector3(0, 2, 0), transform.forward, out mytarget, navmAgent.stoppingDistance + 4))
                {
                    if ((mytarget.transform.gameObject.tag == "Player") && (IsFacing()))
                    {
                        int atmptDamage;
                            atmptDamage = npcstats[1].statAmount + npcstats[1].statBonus + npcstats[0].statAmount / 10;
                        player.gameObject.GetComponent<player_stats>().GetHurt(atmptDamage);
                        Debug.Log(NPCname + ": attempting swing for " + atmptDamage.ToString());
                    }
                }
            }
            else
            {
                CancelInvoke("AttackRotation");
            }
            mymodelAnimator.SetBool("swinging", false); 
    }

    void EffectCheck()
    {
        if (CurrentlyApplying.Count > 0)
        {
            for (int a = 0; a < CurrentlyApplying.Count; a++)
            {
                if ((CurrentlyApplying[a] != null)&&(CurrentlyApplying[a].remTurns > 0))
                {
                    switch (CurrentlyApplying[a].mytype)
                    {
                        case GameConstants.EffectType.Burn:
                            GetHurt(CurrentlyApplying[a]);
                            break;
                        case GameConstants.EffectType.Curse:
                            npcstats[CurrentlyApplying[a].statSlot].statBonus = -1 * CurrentlyApplying[a].GetDamage()/5;
                            break;
                        case GameConstants.EffectType.Daze:
                            mMult = CurrentlyApplying[a].GetDamage();
                            break;
                        case GameConstants.EffectType.Modify:
                            // Regenerate, Burn willpower etc.
                            break;
                        default:
                            break;
                    }
                    CurrentlyApplying[a].remTurns--;
                    if (CurrentlyApplying[a].remTurns <= 0)
                        CurrentlyApplying.RemoveAt(a);
                } else
                {
                    CurrentlyApplying.RemoveAt(a);
                }
            }
            StartCoroutine(Revert());
        }
    }

    IEnumerator Revert()
    {
        yield return new WaitForSeconds(1.5f);
        for (int a = 0; a < npcstats.Length; a++)
        {
            npcstats[a].statBonus = 0;
        }
        mMult = 0;
    }

    bool IsFacing()
    {
        if (Quaternion.Angle(transform.rotation, Quaternion.Euler(player.rotation.eulerAngles * -1)) < 30)
            return true;
        else
            return false;
    }

    

    void Update()
    {
        if ((curHP > 0)&&(player.gameObject.GetComponent<player_stats>().myanim.GetBool("GamePlayActive"))&&(!IsOccupied))
        {
            if (isFleeing)
            {
                if (Vector3.Distance(player.position,transform.position) > MaxAllowedDistance)
                {
                    GameObject.FindGameObjectWithTag("GameController").GetComponent<WayBase>().ReSpawn();
                }
                if (target == !WayPointObjects[waypointCounter].transform)
                {
                    target = WayPointObjects[waypointCounter].transform;
                    navmAgent.SetDestination(target.position);
                }
                if (waypointCounter < WayPointObjects.Length)
                {
                    if ((navmAgent.remainingDistance < 1)&&(waypointCounter < WayPointObjects.Length-1))
                    {
                        // next waypoint
                        waypointCounter++;
                        GameObject.FindGameObjectWithTag("GameController").GetComponent<WayBase>().TaskIncrement(false);
                    }
                    else
                    {
                        mymodelAnimator.SetBool("OnTheMove", true);
                        character.Move(navmAgent.desiredVelocity * (1 - mMult), false, false);
                        character.Move(Vector3.zero, false, false);
                    }

                }
            }
            else if ((Vector3.Distance(transform.position, player.position) < observeRange)&&(!isFleeing))
            {
                target = player;
                    
                if (target != transform)
                    navmAgent.SetDestination(target.position);
                else
                    navmAgent.SetDestination(gameObject.transform.position);

                if (navmAgent.remainingDistance > navmAgent.stoppingDistance)
                {
                    mymodelAnimator.SetBool("OnTheMove", true);
                    character.Move(navmAgent.desiredVelocity * (1 - mMult), false, false);       
                }
                else
                {
                    character.Move(Vector3.zero, false, false);
                }
            } else if ((curHP > 0) && (player.gameObject.GetComponent<player_stats>().myanim.GetBool("GamePlayActive")) && (!IsOccupied))
            {
              
            }

        }
    }

    

    void Roam()
    {

    }

    
}
