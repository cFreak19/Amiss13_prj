﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.Characters.ThirdPerson;
using A13_theCurse_GameConst;

public class tutorial_miniboss : automated
{
    public int isPassedChPLevel;
    public GameObject spikePrefab;
    public float SpikeTimer;
    public Animator mymodelAnimator;
    UnityEngine.AI.NavMeshAgent navmAgent;
    ThirdPersonCharacter character;
    public Transform target, player;
    public float observeRange, swingTime, mMult;
    public stat[] npcstats = new stat[6];
    public bool storyProgression;
    private bool started = false;
    public GameObject CutsceneAtEnd, StompDust, ArmCol, SPBubble;

    public override void Init()
    {
        StartFight();
    }

    void Start()
    {
        player = GameObject.Find("Player_Object").transform;
        navmAgent = GetComponent<UnityEngine.AI.NavMeshAgent>();
        navmAgent.updateRotation = false;
        navmAgent.updatePosition = true;
        character = GetComponent<ThirdPersonCharacter>();
        maxHP = (npcstats[0].statAmount + npcstats[0].statBonus) * 3;
        curHP = maxHP;
        target = this.transform;
        InvokeRepeating("EffectCheck", 1.5f, 1.5f);
    }


    public override void Interact()
    {

    }
    
    public override void GetCast(Applied_Effect eff)
    {
        curHP -= eff.GetDamage() * ((100 - npcstats[6].statAmount * 2) / 100);
        if ((hasWP) && (eff.mytype == GameConstants.EffectType.Modify))
        {
            curWP -= eff.GetDamage() * ((100 - npcstats[6].statAmount) / 50);
        }
        if (curHP <= 0)
        {
            curHP = 0;
            Faint();
        }
    }
    public override void GetHurt(int a)
    {
        if (player.transform.gameObject.GetComponent<Animator>().GetBool("GamePlayActive"))
        {
            if (mymodelAnimator.GetBool("fightActive"))
            {
                curHP -= a * ((100 - npcstats[5].getTotalStat()) / 100);
                if (curHP <= 0)
                {
                    Faint();
                }
            }
        }
    }

    public override void GetHurt(Applied_Effect eff)
    {
        curHP -= eff.GetDamage() * ((100 - npcstats[6].getTotalStat()) / 100);
        if (curHP <= 0)
        {
            Faint();
        }
    }

    void Faint()
    {
        mymodelAnimator.SetBool("fightActive", false);
        CancelInvoke();
        GetComponent<Rigidbody>().velocity = Vector3.zero;
        CutsceneAtEnd.GetComponent<cutscene>().InitiateScene();
        if (storyProgression)
            player.GetComponent<player_stats>().StoryC++;
        GameObject.FindGameObjectWithTag("GameController").GetComponent<WayBase>().TaskIncrement(false);
        if (GetComponent<Lootable>())
        {
            GetComponent<Lootable>().BlurpLoot();
        }
    }

    void AttackRotation()
    {
        if (!mymodelAnimator.GetBool("Engaged"))
            mymodelAnimator.SetBool("Engaged", true);
        float dist = Vector3.Distance(player.position, transform.position);
        if (dist <= 11f)
            StartCoroutine(Swing());
        else if ((dist > 16f) && (dist <= observeRange))
            StartCoroutine(SpikeImpale());
        else if ((dist > 11f) && (dist <= 16f))
            StartCoroutine(Stomp());
        else
        {
            mymodelAnimator.SetBool("Engaged", false);
            CancelInvoke();
        }
    }

    IEnumerator Swing()
    {
        mymodelAnimator.SetInteger("animationNumber", 1);
        mymodelAnimator.SetBool("animating", true);
        yield return new WaitForSeconds(0.5F);
        ArmCol.GetComponent<BoxCollider>().enabled = true;
        yield return new WaitForSeconds(0.5f);
        mymodelAnimator.SetBool("animating", false);
        ArmCol.GetComponent<BoxCollider>().enabled = false;
    }

    IEnumerator Stomp()
    {
        mymodelAnimator.SetInteger("animationNumber", 2);
        mymodelAnimator.SetBool("animating", true);
        SPBubble.GetComponent<StorySpeech>().Comment(1);
        yield return new WaitForSeconds(0.5f);
        StompDust.GetComponent<ParticleSystem>().Play();
        yield return new WaitForSeconds(0.1f);
        StompDust.GetComponent<BoxCollider>().enabled = true;
        yield return new WaitForSeconds(0.15f);
        StompDust.GetComponent<BoxCollider>().enabled = false;
        mymodelAnimator.SetBool("animating", false);
    }

    IEnumerator SpikeImpale()
    {
        mymodelAnimator.SetInteger("animationNumber", 0);
        mymodelAnimator.SetBool("animating", true);
        SPBubble.GetComponent<StorySpeech>().Comment(0);
        yield return new WaitForSeconds(1f);
        Instantiate(spikePrefab, new Vector3(target.position.x, 7.5f, target.position.z), Quaternion.identity);
        yield return new WaitForSeconds(0.4f);
        mymodelAnimator.SetBool("animating", false);
    }


    void EffectCheck()
    {
        if (CurrentlyApplying.Count > 0)
        {
            for (int a = 0; a < CurrentlyApplying.Count; a++)
            {
                if ((CurrentlyApplying[a] != null) && (CurrentlyApplying[a].remTurns > 0))
                {
                    switch (CurrentlyApplying[a].mytype)
                    {
                        case GameConstants.EffectType.Burn:
                            GetHurt(CurrentlyApplying[a]);
                            break;
                        case GameConstants.EffectType.Curse:
                            npcstats[CurrentlyApplying[a].statSlot].statBonus = -1 * CurrentlyApplying[a].GetDamage() / 5;
                            break;
                        case GameConstants.EffectType.Daze:
                            mMult = CurrentlyApplying[a].GetDamage();
                            break;
                        case GameConstants.EffectType.Modify:
                            // Regenerate, Burn willpower etc.
                            break;
                        default:
                            break;
                    }
                    CurrentlyApplying[a].remTurns--;
                    if (CurrentlyApplying[a].remTurns <= 0)
                        CurrentlyApplying.RemoveAt(a);
                }
                else
                {
                    CurrentlyApplying.RemoveAt(a);
                }
            }
            StartCoroutine(Revert());
        }
    }

    IEnumerator Revert()
    {
        yield return new WaitForSeconds(1.5f);
        for (int a = 0; a < npcstats.Length; a++)
        {
            npcstats[a].statBonus = 0;
        }
        mMult = 0;
    }

    public void StartFight()
    {
        if (!mymodelAnimator.GetBool("Engaged"))
        {
            mymodelAnimator.SetBool("fightActive", true);
            mymodelAnimator.SetBool("Engaged", true);
            target = player;
            InvokeRepeating("AttackRotation", swingTime, swingTime);
        }
    }


    void Update()
    {
        if (player.gameObject.GetComponent<player_stats>().myanim.GetBool("GamePlayActive"))
        {
            if ((curHP > 0) && (target != null) && (mymodelAnimator.GetBool("fightActive")) && (mymodelAnimator.GetBool("Engaged")))
            {
                if (Vector3.Distance(transform.position, player.position) < observeRange)
                {
                    target = GameObject.Find("Player_Object").transform;
                    if (navmAgent.remainingDistance <= navmAgent.stoppingDistance)
                    {
                        mymodelAnimator.SetBool("OnTheMove", false);
                    }
                    else
                    {
                        mymodelAnimator.SetBool("OnTheMove", true);
                    }
                    if (!mymodelAnimator.GetBool("Engaged"))
                    {
                        InvokeRepeating("AttackRotation", swingTime, swingTime);
                    }
                }
                else
                {
                    CancelInvoke();
                    target = this.gameObject.transform;
                    mymodelAnimator.SetBool("OnTheMove", false);
                    mymodelAnimator.SetBool("Engaged", false);
                }
                if (target != this.gameObject.transform)
                    navmAgent.SetDestination(target.position);
                else
                    navmAgent.SetDestination(gameObject.transform.position);

                if ((navmAgent.remainingDistance > navmAgent.stoppingDistance) && (navmAgent.remainingDistance > navmAgent.stoppingDistance))
                {
                    character.Move(navmAgent.desiredVelocity * (1 - mMult), false, false);
                    mymodelAnimator.SetBool("OnTheMove", true);
                }
                else
                {
                    character.Move(Vector3.zero, false, false);
                }
            }

            if ((Vector3.Distance(transform.position, player.transform.position) < observeRange) && (!mymodelAnimator.GetBool("fightActive")) && (curHP > 0))
            {
                mymodelAnimator.SetBool("fightActive", true);
            }

            if ((curHP <= 0) && (mymodelAnimator.GetBool("fightActive")))
            {
                Faint();
            }
        }
    }

}
