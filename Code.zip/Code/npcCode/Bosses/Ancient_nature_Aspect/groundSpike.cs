﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class groundSpike : MonoBehaviour
{
    public float timeUntilStrike;

    IEnumerator HitTimer()
    {
        yield return new WaitForSeconds(timeUntilStrike);
        RaycastHit myhit;
        if (Physics.Raycast(transform.position, transform.up, out myhit, 3F))
        {

        }
    }
}
