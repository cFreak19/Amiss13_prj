﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;       
using UnityStandardAssets.Characters.ThirdPerson;

public class SecretCannon : MonoBehaviour {
    [Header("BaseRequirements")]
    // stand, move, hit, get hit animations.
    public Animator mymodelAnimator;
    UnityEngine.AI.NavMeshAgent navmAgent;
    ThirdPersonCharacter character;
    public Transform target, player;


    public AudioClip FiringSound;
    private GameObject PlayerObj;
    private Vector3 targetPos;
    public float FireFrequency, FireStrength;
    public int PotentialFireDamage;
    public GameObject ProjectilePrefab, targetObj, aimDispPrefab;

	// Use this for initialization
	void Start () {
        PlayerObj = GameObject.Find("Player_Object");
        navmAgent = GetComponent<UnityEngine.AI.NavMeshAgent>();
        navmAgent.updateRotation = false;
        navmAgent.updatePosition = true;
        character = GetComponent<ThirdPersonCharacter>();
    }
	

    void FireCheck()
    {
        StartCoroutine(OpenFire());
    }


    IEnumerator OpenFire()
    {
        targetPos = PlayerObj.transform.position;
        GameObject aimD = Instantiate(aimDispPrefab, targetPos, Quaternion.identity) as GameObject;
        GetComponent<AudioSource>().clip = FiringSound;
	GetComponent<AudioSource>().Play();
        mymodelAnimator.SetBool("Aiming", true);
        yield return new WaitForSeconds(1.5f);
        mymodelAnimator.SetBool("Aiming", false);
        GameObject myBalls = Instantiate(ProjectilePrefab, transform.position, Quaternion.identity) as GameObject;
        myBalls.GetComponent<projectile>().RawDamageHeld = PotentialFireDamage;

    }                          

	// Update is called once per frame
	void Update () {
		
	}
}
