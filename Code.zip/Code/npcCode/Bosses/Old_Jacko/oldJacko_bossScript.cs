﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.Characters.ThirdPerson;
using A13_theCurse_GameConst;

public class oldJacko_bossScript : automated {

    [Header("BaseRequirements")]
    // stand, move, hit, get hit animations.
    public Animator mymodelAnimator;
    UnityEngine.AI.NavMeshAgent navmAgent;
    ThirdPersonCharacter character;
    public Transform player;

    [Header("CombatSpecs")]
    public int FightPhase = 0;
    public float observeRange, swingTime;
    public int healthMult, willMult;
    public float mMult;
    //private float ConstCounter;
    private bool IsOccupied = false;
    public invitem[] WeaponsArsenal = new invitem[3];

    [Header("Character Stats")]
    public stat[] npcstats = new stat[7];
    public GameObject[] SecretCrates = new GameObject[5];
    private bool MainHandNext = true;
    public float SwingFreqM = 1.2f;
    public float MDMult = 1.4f;
    private float CurSpeedMod = 1;
    public GameObject mdSmiley;

    [Header("Rest")]
    public int criticalAnimationNumber;
    public GameObject ArrowPrefab;
    public AudioClip meleeSwing, faint, emoteVA;
    public bool storyprogression = false;
    public bool taskIncrement = false;
    public GameObject OJackoSpeechBubble;
    public AudioClip[] OJackoFDialogues = new AudioClip[6];


    public void CritCamInit()
    {
        CancelInvoke();
        IsOccupied = true;
        mymodelAnimator.SetBool("swinging", false);
        GetComponent<CapsuleCollider>().enabled = false;
        transform.rotation = Quaternion.Euler((player.position - transform.position).normalized);
        mymodelAnimator.SetBool("struggle", true);
    }

    public void CritCamResolve()
    {
        GetComponent<CapsuleCollider>().enabled = false;
        mymodelAnimator.SetBool("struggle", false);
        if (curHP > 0)
        {
            IsOccupied = false;
        }
    }



    public override void Interact()
    {

    }

    public override void Init()
    {
  
       navmAgent = GetComponent<UnityEngine.AI.NavMeshAgent>();
        navmAgent.updateRotation = false;
        navmAgent.updatePosition = true;
        character = GetComponent<ThirdPersonCharacter>();
        maxHP = (npcstats[0].statAmount + npcstats[0].statBonus) * healthMult;
        maxWP = (npcstats[4].statAmount + npcstats[4].statBonus) * willMult;
        curHP = maxHP;
        maxWP = curWP;       
                
        InvokeRepeating("EffectCheck", 1.5f, 1.5f);
        mymodelAnimator.SetBool("IsActive", true);
    }

    bool IsFacing()
    {
        if (Quaternion.Angle(transform.rotation, Quaternion.Euler(player.rotation.eulerAngles * -1)) < 30)
            return true;
        else
            return false;
    }

    public override void GetHurt(int a)
    {
        IsOccupied = true;          

        int incDmg = a;
        if (!IsFacing())
        {
            incDmg *= 3;
            incDmg /= 2;
        }

        curHP -= incDmg * ((100 - npcstats[5].statAmount) / 100); //check mitigation done by fortitude
        Debug.Log(NPCname + "received " + (incDmg * ((100 - npcstats[5].statAmount) / 100)).ToString() + " physical damage.");

        if (curHP <= 0)
        {
            curHP = 0;
            Faint();
        }
        IsOccupied = false;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.transform.gameObject.GetComponent<spellContent>())
        {
            spellContent affectingSpell = other.transform.gameObject.GetComponent<spellContent>();
            affectingSpell.target = this.transform.gameObject;
            affectingSpell.Activate();
        }

    }
    public override void GetCast(Applied_Effect eff)
    {
        IsOccupied = true;
        curHP -= eff.GetDamage() * ((100 - npcstats[5].statAmount * 2) / 100);
        if ((hasWP) && (eff.mytype == GameConstants.EffectType.Burn))
        {
            curWP -= eff.GetDamage() * ((100 - npcstats[5].statAmount) / 50);
            CurrentlyApplying.Add(eff);
        }
        if (curHP <= 0)
        {
            curHP = 0;
            Faint();
        }
        if (eff.mytype == GameConstants.EffectType.Modify)
        {
            CurrentlyApplying.Add(eff);
        }
        IsOccupied = false;
    }

    public override void GetHurt(Applied_Effect eff)
    {
        curHP -= eff.GetDamage() * npcstats[5].statAmount / 100;
        if (curHP <= 0)
        {
            curHP = 0;
            Faint();
        }
    }

    void Faint()
    {
        if (mymodelAnimator.GetBool("struggle"))
            CritCamResolve();
        if (faint != null)
        {
            List<AudioClip> faints = new List<AudioClip>();
            faints.Add(faint);
            OJackoSpeechBubble.GetComponent<SingleCommentTrig>().ExternalSpCall(faints);
        }
        mymodelAnimator.SetBool("IsActive", false);
        GetComponent<CapsuleCollider>().enabled = false;
        
        transform.Find("PoolEmitter").GetComponent<ParticleSystem>().Play();
        GameObject.Find("Player_Object").GetComponent<player_stats>().BattleOff();
        AchiStatInc();
        GameObject.Find("Player_Object").GetComponent<InvController>().AcquireItem(GetComponent<Lootable>().PickAtRandom());

    }

    IEnumerator AdvanceChapter()
    {
        yield return new WaitForSeconds(12f);
        if (taskIncrement)
        {
            GameObject.Find("gameController").GetComponent<WayBase>().TaskIncrement(false);
        }
    }
    private void OnEnable()
    {
        PhaseAdvance();
    }

    void AttackRotation()
    {
        if (navmAgent.remainingDistance <= navmAgent.stoppingDistance)
        {
            if (!mymodelAnimator.GetBool("swinging"))
            {
                switch (FightPhase)
                {
                    case 0:
                        break;
                    case 1:
                        if (MainHandNext)
                            StartCoroutine(MainSwing());
                        else
                            StartCoroutine(OffSwing());
                        MainHandNext = !MainHandNext;
                        break;
                    case 3:
                        StartCoroutine(XbowSwing());
                        break;
                    case 2:
                        if (MainHandNext)
                            StartCoroutine(MainSwing());
                        else
                            StartCoroutine(OffSwing());
                        MainHandNext = !MainHandNext;
                        break;
                }
            }
        }
        else
        {
            List<AudioClip> myCry = new List<AudioClip>();
            myCry.Add(meleeSwing);
            OJackoSpeechBubble.GetComponent<SingleCommentTrig>().ExternalSpCall(myCry);
            CancelInvoke("AttackRotation");
        }
    }


    void UnlockCrates()
    {
        for (int a = 0; a < SecretCrates.Length; a++)
        {
            SecretCrates[a].GetComponent<sneakyCrate>().Reveal();
        }
    }


    IEnumerator MainSwing()
    {
        mymodelAnimator.SetBool("swinging", true);
        int atmptDamage;
        yield return new WaitForSeconds(WeaponsArsenal[0].HitDelay * CurSpeedMod);
        if ((navmAgent.remainingDistance < navmAgent.stoppingDistance))
        {
                if (IsFacing())
                {
                    atmptDamage = npcstats[1].getTotalStat() + WeaponsArsenal[0].dmgMod;
                    player.gameObject.GetComponent<player_stats>().GetHurt(atmptDamage);
                }
        }
        else
        {
            CancelInvoke("AttackRotation");
        }
        MainHandNext = false;
        mymodelAnimator.SetBool("MainSwingNext", false);
        yield return new WaitForSeconds((WeaponsArsenal[0].totalCD - WeaponsArsenal[0].HitDelay) * CurSpeedMod);
        mymodelAnimator.SetBool("swinging", false);
    }

    IEnumerator OffSwing()
    {
        mymodelAnimator.SetBool("swinging", true);
        int atmptDamage;
        yield return new WaitForSeconds(WeaponsArsenal[1].HitDelay * CurSpeedMod);
        if ((navmAgent.remainingDistance < navmAgent.stoppingDistance))
        {

            if (IsFacing())
            {
                atmptDamage = npcstats[1].getTotalStat() + WeaponsArsenal[1].dmgMod;
                player.gameObject.GetComponent<player_stats>().GetHurt(atmptDamage);
            }
        }
        else
        {
            CancelInvoke("AttackRotation");
        }
        MainHandNext = true;
        mymodelAnimator.SetBool("MainSwingNext", true);
        yield return new WaitForSeconds((WeaponsArsenal[1].totalCD - WeaponsArsenal[1].HitDelay) * CurSpeedMod);
        mymodelAnimator.SetBool("swinging", false);
        if (UnityEngine.Random.Range(0, 100) < 40)
            GetComponent<StorySpeech>().RandComm();
    }

    IEnumerator XbowSwing()
    {
        mymodelAnimator.SetBool("swinging", true);
        int atmptDamage;
        yield return new WaitForSeconds(WeaponsArsenal[2].HitDelay * CurSpeedMod);
        if ((navmAgent.remainingDistance < navmAgent.stoppingDistance))
        {

            if (IsFacing())
            {
                GameObject bolt = Instantiate(ArrowPrefab, WeaponsArsenal[2].worldprefab.transform.position, Quaternion.identity) as GameObject;
                atmptDamage = npcstats[4].getTotalStat() + WeaponsArsenal[2].dmgMod;
                bolt.GetComponent<projectile>().RawDamageHeld = atmptDamage;
                bolt.GetComponent<projectile>().ForceMagnitude = 20;
                bolt.GetComponent<projectile>().targeted = true;
                bolt.GetComponent<projectile>().targetPos = player.position;
                //player.gameObject.GetComponent<player_stats>().GetHurt(atmptDamage);
            }
        }
        else
        {
            CancelInvoke("AttackRotation");
        }
        yield return new WaitForSeconds((WeaponsArsenal[2].totalCD - WeaponsArsenal[2].HitDelay) * CurSpeedMod);
        mymodelAnimator.SetBool("swinging", false);
        mymodelAnimator.SetBool("MainSwingNext", true);
        if (UnityEngine.Random.Range(0, 100) < 30)
            GetComponent<StorySpeech>().RandComm();
    }

    IEnumerator SwingFail()
    {
        yield return new WaitForSeconds(0.4f);
        mymodelAnimator.SetBool("swinging", false);
        mymodelAnimator.SetBool("MainSwingNext", true);
        MainHandNext = true;
    }


    void PhaseAdvance()
    {
        FightPhase++;
        mymodelAnimator.SetInteger("fightPhase", FightPhase);
        OJackoSpeechBubble.GetComponent<SingleCommentTrig>().progressing = true;
        StartCoroutine(AdvanceAni());
    }

    IEnumerator AdvanceAni()
    {
      
        yield return new WaitForSeconds(1f);
        if (FightPhase == 1)
        {

        }
        else if (FightPhase == 2)
        {     
            List<AudioClip> NeccAudio = new List<AudioClip>();
            NeccAudio.Add(OJackoFDialogues[1]);
            NeccAudio.Add(OJackoFDialogues[2]);
            NeccAudio.Add(OJackoFDialogues[3]);
            OJackoSpeechBubble.GetComponent<SingleCommentTrig>().ExternalSpCall(NeccAudio);
            WeaponsArsenal[0].worldprefab.SetActive(true);
            WeaponsArsenal[1].worldprefab.SetActive(true);
        }
        else if (FightPhase == 3)
        {
            List<AudioClip> NeccAudio = new List<AudioClip>();
            NeccAudio.Add(OJackoFDialogues[4]);
            NeccAudio.Add(OJackoFDialogues[5]);
            NeccAudio.Add(emoteVA);
            OJackoSpeechBubble.GetComponent<SingleCommentTrig>().ExternalSpCall(NeccAudio);
            WeaponsArsenal[0].worldprefab.SetActive(true);
            WeaponsArsenal[1].worldprefab.SetActive(true);
        }
        else if (FightPhase == 4)
        {
            navmAgent.stoppingDistance = WeaponsArsenal[2].itemRange;
            List<AudioClip> NeccAudio = new List<AudioClip>();
            NeccAudio.Add(OJackoFDialogues[6]);           
            OJackoSpeechBubble.GetComponent<SingleCommentTrig>().ExternalSpCall(NeccAudio);
            WeaponsArsenal[0].worldprefab.SetActive(false);
            WeaponsArsenal[1].worldprefab.SetActive(false);
            WeaponsArsenal[2].worldprefab.SetActive(true);
        }
        CancelInvoke("AttackRotation");     
    }

  

    void Update()
    {
        bool gameOn = player.gameObject.GetComponent<player_stats>().myanim.GetBool("GamePlayActive");
        if (curHP > 0)
        {
            if ((curHP < maxHP * 80 / 100) && (FightPhase == 1) && gameOn)
            {
                PhaseAdvance();
            }
            else if ((curHP < maxHP * 40 / 100) && (FightPhase == 2) && gameOn)
            {
                PhaseAdvance();
            }
            else if ((curHP < maxHP * 30 / 100) && (FightPhase == 3) && gameOn)
            {
                PhaseAdvance();
            }
        }
        if ((curHP > 0) && gameOn && (!IsOccupied))
        {
            if (navmAgent.remainingDistance < observeRange)
            {
                if (FightPhase > 0)
                {

                        GameObject.Find("Player_Object").GetComponent<player_stats>().BattleOn();
                    if (navmAgent.remainingDistance <= navmAgent.stoppingDistance)
                    {
                        mymodelAnimator.SetBool("OnTheMove", false);
                        if (!IsInvoking("AttackRotation"))
                        {
                            InvokeRepeating("AttackRotation", swingTime * CurSpeedMod, swingTime * CurSpeedMod);
                        }
                    }
                    else
                    {
                        if (!mymodelAnimator.GetBool("swinging"))
                        {
                            CancelInvoke("AttackRotation");
                            mymodelAnimator.SetBool("OnTheMove", true);
                        }
                    }
                }
                navmAgent.SetDestination(gameObject.transform.position);

                if (navmAgent.remainingDistance > navmAgent.stoppingDistance)
                {
                    mymodelAnimator.SetBool("OnTheMove", true);
                    character.Move(navmAgent.desiredVelocity * (1 - mMult), false, false);
                }
                else
                {
                    character.Move(Vector3.zero, false, false);
                }
            }
            
        }
    }
}
