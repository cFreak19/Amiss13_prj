﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sneakyCrate : MonoBehaviour {
    public GameObject CannonObj;

	public void Reveal()
    {
        GetComponent<AudioSource>().Play();
        CannonObj.SetActive(true);
        Destroy(transform.gameObject, 0.5f);
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
