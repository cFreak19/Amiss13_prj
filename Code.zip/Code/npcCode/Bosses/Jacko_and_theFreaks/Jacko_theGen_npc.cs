﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using A13_theCurse_GameConst;

public class Jacko_theGen_npc : MonoBehaviour {
    public GameObject[] MinionPrefabs = new GameObject[3];
    public List<GameObject> ActiveMinions = new List<GameObject>();
    public GameObject theJokeCutscene, platform, theJokeGObj;
    public int[] waveLevels = new int[3];
    public Vector3 summonAnchor = Vector3.zero;
    public Rect summonArea;
    public AudioClip[] jackoLines;
    public GameObject jackoSpeechBubble, fightEndCutscene;
    private int SummonedMinionsForTurn;
    public int firstTurnMinonN, secondTurnMinionN, thirdTurnMinionN;
    private int curWave;

	// Use this for initialization
	void Start () {
        InvokeRepeating("CheckOnMinions", 0.5f, 0.5f);	
	}

    private void OnEnable()
    {
        AdvanceWaves();
    }

    void CheckOnMinions()
    {
        if (ActiveMinions.Count > 0)
        {
            for (int a = 0; a < ActiveMinions.Count; a++)
            {
                if ((ActiveMinions[a] == null) && (a < ActiveMinions.Count))
                {
                    ActiveMinions.RemoveAt(a);
                    a--;
                }
            }
        } else
        {
            StartCoroutine(AdvanceWaves());
            List<AudioClip> shortcomment = new List<AudioClip>();
            shortcomment.Add(jackoLines[curWave-1]);
            jackoSpeechBubble.GetComponent<SingleCommentTrig>().ExternalSpCall(shortcomment);
        }
    }

    IEnumerator AdvanceWaves()
    {
        curWave++;
        jackoSpeechBubble.GetComponent<SingleCommentTrig>().PointItOut();
        switch(curWave)
        {
            case 1:
                SummonedMinionsForTurn = firstTurnMinonN;
                break;
            case 2:
                SummonedMinionsForTurn = secondTurnMinionN;
                break;
            case 3:
                SummonedMinionsForTurn = thirdTurnMinionN;
                break;
            case 4:
                SummonedMinionsForTurn = 0;
                break;
        }
        yield return new WaitForSeconds(2f);
        StartCoroutine(SummonWave());
    }

    public void WinCondition()
    {
        theJokeGObj.SetActive(false);
        fightEndCutscene.GetComponent<cutscene>().InitiateScene();
    }

    IEnumerator SummonWave()
    {
        if (curWave < 4)
        {
            for (int a = 0; a < SummonedMinionsForTurn; a++)
            {
                Vector3 summonLoc = summonAnchor + new Vector3(UnityEngine.Random.Range(summonArea.x, summonArea.x + summonArea.width), 4, UnityEngine.Random.Range(summonArea.y, summonArea.y + summonArea.height));
                GameObject nextMinion = Instantiate(MinionPrefabs[UnityEngine.Random.Range(0, MinionPrefabs.Length)], summonLoc, Quaternion.identity) as GameObject;
                nextMinion.GetComponent<simple_npc>().level = waveLevels[curWave - 1];
                yield return new WaitForSeconds(0.5f);
            }

        } else
        {
            theJokeCutscene.GetComponent<cutscene>().InitiateScene();
        }
    }

	// Update is called once per frame
	void Update () {
		//if (platform.GetComponent<itemPickup>)
	}
}
