﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class platform : MonoBehaviour {
    public int curHp, maxHp;
    public GameObject JackoObj, particles;

	// Use this for initialization
	void Start () {
		
	}


    public void GetCrashedInto()
    {
        particles.GetComponent<ParticleSystem>().Play();
        particles.GetComponent<AudioSource>().Play();
        curHp--;
        if (curHp <= 0)
        {
            JackoObj.GetComponent<Jacko_theGen_npc>().WinCondition();
        }
    }

    // Update is called once per frame
    void Update () {
		
	}
}
