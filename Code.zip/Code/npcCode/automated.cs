﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using A13_theCurse_GameConst;

public abstract class automated : MonoBehaviour
{
    public string NPCname;
    public GameConstants.CreatureType type;
    public string description;
    public int maxHP = 1;
    public int curHP = 1;
    public int maxWP, curWP;
    public int WRegen, HRegen;
    public int level;
    public List<Applied_Effect> CurrentlyApplying = new List<Applied_Effect>();
    public List<reward> killRew = new List<reward>();
    public bool hasWP;

    public float GetHitR()
    {
        return float.Parse(curHP.ToString()) / float.Parse(maxHP.ToString());
    }

    void Start()
    {
        
    }

    void Update()
    {
        
    }

    public string GetHoverString()
    {
        return NPCname + " lv." + level.ToString() + "| " + type.ToString();
    }
    public abstract void Interact();

    public void AchiStatInc()
    {
        string achistatname = "";
        switch(type)
        {
            case GameConstants.CreatureType.Ancient:
                achistatname = "kAncient";
                break;
            case GameConstants.CreatureType.Humanoid:
                achistatname = "kHum";
                break;
            case GameConstants.CreatureType.Mystical:
                achistatname = "kMystical";
                break;
            case GameConstants.CreatureType.Unknown:
                achistatname = "kUKnown";
                break;
            case GameConstants.CreatureType.Wild:
                achistatname = "kWild";
                break;
        }
        //GameObject.Find("gameController").GetComponent<steamMethod>().UpAchiCount(achistatname);
    }

    public bool CheckForDaze()
    {
        for (int a = 0; a < CurrentlyApplying.Count; a++)
        {
            if (CurrentlyApplying[a].mytype == GameConstants.EffectType.Daze)
                return true;
        }
        return false;
    }


    public abstract void Init();
    public abstract void GetHurt(Applied_Effect eff);
    public abstract void GetCast(Applied_Effect eff);
    public abstract void GetHurt(int damageAmnt);
}
