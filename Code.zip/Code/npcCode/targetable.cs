﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class targetable : MonoBehaviour{
    public Animator meshAnimator;
    public GameObject[] SpawnObjects;
    public automated specs;

	// Use this for initialization
	void Start () {
		
	}

    public void DestroyObj()
    {
        GetComponent<AudioSource>().Play();
        for (int a = 0; a < SpawnObjects.Length; a++)
        {
            Instantiate(SpawnObjects[a], new Vector3(transform.position.x + Random.Range(-1, 1), transform.position.y + Random.Range(-1, 1), transform.position.z + Random.Range(-1, 1)),Quaternion.identity);
        }
    }

    IEnumerator complete()
    {
        yield return new WaitForSeconds(1f);
        Destroy(this.gameObject);
    }

    public void GetHit(int a)
    {
        GetComponent<automated>().GetHurt(a);
    }

	// Update is called once per frame
	void Update () {
		
	}
}
