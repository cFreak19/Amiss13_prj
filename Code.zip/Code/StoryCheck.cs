﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
 

public class StoryCheck : MonoBehaviour {
    public bool[] VarsOnCheck = new bool[5];
    public bool TaskIncrement = false;
	public List<GameObject> TobeEnabled = new List<GameObject>();


    public void SetActivity(bool current, int order)
    {
        VarsOnCheck[order] = current;
    }


	// Use this for initialization
	void Start () {
		
	}
	
    void ActOnSucces()
    {

    }

    public void CheckForAction()
    {
        int count = 0;
        for (int a = 0; a < VarsOnCheck.Length; a++)
        {
            if (VarsOnCheck[a])
                count++;
        }
        if (count >= VarsOnCheck.Length -1)
        {
            ActOnSucces();
        }
    }


	// Update is called once per frame
	void Update () {
		
	}
}
