﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cameraShake : MonoBehaviour {
    public GameObject myCamera;
    public bool ShakeOn = false;

	
    public void QuakeForUs()
    {
        InvokeRepeating("CheckForShake", 1f, 1f);
    }
	
    public void WrapUp()
    {
        CancelInvoke("CheckForShake");
    }

    void CheckForShake()
    {
        if (ShakeOn)
            StartCoroutine(Shake());
    }

    public void SingleShake()
    {
        StartCoroutine(Shake());
    }

    IEnumerator Shake()
    {
        Vector3 mynew = new Vector3(UnityEngine.Random.Range(-2, 2), UnityEngine.Random.Range(-2, 2), UnityEngine.Random.Range(-2, 2));
        transform.position += mynew;
        yield return new WaitForSeconds(0.3f);
        transform.position -= mynew;
    }

	// Update is called once per frame
	void Update () {
        
	}
}
