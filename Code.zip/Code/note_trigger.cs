﻿using UnityEngine;
using System.Collections;

public class note_trigger : MonoBehaviour {
    public int notificationNumber;
    public bool isTutorial;
    public string Message;

	public void PickUp()
    {
        if (Message.Length < 2)
        {
            if (isTutorial)
            {
                GameObject.Find("Initial_Tutorial" + notificationNumber.ToString()).SetActive(true);
            }
            else
            {
                GameObject.Find("NotificationPanel" + notificationNumber.ToString()).SetActive(true);
            }
        }
        else
        {
            GameObject.Find("UI_MessagePanel" + notificationNumber.ToString()).SetActive(true);
        }
        Destroy(this.gameObject);
    }

    public void OnCollision(Collider mycollider)
    {
        PickUp();
    }
}
