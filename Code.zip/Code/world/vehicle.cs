﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class vehicle : MonoBehaviour {
	public Transform FrontWheelLeft, FrontWheelRight;
	public Transform[] OtherWheels;
	public bool isonthemove, turningleft, turningright;
	public Vector3 forwardrot;
	private Vector3 defaultLWRot,defaultRWRot;
	public float speedMult;

	void Start()
	{
		defaultLWRot = FrontWheelLeft.rotation.eulerAngles;
		defaultRWRot = FrontWheelRight.rotation.eulerAngles;
	}

	public void SteerLeft()
	{
		FrontWheelLeft.rotation.eulerAngles.Set(defaultLWRot.x,defaultLWRot.y -45, defaultLWRot.z);
		FrontWheelRight.rotation.eulerAngles.Set(defaultRWRot.x,defaultRWRot.y - 45, defaultRWRot.z);
		turningleft = true;
		turningright = false;
	}

	public void SteerRight()
	{
		FrontWheelLeft.rotation.eulerAngles.Set(defaultLWRot.x,defaultLWRot.y +45, defaultLWRot.z);
		FrontWheelRight.rotation.eulerAngles.Set(defaultRWRot.x,defaultRWRot.y + 45, defaultRWRot.z);
		turningleft = false;
		turningright = true;
	}

	void Update () {
		if (isonthemove) {
				for (int a = 0; a < OtherWheels.Length; a++) {
				OtherWheels [a].Rotate (forwardrot * speedMult);
			}
			FrontWheelLeft.Rotate(forwardrot * speedMult);
			FrontWheelRight.Rotate(forwardrot * speedMult);
			GetComponent<Rigidbody> ().AddForce (transform.forward * speedMult); //car meshes need to be rotated on X axis... Too lazy to set an empty parent.
		}

	}
}
