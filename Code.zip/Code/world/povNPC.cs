﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[Serializable]
public class Query
{
    public string theQuestionString;
    public int[] theQuestion = new int[1];
    public bool ResponseisAudio;
    public int[] theResponse = new int[1];
    public bool furtherDialOn = false;
    public int[] furtherDialN = new int[1];
    public bool Explored = false;
    public bool SuccessDial = false;
    public int reqExpl;

    // Only for Hogus
    public bool ResponseRoll; //false:: speechanimation, true:: rollanimation
}

[Serializable]
public class QSelection
{
    public string selectionString;
    public int audioN;
}

[Serializable]
public class DialogueTree
{
    public List<Query> PossibleQueries = new List<Query>();
    public int RequiredStoryLevel;
    public string RequiredKItemName;
}


public class povNPC : MonoBehaviour {
    public  Camera maincam, povcam;
    [SerializeField] private GameObject playerObj, NPCspeechObj, plSpeechObj;
    public AudioClip[] npcResponses = new AudioClip[1];
    public AudioClip[] WyattResponses = new AudioClip[1];
    private bool dialogueOn;
    public bool ActonEnable, LockedDialogue, IntroduceOnEnable; //Locked Dialogues are one time, can not be left unless game is shut down or story is progressed.
    public List<Query> QueryBase = new List<Query>();
    private List<string> QueriedLog = new List<string>();
    private List<int> ResponseList = new List<int>();
    private int ExplorationCounter;
    private List<AudioClip> Query_respAudio = new List<AudioClip>();
    private List<AudioClip> Query_WAudio = new List<AudioClip>();
    private int rootResponse = -1;
    public bool lastDial = false;
    private int curBaseN = -1;
    private List<string> Query_Wqueries = new List<string>();
    public GUISkin myskin;
    public GameObject playCSonEnd;
    public float reqDistance;
    public Animator CharAnim;
    public int aniResponseVariations; //0 means no animation 
    public bool RollThisTurnAround = false;

    // Use this for initialization
    void Start () {
        playerObj = GameObject.Find("Player_Object");
    }

    public void Engage()
    {
        if (Vector3.Distance(playerObj.transform.position,transform.position)<reqDistance)
            Activate();
    }

    void Deactivate()
    {
        playerObj.GetComponent<player_stats>().myanim.SetBool("GamePlayActive", true);
        dialogueOn = false;
        ResponseList.Clear();
        rootResponse = -1;
        ExplorationCounter = 0;
    }

    void OnEnable()
    {
        Activate();
    }

    public IEnumerator Activate()
    {
        playerObj.GetComponent<player_stats>().myanim.SetBool("GamePlayActive", false);
        if (IntroduceOnEnable)
        {
            NPCspeechObj.GetComponent<SingleCommentTrig>().SpillEverythingOut();
            yield return (NPCspeechObj.GetComponent<SingleCommentTrig>().IsDone());
        }
        else
            yield return new WaitForSeconds(0.5f);
        StartDialogue();
    }

    void StartDialogue()
    {
        povcam.enabled = true;
        maincam.enabled = false;
        dialogueOn = true;
        ResponseList.Add(0);
        curBaseN = 0;

        Query_respAudio.Clear();
        for (int a = 0; a < QueryBase[0].theResponse.Length; a++)
        {
            Query_respAudio.Add(npcResponses[QueryBase[0].theResponse[a]]);
        }
        if (QueryBase[0].ResponseisAudio)
        {
            Query_WAudio.Clear();
            for (int a = 0; a < QueryBase[0].theQuestion.Length; a++)
            {
                Query_WAudio.Add(WyattResponses[QueryBase[0].theQuestion[a]]);
            }
        }
        Query_Wqueries.Clear();
        for (int a = 0; a < QueryBase[0].furtherDialN.Length; a++)
        {
                Query_Wqueries.Add(QueryBase[QueryBase[0].furtherDialN[a]].theQuestionString);
        }
        RollThisTurnAround = QueryBase[0].ResponseRoll;
        StartCoroutine(UpdateQuery());
    }
        
  
    IEnumerator UpdateQuery()
    {
        float waitSeconds;
        if (Query_WAudio.Count > 0)
        {
            NPCspeechObj.GetComponent<SingleCommentTrig>().ExternalSpCall(Query_WAudio);
            waitSeconds = 0.5f;
            for (int a = 0; a < Query_WAudio.Count; a++)
            {
                waitSeconds += Query_WAudio[a].length * 20 * Time.deltaTime;
            }
        }
        NPCspeechObj.GetComponent<SingleCommentTrig>().ExternalSpCall(Query_respAudio);
        waitSeconds = 0.5f;
        if (!QueryBase[curBaseN].Explored)
        {
            QueryBase[curBaseN].Explored = true;
            ExplorationCounter++;
        }
        for (int a = 0; a < Query_respAudio.Count; a++)
        {
            waitSeconds += Query_respAudio[a].length;
        }
        CharAnim.SetInteger("speechAniNo",UnityEngine.Random.Range(1,aniResponseVariations));
        CharAnim.SetBool("animating", true);
        yield return new WaitForSeconds(waitSeconds * 20 * Time.deltaTime);
        CharAnim.SetBool("animating", false);
        if(RollThisTurnAround)
        {
            for (int a = 0; a < 3; a++)
            {
                if (UnityEngine.Random.Range(0,2) == 0)
                {
                    CharAnim.SetInteger("SelectRoll", 2);
                } else
                {
                    CharAnim.SetInteger("SelectRoll", 5);
                }
                CharAnim.SetBool("rolling", true);
                CharAnim.SetBool("animating", true);
                yield return new WaitForSeconds(3.4f * Time.deltaTime);
            }
        }
        if (lastDial)
            EndNPCDialogue();
        int CurTree = 0;
        for (int a = 0; a < ResponseList.Count; a++)
        {
            CurTree = QueryBase[CurTree].theResponse[ResponseList[a]];
        }
        if ((ResponseList.Count > 0)&&(ResponseList.Count < QueryBase.Count)&&(CurTree != -2))
        {
            lastDial = QueryBase[CurTree].SuccessDial;
            curBaseN = CurTree;
            Query_respAudio.Clear();
            for (int a = 0; a < QueryBase[CurTree].theResponse.Length; a++)
            {
                if (ExplorationCounter >= QueryBase[CurTree].reqExpl)
                    Query_respAudio.Add(npcResponses[QueryBase[CurTree].theResponse[a]]);
            }
            if (QueryBase[CurTree].ResponseisAudio)
            {
                Query_WAudio.Clear();
                for (int a = 0; a < QueryBase[CurTree].theQuestion.Length; a++)
                {
                    if (ExplorationCounter >= QueryBase[CurTree].reqExpl)
                        Query_WAudio.Add(WyattResponses[QueryBase[CurTree].theQuestion[a]]);
                }
            }
            Query_Wqueries.Clear();
            for (int a = 0; a < QueryBase[CurTree].furtherDialN.Length; a++)
            {
                Query_Wqueries.Add(QueryBase[QueryBase[CurTree].furtherDialN[a]].theQuestionString);
            }
        } 
    }

    void EndNPCDialogue()
    {
        dialogueOn = false;
        povcam.enabled = false;
        maincam.enabled = true;
        if (playCSonEnd != null)
        {
            playCSonEnd.GetComponent<cutscene>().InitiateScene();
        }
        else
            playerObj.GetComponent<player_stats>().myanim.SetBool("GamePlayActive", true);
    }

    void OnGUI()
    {
        GUI.skin = myskin;
        if (dialogueOn)
        {
            if (ResponseList.Count > 0)
            {
                for (int a = 0; a < Query_Wqueries.Count; a++)
                {
                    if (GUI.Button(new Rect(Screen.width/2 + 150, Screen.height/2 - 210 + a*70, 300,60),Query_Wqueries[a]))
                    {
                        ResponseList.Add(a);
                        StartCoroutine(UpdateQuery());
                    }
                }

                if (GUI.Button(new Rect(Screen.width/2 + 150, Screen.height/2 - 210 + 70 * Query_Wqueries.Count, 300, 60),"That thing you said that time..."))
                {
                    ResponseList.RemoveAt(ResponseList.Count - 1);
                    StartCoroutine(UpdateQuery());
                }
            }                                                                           
            if (!LockedDialogue)
            {
                if (GUI.Button(new Rect(), "Back"))
                {
                    Deactivate();
                }
            }
        }
    }
}
