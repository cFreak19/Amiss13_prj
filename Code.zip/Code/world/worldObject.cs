﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

public class worldObject : MonoBehaviour
{
    private string ObjectName, ObjectDescription;
    private GameObject playerObj, tarFocObj;
    public float viewRange;
    public bool selected = false;
    public bool isSkinnedRend = false;
    public bool isMouseFree = false;

    public void InfD()
    {
        if (GetComponent<interactable>())
            GetComponent<interactable>().InfPrompt();
        else if (GetComponent<puzzleTrigger>())
            GetComponent<puzzleTrigger>().OnInspect();
    }

    public float getHitRatio()
    {
        if (GetComponent<automated>())
        {
            return GetComponent<automated>().GetHitR();
        }
        else
            return 0;
    }

    public string OnInspect()
    {
        return ObjectDescription;
    }
    public Transform getTr()
    {
        return transform;
    }
    public string OnGaze()
    {
        return ObjectName;
    }

    void Start()
    {
        playerObj = GameObject.Find("Player_Object");
        tarFocObj = GameObject.Find("targetthingy");
        if (GetComponent<interactable>())
        {
            ObjectName = GetComponent<interactable>().GObjectName;
            ObjectDescription = GetComponent<interactable>().ObserveMsg;
        }
    }

    void Update()
    {
        if (isMouseFree)
        {
            float myDistance = Vector3.Distance(tarFocObj.transform.position, transform.position);
            if (myDistance < viewRange)
                playerObj.GetComponent<targetingSystem>().AddInRange(gameObject);
            else
                playerObj.GetComponent<targetingSystem>().RemoveFromRange(gameObject);
        }
    }

    public void OnUse()
    {
        if (Vector3.Distance(tarFocObj.transform.position, transform.position) < 4f)
        {
            if (GetComponent<povNPC>())
                GetComponent<povNPC>().Activate();
            else if (GetComponent<interactable>())
                GetComponent<interactable>().Use();
            //else if (GetComponent<cutscene>())
            //    GetComponent<cutscene>().InitiateScene();
            else if (GetComponent<SingleCommentTrig>())
                GetComponent<SingleCommentTrig>().Use();
            else if (GetComponent<puzzleTrigger>())
                GetComponent<puzzleTrigger>().Use();
        }
        else
        {
            InfD();
        }
    }

    public void SelectThisOne()
    {
        Debug.Log("selecting: " + gameObject.name);
        tarFocObj.GetComponent<CinemachineTargetGroup>().m_Targets[1].target = transform;
        selected = true;
    }

    public void UnSelectThisOne()
    {
        selected = false;
    }
}
