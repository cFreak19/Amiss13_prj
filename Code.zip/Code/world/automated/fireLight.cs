﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class fireLight : MonoBehaviour {
    public float midIntensity, highIntensity;

	// Use this for initialization
	void Start () {
		InvokeRepeating("Rotation",0.2F,0.2F);
	}
	
    void Rotation()
    {
        int dice = Random.Range(0, 1);
        if (dice == 1)
            GetComponent<Light>().intensity = midIntensity;
        else
            GetComponent<Light>().intensity = highIntensity;
    }

	// Update is called once per frame
	void Update () {
		
	}
}
