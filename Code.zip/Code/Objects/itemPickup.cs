﻿using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;

public class itemPickup : interactable
{
    public List<invitem> myitem = new List<invitem>();
    public bool LvreqOn, upgradeweapon;
    public int reqLv = 0;
    public bool storyprogression, playCutscene, taskinc, warp, unravel, onetime, singleRandomize, dialBox;
    public int surplusRew, xpRew;
    private bool used = false;
    private bool unraveled = false;
    public AudioClip destroySound, hitSound;
    public int maxLootAmount;
    private List<GameObject> toDisable = new List<GameObject>();

    public List<GameObject> ToDisable
    {
        get
        {
            return toDisable;
        }

        set
        {
            toDisable = value;
        }
    }

    // Use this for initialization
    void Start()
    {
        plObj = GameObject.Find("Player_Object");
        //worldObj = GameObject.Find("UI_MessagePanel");
    }

    public override void GetHit(int dinput)
    {
        ChealthP -= dinput;
        if (ChealthP <= 0)
        {
            GetComponent<BoxCollider>().enabled = false;
            GetComponent<AudioSource>().clip = destroySound;
            GetComponent<AudioSource>().Play();
            int mylam = UnityEngine.Random.Range(0, maxLootAmount);
            for (int a = 0; a < mylam; a++)
                GetComponent<Lootable>().BlurpLoot();
            Destroy(transform.gameObject, destroySound.length * 60);
        }
        else
        {
            GetComponent<AudioSource>().clip = hitSound;
            GetComponent<AudioSource>().Play();
        }
    }

    public override void InfPrompt()
    {
        worldObj.transform.Find("MessageText").gameObject.GetComponent<Text>().text = ObserveMsg;
        worldObj.transform.Find("Text").gameObject.GetComponent<Text>().text = GObjectName;
        worldObj.SetActive(true);
        if (!unraveled)
            if (unravel)
            {
                //GameObject.Find("SteamManager").GetComponent<steamMethod>().UpAchiCount("Unravel");
                unraveled = true;
            }
    }

    public override void Use()
    {
        worldObj.transform.Find("MessageText").gameObject.GetComponent<Text>().text = ObserveMsg;
        worldObj.transform.Find("Text").gameObject.GetComponent<Text>().text = GObjectName;
        if ((!used && LvreqOn && (plObj.GetComponent<player_stats>().StoryC >= reqLv)) || (!LvreqOn && !used))
        {
            if (onetime)
            {
                GetComponent<BoxCollider>().enabled = false;
                used = true;
            }
            if ((unravel) && (!unraveled))
            {
                //if (unravel)
                    //GameObject.FindGameObjectWithTag("GameController").GetComponent<steamMethod>().UpAchiCount("Unravel");
                unraveled = true;
            }
            for (int a = 0; a < myitem.Count; a++)
                plObj.GetComponent<InvController>().AcquireItem(myitem[a]);
            if (storyprogression)
                plObj.GetComponent<player_stats>().StoryC++;
            if (playCutscene)
            {
                GetComponent<cutscene>().InitiateScene();
            }
            if (upgradeweapon)
            {
                GetComponent<WeaponUpgrade>().Upgrade();
            }
            if (taskinc)
            {
                GameObject.FindGameObjectWithTag("GameController").GetComponent<WayBase>().TaskIncrement(warp);
            }
            plObj.GetComponent<player_stats>().myActiveProfile.SurplusPt += surplusRew;
            plObj.GetComponent<player_stats>().myActiveProfile.Experience += xpRew;
            if (dialBox)
                InfPrompt();
            if (DestroyOnUse)
            {
                GameObject.Find("targetthingy").GetComponent<targetFocus>().RemoveCur();
                //Destroy(this.gameObject);
            }
        }
        else
        {
            if (onetime)
            {
                GetComponent<BoxCollider>().enabled = false;
                used = true;
            }
            if ((unravel) && (!unraveled))
            {
                //if (unravel)
                //    GameObject.FindGameObjectWithTag("GameController").GetComponent<steamMethod>().UpAchiCount("Unravel");
                unraveled = true;
            }
            for (int a = 0; a < myitem.Count; a++)
                plObj.GetComponent<InvController>().AcquireItem(myitem[a]);
            if (storyprogression)
                plObj.GetComponent<player_stats>().StoryC++;
            if (playCutscene)
            {
                GetComponent<cutscene>().InitiateScene();
            }
            if (upgradeweapon)
            {
                GetComponent<WeaponUpgrade>().Upgrade();
            }
            if (taskinc)
            {
                GameObject.FindGameObjectWithTag("GameController").GetComponent<WayBase>().TaskIncrement(warp);
            }
            plObj.GetComponent<player_stats>().myActiveProfile.SurplusPt += surplusRew;
            plObj.GetComponent<player_stats>().myActiveProfile.Experience += xpRew;
            if (dialBox)
                InfPrompt();
            if (DestroyOnUse)
            {
                GameObject.Find("targetthingy").GetComponent<targetFocus>().RemoveCur();
                //Destroy(this.gameObject, 0.3f);
            }
        }
    }
    public override void InfDisplay(GameObject DispAnchor)
    {
        DispAnchor.GetComponent<Text>().text = GObjectName;
    }
}
