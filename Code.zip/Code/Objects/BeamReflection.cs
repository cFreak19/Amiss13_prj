﻿using UnityEngine;

public class BeamReflection : MonoBehaviour
{
    private Vector3 reflectionDir = Vector3.zero;
    private Vector3 Objdirection = Vector3.zero;
    private Vector3 Incdirection = Vector3.zero;
    private Vector3 reflectionPos = Vector3.zero;
    private Vector3 pointofImpact = Vector3.zero;
    public GameObject dirIndicator, plObject, staticTarget;
    private int travelstage = 0;
    public float BrightnessLevel, reflectionDisttoCenter;
    private bool BeamProgressing = false;
    private bool takeCosineX, takeCosineY, takeCosineZ;
    public bool ReflRelative = true;
    public bool cutsceneTrigger;
    public float triggerDistance;
    public bool breakOnImpact = false;
    public AudioClip breakSound;


    void Start()
    {
        Objdirection = (dirIndicator.transform.position - transform.position).normalized * (plObject.transform.position - transform.position).magnitude;
        gameObject.AddComponent<AudioSource>();
        GetComponent<AudioSource>().clip = breakSound;
        plObject = GameObject.Find("Player_Object");
        EndBeam();
    }


    public void EndBeam()
    {
        BeamProgressing = false;
        travelstage = 0;
        GetComponent<LineRenderer>().SetPosition(0, transform.position);
        GetComponent<LineRenderer>().SetPosition(1, transform.position);
        GetComponent<LineRenderer>().SetPosition(2, transform.position);
    }

    Vector3 getReflection(Vector3 incoming)
    {
        float theX, theY, theZ;
        Objdirection = (dirIndicator.transform.position - pointofImpact).normalized * (plObject.transform.position - pointofImpact).magnitude;
        float angbetween = Vector3.Angle(incoming - transform.position, Objdirection);
        Vector3 medPos = transform.position + Objdirection.normalized * ((incoming - transform.position).magnitude * Mathf.Cos(angbetween));

        theX = medPos.x * 2 - incoming.x;
        theY = medPos.y * 2 - incoming.y;
        theZ = medPos.z * 2 - incoming.z;

        return new Vector3(theX, theY, theZ);
    }

    public void DrawBeamPath(Vector3 targetedPoint)
    {
        if (!GetComponent<LineRenderer>().enabled)
            GetComponent<LineRenderer>().enabled = true;
        pointofImpact = targetedPoint;
        Vector3 raysourcepos = plObject.transform.position;
        Incdirection = raysourcepos - transform.position;
        //Vector3 medianPos = (dirIndicator.transform.position - targetedPoint).normalized * Incdirection.magnitude;
        reflectionPos = getReflection(raysourcepos);
        if (!BeamProgressing)
        {
            if (ReflRelative)
                reflectionPos = getReflection(raysourcepos);
            else
                reflectionPos = staticTarget.transform.position;
            reflectionDir = reflectionPos - transform.position;
            GetComponent<LineRenderer>().SetPosition(0, raysourcepos);
            GetComponent<LineRenderer>().SetPosition(1, targetedPoint);
            GetComponent<LineRenderer>().SetPosition(2, reflectionPos);
        }
    }

    public void StartBeam()
    {
        BeamProgressing = true;
    }

    void Update()
    {
        if (BeamProgressing)
            BeamProgress();

        if (BeamProgressing && cutsceneTrigger && (Vector3.Distance(transform.position, plObject.transform.position) < triggerDistance))
        {
            EndBeam();
            GetComponent<cutscene>().InitiateScene();
        }

    }

    void OnTriggerEnter(Collider collision)
    {
        if (breakOnImpact && (BeamProgressing) && (travelstage > 0) && (collision.gameObject.tag == "Player"))
        {
            GetComponent<Rigidbody>().AddExplosionForce(4, transform.position, 4);
            GetComponent<AudioSource>().Play();
            EndBeam();
        }
    }



    void BeamProgress()
    {
        RaycastHit beamhit;

        if (travelstage == 0)
        {
            reflectionDisttoCenter = (plObject.transform.position - transform.position).magnitude;
            plObject.transform.position += (transform.position - plObject.transform.position).normalized * BrightnessLevel;
            if (Vector3.Distance(transform.position, plObject.transform.position) <= reflectionDisttoCenter)
            {
                //plObject.transform.position = transform.position + reflectionDir.normalized * reflectionDisttoCenter;
                travelstage++;
                plObject.transform.gameObject.GetComponent<Rigidbody>().AddForce(reflectionDir.normalized * BrightnessLevel, ForceMode.Impulse);
            }
        }
        else
        {
            if (!Physics.Raycast(plObject.transform.position, reflectionDir, out beamhit, 3))
                plObject.transform.position += reflectionDir.normalized * BrightnessLevel / 2;
            else
            {
                if ((beamhit.transform.gameObject != this.gameObject) && (beamhit.transform.gameObject.tag == "Bright"))
                {
                    beamhit.transform.gameObject.GetComponent<BeamReflection>().DrawBeamPath(pointofImpact);
                    plObject.GetComponent<player_stats>().beamselection = beamhit.transform.gameObject;
                    EndBeam();
                }
            }
        }

    }


}
