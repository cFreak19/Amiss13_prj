﻿using UnityEngine;
using System.Collections;

public class gate : MonoBehaviour {
    public string boolName;
    private bool startingBool;

    public int StoryReq;
                                     

    public void Trigger(int curStoryC)
    {
        if (curStoryC >= StoryReq)
            StartCoroutine(OpenUp());
    }

    public void GameplayTrigger()
    {      
        startingBool = !startingBool;
        GetComponent<Animator>().SetBool(boolName, startingBool);
        StartCoroutine(CheckStatus());
    }

    IEnumerator OpenUp()
    {
        yield return new WaitForSeconds(0.1F);
        startingBool = !startingBool;
        GetComponent<Animator>().SetBool(boolName, startingBool);
        StartCoroutine(CheckStatus());
    }

    IEnumerator CheckStatus()
    {
        yield return new WaitForSeconds(6F);
        if (startingBool == true)
        {
            StartCoroutine(Normalize());
        }
    }

    IEnumerator Normalize()
    {
        yield return new WaitForSeconds(0.3F);
        startingBool = false;
        GetComponent<Animator>().SetBool(boolName, false);
        CancelInvoke();
    }

	// Use this for initialization
	void Start () {
        startingBool = GetComponent<Animator>().GetBool(boolName);
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
