﻿using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;
using System;

public class tutorialPickable : interactable {
    public bool preset, progression, seen, getAComment, unravel, unraveled;
    public string Message;
    public int CommentNumber;
    public List<GameObject> Obstacles = new List<GameObject>();
    public List<GameObject> Enables = new List<GameObject>();

    void Start()
    {
        plObj = GameObject.Find("Player_Object");
    }

    public override void GetHit(int dinput)
    {

    }

    public override void Use()
    {
        worldObj.SetActive(true);
        if (progression)
        {
            plObj.GetComponent<player_stats>().StoryC++;
            //if (!unraveled)
            //    if (unravel)
            //        GameObject.Find("gameController").GetComponent<steamMethod>().UpAchiCount("Unravel");
        }

        if (getAComment)
        {
            GameObject.Find("In-gameSpeechBubble").GetComponent<StorySpeech>().Comment(CommentNumber);
        }

        for (int a = 0; a < Obstacles.Count; a++)
        {
            Obstacles[a].SetActive(false);
        }
        for (int a = 0; a < Enables.Count; a++)
        {
            Enables[a].SetActive(true);
        }
        GameObject.Find("targetthingy").GetComponent<targetFocus>().RemoveCur();
        //Destroy(gameObject);
    }

    public override void InfPrompt()
    {
        worldObj.SetActive(true);
        if (getAComment)
        {
            GameObject.Find("In-gameSpeechBubble").GetComponent<StorySpeech>().Comment(CommentNumber);
        }
        //if (!unraveled)
        //   if (unravel)
        //       GameObject.Find("gameController").GetComponent<steamMethod>().UpAchiCount("Unravel");
        if (progression)
            plObj.GetComponent<player_stats>().StoryC++;
        for (int a = 0; a < Obstacles.Count; a++)
        {
            Obstacles[a].SetActive(false);
        }
        for (int a = 0; a < Enables.Count; a++)
        {
            Enables[a].SetActive(true);
        }
        GetComponent<BoxCollider>().enabled = false;
        GameObject.Find("targetthingy").GetComponent<targetFocus>().RemoveCur();
        //Destroy(gameObject);
    }

    public override void InfDisplay(GameObject DispAnchor)
    {
        DispAnchor.GetComponent<Text>().text = GObjectName;
    }
}
