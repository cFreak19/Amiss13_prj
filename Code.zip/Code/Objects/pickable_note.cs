﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System;

public class pickable_note : interactable {
    public bool preset, progression, seen, unravel,unraveled, comment, notify, onetime;
    public string Message;
    private GameObject plObj, worldObj;
    public bool DestroyOnUse;
    public AudioClip hitSound, destroySound;
    public int maxLootAmount;

    public override void GetHit(int dinput)
    {
        ChealthP -= dinput;

        if (ChealthP <= 0)
        {
            GetComponent<BoxCollider>().enabled = false;
            GetComponent<AudioSource>().clip = destroySound;
            GetComponent<AudioSource>().Play();
            int mylam = UnityEngine.Random.Range(0, maxLootAmount);
            for (int a = 0; a < mylam; a++)
                GetComponent<Lootable>().BlurpLoot();
            Destroy(transform.gameObject, destroySound.length * 20 * Time.deltaTime);
        }
        else
        {
            GetComponent<AudioSource>().clip = hitSound;
            GetComponent<AudioSource>().Play();
        }
    }
    void Start()
    {
        plObj = GameObject.Find("Player_Object");
        worldObj = GameObject.Find("UI_MessagePanel"); 
    }
    
	public override void Use()
    {
        if (preset)
        { 
            worldObj.SetActive(true);
        }
        else
        {
            if (!seen)
            {
                if (progression)
                    plObj.GetComponent<player_stats>().StoryC++;
                if (onetime)
                    seen = true;
                //if (unraveled)
                //    if (unravel)
                //        GameObject.Find("SteamManager").GetComponent<steamMethod>().UpAchiCount("Unravel");
                if (comment)
                    GetComponent<SingleCommentTrig>().Use();
            }
            if (notify)
            {
                worldObj.SetActive(true);
                worldObj.transform.Find("MessageText").GetComponent<Text>().text = ObserveMsg;
            }
        }
        if (DestroyOnUse)
            Destroy(this.gameObject);
    }

    public override void InfPrompt()
    {
        if (!seen)
        {
            if (progression)
                plObj.GetComponent<player_stats>().StoryC++;
            if (onetime)
                seen = true;
            //if (unraveled)
            //    if (unravel)
            //        GameObject.Find("SteamManager").GetComponent<steamMethod>().UpAchiCount("Unravel");
            if (comment)
                GetComponent<SingleCommentTrig>().Use();
        }
        if (notify)
        {
            worldObj.SetActive(true);
            worldObj.transform.Find("MessageText").GetComponent<Text>().text = ObserveMsg;
        }
    }

    public override void InfDisplay(GameObject DispAnchor)
    {
        DispAnchor.GetComponent<Text>().text = GObjectName;
    }
}
