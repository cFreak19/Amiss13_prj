﻿using UnityEngine;
using System.Collections;

public abstract class interactable : MonoBehaviour {
    public string GObjectName, ObserveMsg;
    public bool PhysicsApplied, Destroyable, animate; //Knockback and bounce applied
    public int MhealthP = 1;
    public int ChealthP;
    public GameObject plObj, worldObj;
    public bool DestroyOnUse;


    // Use this for initialization
    void Start () {
        ChealthP = MhealthP;
	}

    public abstract void GetHit(int dinput);



	// Update is called once per frame
	void Update () {
	
	}
    public abstract void Use();
    public abstract void InfPrompt();
    public abstract void InfDisplay(GameObject DispAnchor);
}
