﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class storyObstacle : MonoBehaviour {
    public GameObject plObj;
    public int storystageReq;
    public GameObject[] activatedObjects;

	// Use this for initialization
	void Start () {
        plObj = GameObject.Find("Player_Object");
	}
	
	// Update is called once per frame
	void Update () {
        if ((plObj.GetComponent<player_stats>().StoryC >= storystageReq)&&(GetComponent<BoxCollider>().enabled))
        {
            GetComponent<BoxCollider>().enabled = false;
            GetComponent<ParticleSystem>().Stop();
            if (activatedObjects.Length > 0)
            {
                for (int a= 0; a < activatedObjects.Length; a++)
                {
                    activatedObjects[a].SetActive(true);
                }
            }
        }
	}
}
