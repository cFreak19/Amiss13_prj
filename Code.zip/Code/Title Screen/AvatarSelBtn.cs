﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AvatarSelBtn : MonoBehaviour {
	public int AvatarNo;
	public GameObject MenuObj;

	public void SelAvatar()
	{
		MenuObj.GetComponent<GameMainMenu> ().SelectAvatar (AvatarNo);
	}
}
