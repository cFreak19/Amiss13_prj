﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ProfileselectionList : MonoBehaviour {
	public GameObject ButtonPref, ListParent, gameCoreObj;
	List<GameObject> ProfileBtnsList = new List<GameObject>();

	// Use this for initialization
	public void ResetAll()
	{
		for (int a = 0; a < ProfileBtnsList.Count; a++) {
			Destroy (ProfileBtnsList [a]);
		}
        ProfileBtnsList.Clear();
	}

    void OnEnable()
    {
        RefreshList();
    }

    public void RefreshList()
	{
        ResetAll();
        List<string> myUsers = gameCoreObj.GetComponent<UProfiler>().getUserNames();
		for (int a = 0; a < myUsers.Count; a++) {
            GameObject nextBtn = Instantiate(ButtonPref, ListParent.transform) as GameObject;
            nextBtn.GetComponent<ProfileSelBtn>().ProfileNo = a;
            nextBtn.GetComponent<ProfileSelBtn>().parentObj = GameObject.Find("titleInitiator");
            nextBtn.transform.Find("ProfileNamenLv").GetComponent<Text>().text = myUsers[a];
            nextBtn.GetComponent<RectTransform>().localPosition = new Vector2(142,-50 - 100 * a);
            ProfileBtnsList.Add(nextBtn);
		}
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
