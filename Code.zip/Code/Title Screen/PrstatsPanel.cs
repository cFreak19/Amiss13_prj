﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PrstatsPanel : MonoBehaviour {
    public GameObject gameCore;
    public UserProfile myprofile = new UserProfile();
    public Text[] statFields = new Text[9];
    public RawImage AvatarDisplay;


    

    void OnEnable()
    {
        myprofile = gameCore.GetComponent<UProfiler>().ActiveStats;
        if (myprofile.AvatarNo > -1)
            AvatarDisplay.texture = gameCore.GetComponent<UProfiler>().AvaBase[myprofile.AvatarNo];
        statFields[0].text = myprofile.UserName;
        statFields[1].text = "Act " + (myprofile.autosave.ActNo+1).ToString()+ " - " +gameCore.GetComponent<WayBase>().ActsList[myprofile.autosave.ActNo].ActName;
        statFields[2].text = "Chapter " + (myprofile.autosave.ChapterNo+1).ToString() + " - " + gameCore.GetComponent<WayBase>().ActsList[myprofile.autosave.ActNo].chapterList[myprofile.autosave.ChapterNo].ChName;
        statFields[3].text = "Character Level: " + myprofile.Level.ToString();
        statFields[4].text = "Character Surplus: " + myprofile.SurplusPt.ToString();
        statFields[6].text = "Surplus: " + myprofile.SurplusPt.ToString();
    }

}
