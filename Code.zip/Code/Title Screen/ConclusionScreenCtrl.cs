﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ConclusionScreenCtrl : MonoBehaviour {
	public string TitleMapName;
	public GameObject tandlightning;
    private float curIntensityL, maxIntensityL, intModRate, timeUntilNext;

	// Use this for initialization
	void Start ()
    {
        maxIntensityL = 145;
        curIntensityL = 145;
        intModRate = 0.015f;
        tandlightning.GetComponent<Light>().intensity = 0;
        timeUntilNext = UnityEngine.Random.Range(14.0f, 20.0f);
        Time.timeScale = 1f;
        StartCoroutine(Thunderandlightning());
    }

	IEnumerator Thunderandlightning ()
	{
        yield return new WaitForSeconds(timeUntilNext);
        tandlightning.GetComponent<AudioSource>().Play();
        curIntensityL = maxIntensityL;
        intModRate = 0.015f;
        timeUntilNext = UnityEngine.Random.Range(14.0f, 20.0f);
        InvokeRepeating("BacktoNormal", 0.015f, 0.015f);
    }

	void BacktoNormal()
	{
        if (curIntensityL > 0)
        {
            curIntensityL -= intModRate;
            intModRate += 0.01f;
        }
        else
        {
            StartCoroutine(Thunderandlightning());
            CancelInvoke();
        }
        tandlightning.GetComponent<Light>().intensity = curIntensityL;
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void EndDemo()
	{
		Application.Quit ();
	}

	public void BackToTitle()
	{
		SceneManager.LoadScene (TitleMapName);
	}
}
