﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using A13_theCurse_GameConst;
 


    public class GameMainMenu : MonoBehaviour
    {
        private bool NoUserProfiles = true;
        [SerializeField]private GameObject mainGameObj;
        public GameObject[] menuelements = new GameObject[1];
        public GUISkin thecodesourceskin;
        private int PanelNo = -2;
        public GameObject CameraObj; 
        [SerializeField] private Vector3[] menuLocations = new Vector3[5];
        [SerializeField] private Vector3[] menuRotations = new Vector3[5];
        private Vector3 targetLoc, targetRot;
        public Texture2D steamAvatar;
        public string VersionNotes, steamUN;
        public GameObject rewindMenu;

        [Header("Profile Details")]
        [SerializeField] private string userName = "";
        private int userLevel;
        private int userAvatar = -2;
        private int totalSurplus;

        [Header("Cosmetic Database Display Elements")]
        public List<SkinSet> CharSkins = new List<SkinSet>();
        public List<SkinSet> DagSkins = new List<SkinSet>();
        public List<SkinSet> CrBSkins = new List<SkinSet>();
        public List<SkinSet> TrchSkins = new List<SkinSet>();

        public GameObject previewDispObject, previewDispObject2;

        [Header("Referenced External Title Screen Elements")]
        public GameObject ProfileCrPanel, ProfileSlPanel, SkinsPanel, TitlePanel, OptionsPanel;
        public GameObject OnlinePlayPanel, ProfileStatsPanel;
        public GameObject CharSkinDPanel, DagSkinDPanel, CrBSkinDPanel, TrchSkinDPanel;
        public GameObject VenturePanel, SteamConPanel, ProfileNInpField, AvaPrevObj;

        private int prevCSkinNumber, prevDagSkinNumber, prevCbSkinNumber, prevTSkinNumber;
        private int[] SkinLayout = new int[4];
        public bool OnSteam;
        public bool AndVer;

        // Use this for initialization
        void Start()
        {
            mainGameObj = GameObject.FindGameObjectWithTag("GameController");
            Screen.SetResolution(1920, 1080, true);
            SkinLayout[0] = 0;
            SkinLayout[1] = 0;
            SkinLayout[2] = 0;
            SkinLayout[3] = 0;
            SplitSkins(mainGameObj.GetComponent<UnlockableBase>().GetSkinList());
            ResetPanels();
          if ((!AndVer)&&(OnSteam)&&(!SteamManager.Initialized))
            SteamConPanel.SetActive(true);
          else
            StartCoroutine(StartGameSession());
        }

    public void PlayOffline()
    {
        OnSteam = false;
        StartCoroutine(StartGameSession());
    }

     public void ShowConclusion()
     {
        ResetPanels();
        OnlineMode();
        //GameObject.Find("gameController").GetComponent<SteamNetwork>().ReturnLobbyView();
     }

        public void SteamChecked()
        {

        }

        public void VisitNewsBlog()
        {
        if (OnSteam)
            mainGameObj.GetComponent<steamMethod>().WebsiteOnOverlay();
        }

        public void SelectProfileByIndex(int userIndex)
        {
            mainGameObj.GetComponent<UProfiler>().LoadUser(userIndex);
            ResetPanels();
            PanelNo = 1;
            SetCameraAngle();
        TitlePanel.SetActive(true);
            if (OnSteam)
                ProfileStatsPanel.SetActive(true);
        }

        void ResetPanels()
        {
            OptionsPanel.SetActive(false);
            TitlePanel.SetActive(false);
            ProfileCrPanel.SetActive(false);
            ProfileSlPanel.SetActive(false);
            SkinsPanel.SetActive(false);
            ProfileStatsPanel.SetActive(false);
            VenturePanel.SetActive(false);
            SteamConPanel.SetActive(false);
        	OnlinePlayPanel.SetActive(false);
        }

	public void  ProfileCreation()
        {
            ResetPanels();
            PanelNo = -2;
            SetCameraAngle();
            ProfileCrPanel.SetActive(true);
        }

        void InvokeCMovement()
        {
            bool firstDone = false;
            if (Vector3.Distance(CameraObj.transform.localPosition, targetLoc) > 4f)
            {
                CameraObj.transform.localPosition += (targetLoc - CameraObj.transform.localPosition).normalized;
            }
            else
                firstDone = true;
            bool secondDone = false;

            if (Quaternion.Angle(Quaternion.Euler(CameraObj.transform.rotation.eulerAngles), Quaternion.Euler(targetRot)) > 15f)
            {
                CameraObj.transform.Rotate((targetRot - CameraObj.transform.rotation.eulerAngles).normalized);
            }
            else
                secondDone = true;
            if (firstDone && secondDone)
            {
                CameraObj.transform.localPosition = targetLoc;
                CameraObj.transform.localRotation = Quaternion.Euler(targetRot);
                CancelInvoke();
            }
        }

        void SetCameraAngle()
        {
            if (PanelNo < 1)
            {
                CancelInvoke();
                targetLoc = menuLocations[0];
                targetRot = menuRotations[0];
                InvokeRepeating("InvokeCMovement", 0.05f, 0.05f);
            }
            else if (PanelNo == 1)
            {
                CancelInvoke();
                targetLoc = menuLocations[1];
                targetRot = menuRotations[1];
                InvokeRepeating("InvokeCMovement", 0.01f, 0.01f);
            }
            else if (PanelNo == 2)
            {
                CancelInvoke();
                targetLoc = menuLocations[2];
                targetRot = menuRotations[2];
                InvokeRepeating("InvokeCMovement", 0.01f, 0.01f);
            }
            else if (PanelNo == 3)
            {
                CancelInvoke();
                targetLoc = menuLocations[3];
                targetRot = menuRotations[3];
                InvokeRepeating("InvokeCMovement", 0.01f, 0.01f);
            }
            else if (PanelNo == 4)
            {
                CancelInvoke();
                targetLoc = menuLocations[4];
                targetRot = menuRotations[4];
                InvokeRepeating("InvokeCMovement", 0.01f, 0.01f);
            }
        }

        public void DeleteProfile()
        {
        mainGameObj.GetComponent<UProfiler>().DeleteProfile(userName);
        ProfileSlPanel.GetComponent<ProfileselectionList>().RefreshList();
        userName = "";
        userLevel = 0;
        userAvatar = 0;
        ResetPanels();
        PanelNo = -1;
        SetCameraAngle();
        SwitchProfile();
        }

        public void ConnectedCall()
        {
            StartCoroutine(StartGameSession());
        }

        IEnumerator StartGameSession()
        {
            mainGameObj.GetComponent<UProfiler>().LoadData();
            yield return !mainGameObj.GetComponent<UProfiler>().isLoading;
            int ProfileCount;
            yield return ProfileCount = mainGameObj.GetComponent<UProfiler>().getUserNames().Count;
            if (ProfileCount > 0)
                NoUserProfiles = false;
            else
                NoUserProfiles = true;
            ResetPanels();
            if (NoUserProfiles)
            {
                PanelNo = -2;
                SetCameraAngle();
                ProfileCreation();
            }
            else
            {
                PanelNo = -1;
                SetCameraAngle();
                ProfileSlPanel.SetActive(true);
            }
        }
        public void EndGame()
        {
            Application.Quit();
        }

        public void InitNewGame()
        {
            ResetPanels();
            StartCoroutine(NewGame());
        }

        public void InitResGame()
        {
            StartCoroutine(ResumeGame());
        }

        public IEnumerator NewGame()
        {
            ResetPanels();
            GetComponent<Animator>().SetBool("triggered", true);
            //mainGameObj.GetComponent<UProfiler>().ActiveStats.MakeFresh();
            PanelNo = -5;
            SetCameraAngle();
            menuelements[0].GetComponent<gate>().GameplayTrigger();
            yield return new WaitForSeconds(1.45F);
            mainGameObj.GetComponent<WayBase>().FreshSaveRun();
        }

        public IEnumerator ResumeGame()
        {
            ResetPanels();
            mainGameObj.GetComponent<UProfiler>().LoadProgress();
            GetComponent<Animator>().SetBool("triggered", true);
            menuelements[0].GetComponent<gate>().GameplayTrigger();
            yield return new WaitForSeconds(1.45F);
            mainGameObj.GetComponent<WayBase>().ResumeOldRun();
        }

        public void CreateFromSteamProfile()
        {
            ResetPanels();
            PanelNo = 1;
            NoUserProfiles = false;
            SetCameraAngle();
        if (OnSteam)
        {
            //mainGameObj.GetComponent<UProfiler>().SetSteamProfile();
            //mainGameObj.GetComponent<UProfiler>().LoadUser(GetComponent<steamMethod>().GetSteamUN());
            ProfileStatsPanel.SetActive(true);
        }
            TitlePanel.SetActive(true);
        }

    public void Options()
    {
        ResetPanels();
        PanelNo = 3;
        SetCameraAngle();
        OptionsPanel.SetActive(true);
    }

    public void ExtraContent()
    {
        ResetPanels();
        SetCharacterModel();
        PanelNo = 2;
        SkinsPanel.SetActive(true);
        SetCameraAngle();
        if (OnSteam)
            ProfileStatsPanel.SetActive(false);
    }


    public void BackTitle()
    {
        //if (OnSteam)
        //    GetComponent<SteamNetwork>().EndOM();
        PanelNo = 1;
            SetCameraAngle();
            ResetPanels();
        TitlePanel.SetActive(true);
    }

    public void SwitchProfile()
    {
        ResetPanels();
        if (NoUserProfiles)
        {
            PanelNo = -2;
            ProfileCrPanel.SetActive(true);
            SetCameraAngle();
        }
        else
        {
            PanelNo = -1;
            ProfileSlPanel.SetActive(true);
            SetCameraAngle();
        }
    }


    public void SetUserDetails(string uname, int ulevel, int uavatar)
    {
            userName = uname;
            userLevel = ulevel;
            userAvatar = uavatar;
            NoUserProfiles = false;
            PanelNo = 1;
            SplitSkins(mainGameObj.GetComponent<UnlockableBase>().GetSkinList());
            SetCameraAngle();
    }

        void SplitSkins(List<SkinSet> myskins)
        {
            CharSkins.Clear();
            DagSkins.Clear();
            CrBSkins.Clear();
            TrchSkins.Clear();
            for (int a = 0; a < myskins.Count; a++)
            {
                switch (myskins[a].ULtype)
                {
                    case GameConstants.Unlockable.CharSkin:
                        CharSkins.Add(myskins[a]);
                        break;
                    case GameConstants.Unlockable.DagSkin:
                        DagSkins.Add(myskins[a]);
                        break;
                    case GameConstants.Unlockable.CrBSkin:
                        CrBSkins.Add(myskins[a]);
                        break;
                    case GameConstants.Unlockable.TrchSkin:
                        TrchSkins.Add(myskins[a]);
                        break;
                    default:
                        break;
                }
            }
        }

        public void PurchaseCharSkin()
        {

            if (totalSurplus > CharSkins[prevCSkinNumber].UpdatedPrice)
            {
                totalSurplus -= CharSkins[prevCSkinNumber].UpdatedPrice;
                CharSkins[prevCSkinNumber].isUnlocked = true;
                mainGameObj.GetComponent<UProfiler>().UnlockSkin(CharSkins[prevCbSkinNumber].ULName);
            }
            GetComponent<UProfiler>().WriteData();
        }

        public void PurchaseDagSkin()
        {
            if (totalSurplus > DagSkins[prevDagSkinNumber].UpdatedPrice)
            {
                totalSurplus -= DagSkins[prevDagSkinNumber].UpdatedPrice;
                DagSkins[prevDagSkinNumber].isUnlocked = true;
                mainGameObj.GetComponent<UProfiler>().UnlockSkin(DagSkins[prevDagSkinNumber].ULName);
            }
            GetComponent<UProfiler>().WriteData();
        }

        public void PurchaseCrBSkin()
        {
            if (totalSurplus > CrBSkins[prevCbSkinNumber].UpdatedPrice)
            {
                totalSurplus -= CrBSkins[prevCbSkinNumber].UpdatedPrice;
                CrBSkins[prevCbSkinNumber].isUnlocked = true;
                mainGameObj.GetComponent<UProfiler>().UnlockSkin(CrBSkins[prevCbSkinNumber].ULName);
            }
            GetComponent<UProfiler>().WriteData();
        }

        public void PurchaseTSkin()
        {
            if (totalSurplus > TrchSkins[prevTSkinNumber].UpdatedPrice)
            {
                totalSurplus -= TrchSkins[prevTSkinNumber].UpdatedPrice;
                TrchSkins[prevTSkinNumber].isUnlocked = true;
                mainGameObj.GetComponent<UProfiler>().UnlockSkin(TrchSkins[prevTSkinNumber].ULName);
            }
            GetComponent<UProfiler>().WriteData();
        }

        void RefreshWepModels()
        {
            previewDispObject.transform.Find("dagger_meshes").Find("dagger_mesh1");
            SkinSet myskin = DagSkins[prevDagSkinNumber];
            previewDispObject.transform.Find("dagger_meshes").Find("dagger_mesh1").GetComponent<SkinnedMeshRenderer>().sharedMesh = myskin.FileMeshList[0];
            previewDispObject.transform.Find("dagger_meshes").Find("dagger_mesh1").GetComponent<SkinnedMeshRenderer>().materials[0].mainTexture = myskin.baseTexture;
            string isOwned = "";
            if (DagSkins[prevDagSkinNumber].isUnlocked)
                isOwned = "Yes";
            else
                isOwned = "No";
            DagSkinDPanel.transform.Find("SkinOwned").gameObject.GetComponent<Text>().text = "Owned: " + isOwned;
            if (isOwned == "No")
            {
                DagSkinDPanel.transform.Find("PurchaseBtn").gameObject.SetActive(true);
                DagSkinDPanel.transform.Find("SkinCostD").gameObject.GetComponent<Text>().text = "Skin Cost: " + DagSkins[prevDagSkinNumber].UpdatedPrice.ToString();
                if (DagSkins[prevCSkinNumber].hasScoreReq)
                    DagSkinDPanel.transform.Find("SkinReqD").gameObject.GetComponent<Text>().text = "Score Requirement: " + DagSkins[prevDagSkinNumber].ReqSc.ToString();
                else
                    DagSkinDPanel.transform.Find("SkinReqD").gameObject.GetComponent<Text>().text = "Score Requirement: N/A";
            }
            else
                DagSkinDPanel.transform.Find("PurchaseBtn").gameObject.SetActive(false);
            DagSkinDPanel.transform.Find("SkinNameD").gameObject.GetComponent<Text>().text = "Skin Name: " + DagSkins[prevDagSkinNumber].ULName;
            DagSkinDPanel.transform.Find("SkinDescD").gameObject.GetComponent<Text>().text = "Skin Description: " + DagSkins[prevDagSkinNumber].ULDescription;
            myskin = CrBSkins[prevCbSkinNumber];
            previewDispObject.transform.Find("crowbar_meshes").Find("crowbar_mesh1").GetComponent<SkinnedMeshRenderer>().sharedMesh = myskin.FileMeshList[0];
            previewDispObject.transform.Find("crowbar_meshes").Find("crowbar_mesh1").GetComponent<SkinnedMeshRenderer>().materials[0].mainTexture = myskin.baseTexture;
            isOwned = "";
            if (CrBSkins[prevCbSkinNumber].isUnlocked)
                isOwned = "Yes";
            else
                isOwned = "No";
            CrBSkinDPanel.transform.Find("SkinOwned").gameObject.GetComponent<Text>().text = "Owned: " + isOwned;
            if (isOwned == "No")
            {
                CrBSkinDPanel.transform.Find("PurchaseBtn").gameObject.SetActive(true);
                CrBSkinDPanel.transform.Find("SkinCostD").gameObject.GetComponent<Text>().text = "Skin Cost: " + CrBSkins[prevCbSkinNumber].UpdatedPrice.ToString();
                if (CrBSkins[prevCSkinNumber].hasScoreReq)
                    CrBSkinDPanel.transform.Find("SkinReqD").gameObject.GetComponent<Text>().text = "Score Requirement: " + CrBSkins[prevCbSkinNumber].ReqSc.ToString();
                else
                    CrBSkinDPanel.transform.Find("SkinReqD").gameObject.GetComponent<Text>().text = "Score Requirement: N/A";
            }
            else
                CrBSkinDPanel.transform.Find("PurchaseBtn").gameObject.SetActive(false);
            CrBSkinDPanel.transform.Find("SkinNameD").gameObject.GetComponent<Text>().text = "Skin Name: " + CrBSkins[prevCbSkinNumber].ULName;
            CrBSkinDPanel.transform.Find("SkinDescD").gameObject.GetComponent<Text>().text = "Skin Description: " + CrBSkins[prevCbSkinNumber].ULDescription;
            myskin = TrchSkins[prevTSkinNumber];
            previewDispObject.transform.Find("torch_meshes").Find("torch_mesh1").GetComponent<SkinnedMeshRenderer>().sharedMesh = myskin.FileMeshList[0];
            previewDispObject.transform.Find("torch_meshes").Find("torch_mesh1").GetComponent<SkinnedMeshRenderer>().materials[0].mainTexture = myskin.baseTexture;
            isOwned = "";
            if (TrchSkins[prevCbSkinNumber].isUnlocked)
                isOwned = "Yes";
            else
                isOwned = "No";
            TrchSkinDPanel.transform.Find("SkinOwned").gameObject.GetComponent<Text>().text = "Owned: " + isOwned;
            if (isOwned == "No")
            {
                TrchSkinDPanel.transform.Find("PurchaseBtn").gameObject.SetActive(true);
                TrchSkinDPanel.transform.Find("SkinCostD").gameObject.GetComponent<Text>().text = "Skin Cost: " + TrchSkins[prevTSkinNumber].UpdatedPrice.ToString();
                if (CrBSkins[prevCSkinNumber].hasScoreReq)
                    TrchSkinDPanel.transform.Find("SkinReqD").gameObject.GetComponent<Text>().text = "Score Requirement: " + TrchSkins[prevTSkinNumber].ReqSc.ToString();
                else
                    TrchSkinDPanel.transform.Find("SkinReqD").gameObject.GetComponent<Text>().text = "Score Requirement: N/A";
            }
            else
                TrchSkinDPanel.transform.Find("PurchaseBtn").gameObject.SetActive(false);
            TrchSkinDPanel.transform.Find("SkinNameD").gameObject.GetComponent<Text>().text = "Skin Name: " + TrchSkins[prevTSkinNumber].ULName;
            TrchSkinDPanel.transform.Find("SkinDescD").gameObject.GetComponent<Text>().text = "Skin Description: " + TrchSkins[prevTSkinNumber].ULDescription;
        }

        public void SetWepModels()
        {
            SkinLayout[1] = prevDagSkinNumber;
            SkinLayout[2] = prevCbSkinNumber;
            SkinLayout[3] = prevTSkinNumber;
            mainGameObj.GetComponent<WayBase>().MySkins[1] = DagSkins[SkinLayout[1]];
            mainGameObj.GetComponent<WayBase>().MySkins[2] = CrBSkins[SkinLayout[2]];
            mainGameObj.GetComponent<WayBase>().MySkins[3] = TrchSkins[SkinLayout[3]];
        }

        void RefreshCharacterModel()
        {
            SkinSet myskin = CharSkins[prevCSkinNumber];
            previewDispObject.transform.Find("wyatt_meshes").Find("wyatt_mesh1").GetComponent<SkinnedMeshRenderer>().sharedMesh = myskin.FileMeshList[0];
            previewDispObject.transform.Find("wyatt_meshes").Find("wyatt_mesh1").GetComponent<SkinnedMeshRenderer>().materials[0].mainTexture = myskin.baseTexture;
            Transform sec = previewDispObject.transform.Find("wyatt_meshes").Find("wyatt_mesh2");
            if (myskin.FileMeshList[1] != null)
            {
                sec.GetComponent<SkinnedMeshRenderer>().enabled = true;
                sec.GetComponent<SkinnedMeshRenderer>().sharedMesh = myskin.FileMeshList[1];
                sec.GetComponent<SkinnedMeshRenderer>().materials[0].mainTexture = myskin.baseTexture;
            }
            else
                sec.GetComponent<SkinnedMeshRenderer>().enabled = false;

            CharSkinDPanel.transform.Find("SkinNameD").gameObject.GetComponent<Text>().text = "Skin Name: " + CharSkins[prevCSkinNumber].ULName;
            CharSkinDPanel.transform.Find("SkinDescD").gameObject.GetComponent<Text>().text = "Skin Description: " + CharSkins[prevCSkinNumber].ULDescription;
            string isOwned = "";
            if (CharSkins[prevCSkinNumber].isUnlocked)
                isOwned = "Yes";
            else
                isOwned = "No";
            CharSkinDPanel.transform.Find("SkinOwned").gameObject.GetComponent<Text>().text = "Owned: " + isOwned;
            if (isOwned == "No")
            {
                CharSkinDPanel.transform.Find("PurchaseBtn").gameObject.SetActive(true);
                CharSkinDPanel.transform.Find("SkinCostD").gameObject.GetComponent<Text>().text = "Skin Cost: " + CharSkins[prevCSkinNumber].UpdatedPrice.ToString();
                if (CharSkins[prevCSkinNumber].hasScoreReq)
                    CharSkinDPanel.transform.Find("SkinReqD").gameObject.GetComponent<Text>().text = "Score Requirement: " + CharSkins[prevCSkinNumber].ReqSc.ToString();
                else
                    CharSkinDPanel.transform.Find("SkinReqD").gameObject.GetComponent<Text>().text = "Score Requirement: N/A";
            }
            else
                CharSkinDPanel.transform.Find("PurchaseBtn").gameObject.SetActive(false);
        }

        public void SetCharacterModel()
        {
            SkinLayout[0] = prevCSkinNumber;
            SkinSet myskin = CharSkins[prevCSkinNumber];
            previewDispObject.transform.Find("wyatt_meshes").Find("wyatt_mesh1").GetComponent<SkinnedMeshRenderer>().sharedMesh = myskin.FileMeshList[0];
            Transform sec = previewDispObject.transform.Find("wyatt_meshes").Find("wyatt_mesh2");
            if (myskin.FileMeshList[1] != null)
            {
                sec.GetComponent<SkinnedMeshRenderer>().enabled = true;
                sec.GetComponent<SkinnedMeshRenderer>().sharedMesh = myskin.FileMeshList[1];
                sec.GetComponent<SkinnedMeshRenderer>().materials[0].mainTexture = myskin.baseTexture;
            }
            else
                sec.GetComponent<SkinnedMeshRenderer>().enabled = false;
            previewDispObject.transform.Find("wyatt_meshes").Find("wyatt_mesh1").GetComponent<SkinnedMeshRenderer>().materials[0].mainTexture = myskin.baseTexture;
            previewDispObject2.transform.Find("wyatt_meshes").Find("wyatt_mesh1").GetComponent<SkinnedMeshRenderer>().sharedMesh = myskin.FileMeshList[0];
            sec = previewDispObject2.transform.Find("wyatt_meshes").Find("wyatt_mesh2");
            if (myskin.FileMeshList[1] != null)
            {
                sec.GetComponent<SkinnedMeshRenderer>().enabled = true;
                sec.GetComponent<SkinnedMeshRenderer>().sharedMesh = myskin.FileMeshList[1];
                sec.GetComponent<SkinnedMeshRenderer>().materials[0].mainTexture = myskin.baseTexture;
            }
            else
                sec.GetComponent<SkinnedMeshRenderer>().enabled = false;
            mainGameObj.GetComponent<WayBase>().MySkins[0] = myskin;
        }

        public void IncCharSkinSel()
        {
            prevCSkinNumber++;
            if (prevCSkinNumber >= CharSkins.Count)
                prevCSkinNumber %= CharSkins.Count;
            RefreshCharacterModel();
        }

        public void DecCharSkinSel()
        {

            if (prevDagSkinNumber > 0)
                prevDagSkinNumber--;
            else
                prevDagSkinNumber = DagSkins.Count - 2;
            RefreshCharacterModel();
        }

        public void SelectAvatar(int a)
        {
            userAvatar = a;
            AvaPrevObj.GetComponent<RawImage>().texture = mainGameObj.GetComponent<UProfiler>().AvaBase[a];
        }

        public void CreateNewProfile()
        {
            if (userAvatar >= 0)
            {
                userName = ProfileNInpField.GetComponent<InputField>().text;
                mainGameObj.GetComponent<UProfiler>().NewRegularUser(userAvatar, userName);
            PanelNo = 1;
            SetCameraAngle();
                mainGameObj.GetComponent<UProfiler>().LoadUser(userName);
                ResetPanels();
            if (OnSteam)
                ProfileStatsPanel.SetActive(true);
                TitlePanel.SetActive(true);
                NoUserProfiles = false;
            }
            else
                Debug.Log("Please select an avatar.");
        }

        public void IncDagSkinSel()
        {
            prevDagSkinNumber++;
            if (prevDagSkinNumber >= DagSkins.Count)
                prevDagSkinNumber %= DagSkins.Count;
            RefreshCharacterModel();
        }

        public void DecDagSkinSel()
        {

            if (prevDagSkinNumber > 0)
                prevDagSkinNumber--;
            else
                prevDagSkinNumber = DagSkins.Count - 1;
            RefreshCharacterModel();
        }

        public void IncCbSkinSel()
        {
            prevCbSkinNumber++;
            if (prevCbSkinNumber >= CrBSkins.Count)
                prevCbSkinNumber %= CrBSkins.Count;
            RefreshCharacterModel();
        }

        public void DecCbSkinSel()
        {
            if (prevCbSkinNumber > 0)
                prevCbSkinNumber--;
            else
                prevCbSkinNumber = CrBSkins.Count - 1;
            RefreshCharacterModel();
        }

        public void IncTSkinSel()
        {
            prevTSkinNumber++;
            if (prevTSkinNumber >= TrchSkins.Count)
                prevTSkinNumber %= TrchSkins.Count;
            RefreshCharacterModel();
        }

        public void DecTSkinSel()
        {

            if (prevTSkinNumber > 0)
                prevTSkinNumber--;
            else
                prevTSkinNumber = TrchSkins.Count - 1;
            RefreshCharacterModel();
        }

        public void OnlineMode()
        {
        //if (mainGameObj.GetComponent<UProfiler>().getActiveUserDetails().SteamLevel > 0)
        //{
            PanelNo = 4;
            ResetPanels();
            SetCameraAngle();
            OnlinePlayPanel.SetActive(true);
            //if (OnSteam)
                //GetComponent<SteamNetwork>().StartOM();
        //}
        }

        public void RewindPanel()
        {

        }


    }
