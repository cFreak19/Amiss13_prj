﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EndDemoScreen : MonoBehaviour {
	public string TitleMapName;
	public GameObject tandlightning;

	// Use this for initialization
	void Start () {
		InvokeRepeating ("Thunderandlightning", 5f, Random.Range (12.01f, 13.99f));
	}

	void Thunderandlightning ()
	{
		tandlightning.SetActive (true);
		StartCoroutine (BacktoNormal ());
	}

	IEnumerator BacktoNormal()
	{
		yield return new WaitForSeconds (0.5f);
		tandlightning.SetActive (false);
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void EndDemo()
	{
		Application.Quit ();
	}

	public void BackToTitle()
	{
		SceneManager.LoadScene (TitleMapName);
	}
}
