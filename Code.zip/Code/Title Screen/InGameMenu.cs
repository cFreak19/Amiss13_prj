﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class InGameMenu : MonoBehaviour {
    private int currentresponse = 0;
    private bool ExitPrompted = false;
    private bool TitlePrompted = false;
    private bool OnHold = false;
    public GameObject OptionsWorldObj,PromptObj;
    
   

    void Update()
    {
        if ((ExitPrompted)&&(currentresponse != 0)&&(OnHold))
        {
            PromptObj.gameObject.SetActive(false);
            ExitPrompted = false;
            OnHold = false;
            if (currentresponse == 2)
                Application.Quit();
            else
                currentresponse = 0;
        }

        if ((TitlePrompted)&&(currentresponse != 0)&&(OnHold))
        {
            PromptObj.gameObject.SetActive(false);
            TitlePrompted = false;
            OnHold = false;
            if (currentresponse == 2)
            {
                TitlePrompted = false;
                currentresponse = 0;
                GameObject.Find("gameController").GetComponent<WayBase>().ReturnTitleScreen();
            }
            else
            {
                currentresponse = 0;
            }
        }
    }

    public void AnswerPrompt(int response)
    {
        currentresponse = response;
    }

    

    public void Resume()
    {
        GameObject.Find("Player_Object").GetComponent<player_stats>().myanim.SetBool("GamePlayActive", true);
        //GameObject.Find("player_Object").GetComponent<FirstPersonController>().RemoveHold();
        Cursor.lockState = CursorLockMode.Locked;
        this.gameObject.SetActive(false);
        GameObject.Find("Player_Object").GetComponent<ThirdP_ctrl>().enabled = true;
    }

    public void Options()
    {
        OnHold = true;
        OptionsWorldObj.SetActive(true);
    }

    public void OptionsCancel()
    {
        OnHold = false;
        OptionsWorldObj.SetActive(false);
    }



    public void TitleScreen()
    {
        OnHold = true;
        TitlePrompted = true;
        currentresponse = 0;
        PromptObj.gameObject.SetActive(true);
    }

    public void ExitGame()
    {
        if (currentresponse == 0)
        {
            OnHold = true;
            PromptObj.gameObject.SetActive(true);
            ExitPrompted = true;
        }
    }

    
}
