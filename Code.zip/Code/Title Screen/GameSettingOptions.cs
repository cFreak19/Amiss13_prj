﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameSettingOptions : MonoBehaviour {
    private bool FsOn = true;
    private int QLv = 3;
    private string Rsl = "1024x768";
    private GameObject controllerMain;
    [SerializeField]private GameObject ResDDObj, FSToggleObj, QLvDDObj;

    public void FsTempToggle()
    {
        FsOn = !FsOn;
    }

    public void AssignTempQLv()
    {
        QLv = QLvDDObj.GetComponent<Dropdown>().value;
    }

    public void AssignRsl()
    {
        int index = ResDDObj.GetComponent<Dropdown>().value;
        Rsl = ResDDObj.GetComponent<Dropdown>().options[index].text;
    }

    public void AcceptOpts()
    {
        GameSettingPreset nextPrs = new GameSettingPreset();
        nextPrs.FSOn = FsOn;
        nextPrs.QLevel = QLv;
        nextPrs.SetRes(Rsl);
        controllerMain.GetComponent<UProfiler>().ApplySelection(nextPrs);
        
    }
    
    void Start() {
        controllerMain = GameObject.Find("gameController");
        Resolution[] PosResArr = Screen.resolutions;
        List<Dropdown.OptionData> resOpts = new List<Dropdown.OptionData>();
        for (int a = 0; a < PosResArr.Length; a++)
        {
            resOpts.Add(new Dropdown.OptionData(PosResArr[a].width.ToString() + "x" + PosResArr[a].height.ToString()));
        }
            ResDDObj.GetComponent<Dropdown>().ClearOptions();
            ResDDObj.GetComponent<Dropdown>().AddOptions(resOpts);
        FSToggleObj.GetComponent<Toggle>().isOn = Screen.fullScreen;
        QLv = controllerMain.GetComponent<UProfiler>().ActiveStats.userSettings.QLevel;
        QLvDDObj.GetComponent<Dropdown>().value = QualitySettings.GetQualityLevel();
    }
	
}
