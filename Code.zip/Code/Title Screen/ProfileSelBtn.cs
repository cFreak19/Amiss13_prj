﻿using UnityEngine;


public class ProfileSelBtn : MonoBehaviour {
	public GameObject parentObj;
	public int ProfileNo;

	// Use this for initialization
	void Start () {
		
	}

	public void Select()
	{
        parentObj.GetComponent<GameMainMenu>().SelectProfileByIndex(ProfileNo);
	}

	// Update is called once per frame
	void Update () {
		
	}
}
