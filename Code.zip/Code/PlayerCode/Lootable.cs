﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using A13_theCurse_GameConst;

public class Lootable : MonoBehaviour {
    public List<invitem> PossibleLoot = new List<invitem>();
    public GameObject lootablePrefab;
	
    public void BlurpLoot()
    {
        GameObject lootObj = Instantiate(lootablePrefab, transform.position, Quaternion.identity) as GameObject;
        lootObj.GetComponent<itemPickup>().myitem.Add(PossibleLoot[UnityEngine.Random.Range(0, PossibleLoot.Count)]);
    }

    public invitem PickAtRandom()
    {
        return PossibleLoot[UnityEngine.Random.Range(0, PossibleLoot.Count)];
    }

	// Update is called once per frame
	void Update () {
		
	}
}
