﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BeamEffect : MonoBehaviour {
    public float BeamPower = 2;


    private void OnTriggerEnter(Collider other)
    {
        if (other.transform.gameObject.GetComponent<Rigidbody>())
        {
            other.transform.gameObject.GetComponent<Rigidbody>().AddExplosionForce(BeamPower, other.transform.position, GetComponent<SphereCollider>().radius * transform.localScale.x,10,ForceMode.Impulse);
            if (other.transform.gameObject.GetComponent<automated>())
            {
                other.transform.gameObject.GetComponent<automated>().GetHurt(int.Parse(BeamPower.ToString()) * 3);
            }
            other.transform.gameObject.GetComponent<Rigidbody>().AddExplosionForce(10f, other.ClosestPoint(transform.position), 5f);
        }
        if (other.transform.gameObject.GetComponent<interactable>().Destroyable)
            other.transform.gameObject.GetComponent<interactable>().ChealthP -= 1;
    }

}
