﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RuneBookInterface : MonoBehaviour {

    public GameObject[] RuneDisplayObjects;

	// Use this for initialization
	void Start () {
        for (int a = 0; a < RuneDisplayObjects.Length; a++)
            RuneDisplayObjects[a].GetComponent<Text>().text = GameObject.Find("Player_Object").GetComponent<RuneBase>().getRank(a).ToString();
	}
	
    //public void SetCursorDown()
    //{
    //    Cursor.lockState = CursorLockMode.Locked;
    //    Cursor.visible = false;
    //}

    void OnDisable()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        GameObject.Find("Player_Object").GetComponent<player_stats>().myanim.SetBool("GamePlayActive", true);
    }
    

	// Update is called once per frame
	void Update () {
        if (GameObject.Find("Player_Object").GetComponent<player_stats>().myanim.GetBool("GamePlayActive") && transform.gameObject.activeInHierarchy)
            gameObject.SetActive(false);
    }
}
