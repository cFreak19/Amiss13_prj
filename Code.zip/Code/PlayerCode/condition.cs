﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

[Serializable]
public class condition
{
    public int ActNo, ChapterNo, PlayerLevel, damageoutput, spellunlocked, itemobtained, coincollected;

    public bool EligiblyTriggered(condition mycurrentcond)
    {
        if ((mycurrentcond.ActNo >= ActNo) && (mycurrentcond.ChapterNo >= ChapterNo) && (mycurrentcond.PlayerLevel >= PlayerLevel) && (mycurrentcond.damageoutput >= damageoutput) && (mycurrentcond.spellunlocked == spellunlocked) && (mycurrentcond.itemobtained == itemobtained) && (mycurrentcond.coincollected >= coincollected))
            return true;
        else
            return false;
    }
}