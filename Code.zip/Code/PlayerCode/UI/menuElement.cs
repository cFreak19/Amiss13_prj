﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class menuElement : MonoBehaviour
{
    void OnEnable()
    {
        Time.timeScale = 0F;
    }

    void OnDisable()
    {
        Time.timeScale = 1F;
    }

    public void CancelAttr()
    {
        Time.timeScale = 1F;
        this.gameObject.SetActive(false);
        
    }
}
