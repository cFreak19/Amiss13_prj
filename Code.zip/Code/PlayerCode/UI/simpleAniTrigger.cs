﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
 

public class simpleAniTrigger : MonoBehaviour {
    public string boolName;
    public Texture2D xpIc, surpIc;
    public GameObject aniObj;

	// Use this for initialization
	void Start () {
		
	}

    
    public void AniTrigger(Texture2D itemIcExt)
    {
        aniObj.GetComponent<Animator>().SetBool(boolName, false);
        aniObj.GetComponent<RawImage>().texture = itemIcExt;
        aniObj.GetComponent<Animator>().SetBool(boolName, true);
        aniObj.GetComponent<Animator>().SetBool(boolName, false);
    }

    public void AniTrigger(bool isXP) //if not custom, either is an exp reward or a surplus reward.
    {
        aniObj.GetComponent<Animator>().SetBool(boolName, false);
        if (isXP)
            aniObj.GetComponent<RawImage>().texture = xpIc;
        else
            aniObj.GetComponent<RawImage>().texture = surpIc;
        aniObj.GetComponent<Animator>().SetBool(boolName, true);
        aniObj.GetComponent<Animator>().SetBool(boolName, false);
    }
    


	// Update is called once per frame
	void Update () {
		
	}
}
