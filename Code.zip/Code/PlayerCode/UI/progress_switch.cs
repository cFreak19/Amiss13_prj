﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class progress_switch : interactable
{
    public List<GameObject> destroyables = new List<GameObject>();
    public string theMessage;
    public int stagereq, UseCount;
    public List<GameObject> animationTriggers = new List<GameObject>();
    public bool onetimeUse;
    private GameObject plObj;

    void Start()
    {
        plObj = GameObject.Find("Player_Object");
    }

    public override void GetHit(int dinput)
    {

    }

    public override void InfPrompt()
    {

    }

    public override void Use()
    {
		if (plObj.GetComponent<player_stats>().StoryC >= stagereq)
        {
            GameObject.Find("UI_MessagePanel").SetActive(true);
            if (destroyables.Count > 1)
            {
                for (int a = 0; a < destroyables.Count; a++)
                {
                    Destroy(destroyables[a]);
                }
            }
            if (animationTriggers.Count > 1)
            {
                for (int a = 0; a < animationTriggers.Count; a++)
                {
                    animationTriggers[a].GetComponent<automated_anim>().AnimTrigger();
                }
            }

			plObj.GetComponent<player_stats>().StoryC++;
        }
    }

    public override void InfDisplay(GameObject DispAnchor)
    {

    }
}