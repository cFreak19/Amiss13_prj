﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class fadeControl : MonoBehaviour {
    public float falpha, myrate;

    public void FadeIn()
    {
        InvokeRepeating("DecBlack", myrate, myrate);
    }


    public void FadeOut()
    {
        InvokeRepeating("IncBlack", myrate, myrate);
    }

    void IncBlack()
    {
        falpha++;
        if (falpha >= 1)
            CancelInvoke();

    }

    void DecBlack()
    {
        falpha--;
        if (falpha <= 0)
            CancelInvoke();
    }


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
