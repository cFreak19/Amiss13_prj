﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System;

public class MsgBox : interactable {
    public string Message;

    public override void GetHit(int dinput)
    {

    }

    public override void InfPrompt()
    {
        GameObject.Find("UI_MessagePanel").transform.Find("MessageText").GetComponent<Text>().text = Message;
        GameObject.Find("UI_MessagePanel").SetActive(true);
    }

    public override void Use()
    {
        GameObject.Find("UI_MessagePanel").transform.Find("MessageText").GetComponent<Text>().text = Message;
        GameObject.Find("UI_MessagePanel").SetActive(true);
    }

    public override void InfDisplay(GameObject DispAnchor)
    {
        DispAnchor.GetComponent<Text>().text = GObjectName;
        //GUI.Label(new Rect(DispAnchor.x + 10, DispAnchor.y + 10, 640, 128), GObjectName);
    }
}
