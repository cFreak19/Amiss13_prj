﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class automated_anim : MonoBehaviour
{
    public GameObject extObj;
    public void AnimTrigger()
    {
        if (extObj == null)
            GetComponent<Animator>().SetBool("thetrigger", true);
        else
            extObj.GetComponent<Animator>().SetBool("thetrigger", true);
    }
}
