﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.UI;

public class ErrorDisplay : MonoBehaviour
{
    bool isFatal;

    public void Display(string errorstring, bool isfatal)
    {
        transform.Find("Text").GetComponent<Text>().text = errorstring;
        Debug.Log(errorstring);
        isFatal = isfatal;
    }

    public void End()
    {
        if (isFatal)
            Application.Quit();
        else
            this.gameObject.SetActive(false);
    }
}
