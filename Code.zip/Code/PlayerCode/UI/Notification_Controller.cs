﻿using UnityEngine;
using System.Collections;

public class Notification_Controller : MonoBehaviour {


    void OnEnable()
    {
        GameObject.Find("Player_Object").GetComponent<player_stats>().myanim.SetBool("GamePlayActive",false);
    }
    


	void FixedUpdate () {
	    if(Input.GetButtonDown("Close Window / Next"))
        {
            GameObject.Find("Player_Object").GetComponent<player_stats>().myanim.SetBool("GamePlayActive",true);
            this.gameObject.SetActive(false);
        }
	}
}
