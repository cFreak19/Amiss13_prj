﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;



public class WorldPuzzle : MonoBehaviour {
    public List<GameObject> clues = new List<GameObject>();//clues to be set for the final input, which is either a win condition or a series of characters to be added somewhere.
    public List<bool> isSprite = new List<bool>(); //bool checks for clue objects, to decide if they are world text meshes or sprites to be modified.

    public List<GameObject> triggers = new List<GameObject>(); //objects to be triggered.

    //public List<bool> SwitchCombinationReq = new List<bool>(); //required trigger combination for switches
    //public List<int> SelectorCombinationReq = new List<int>(); //required trigger combination for selectors

    public List<Sprite> SpriteClues = new List<Sprite>();
    public List<string> ClueTexts = new List<string>();

    public List<GameObject> triggerDisplayObj = new List<GameObject>(); //trigger object results displayed

    public AudioSource adsrc;

    public bool DefineTriggerObjects = false;
    public string successComb = ""; //required combination for success, a character for each input, 'mind'
    private string curComb = "";
    private int CombCounter = 0;

    [Header("Resolve Actions")]
    public bool AnimateOnResolve;
    public string AniBoolTrigger;
    public int AniIntSelection;
    public bool MoveObjects, DestroyObjects,ActivateObjects;
    public List<GameObject> AppliedObjects = new List<GameObject>();
    public List<Vector3> ChangedLocations = new List<Vector3>();
    public List<bool> ObjectIsDestroyed = new List<bool>();
    public List<bool> ObjectIsMoved = new List<bool>();
    public List<bool> ObjectIsActivated = new List<bool>();

    public void TriggerDefine (int index)
    {
        if (CombCounter < successComb.Length - 1)
        {
            curComb += successComb[index];
            CombCounter++;
            triggerDisplayObj[index].SetActive(true); //on success enable display
            if (CombCounter >= successComb.Length)
            {
                if (curComb == successComb)
                {
                    PuzzleResolve();
                }
                else {
                    for (int a = 0; a < triggerDisplayObj.Count; a++)
                    {
                        triggerDisplayObj[a].SetActive(false);
                    }
                    curComb = "";
                    CombCounter = 0;
                    for (int a = 0; a < triggers.Count; a++)
                    {
                        triggers[a].GetComponent<puzzleTrigger>().Used = false;
                    }
                }
            }
        } else
        {
            for (int a = 0; a < triggerDisplayObj.Count; a++)
            {
                triggerDisplayObj[a].SetActive(false);
            }
            curComb = "";
            CombCounter = 0;
        }
    }

    void PuzzleResolve()
    {
        if (adsrc != null)
            adsrc.Play();
        if (AnimateOnResolve)
        {
            if (AniIntSelection != -1)
            {

            }
            else
            {

            }
        }
        if (MoveObjects)
        {
            for (int a = 0; a < ObjectIsMoved.Count; a++)
            {
                if (ObjectIsMoved[a])
                {
                    AppliedObjects[a].transform.position = ChangedLocations[a];
                }
            }
        }
        if (DestroyObjects)
        {
            for (int a = 0; a < ObjectIsDestroyed.Count; a++)
            {
                if (ObjectIsDestroyed[a])
                    Destroy(AppliedObjects[a]);
            }
        }
    }

    public void DefineSpecific(char spec)
    {
        if (CombCounter < successComb.Length - 1)
        {
            curComb += spec;
            CombCounter++;
            triggerDisplayObj[CombCounter-1].SetActive(true); //on success enable display
        }
        else
        {
            for (int a = 0; a < triggerDisplayObj.Count; a++)
            {
                triggerDisplayObj[a].SetActive(false);
            }
            curComb = "";
            CombCounter = 0;
        }
    }

    // Use this for initialization
    void Start () {
        if (DefineTriggerObjects)
        {
            if (clues.Count >= SpriteClues.Count + ClueTexts.Count)
            {
                int spritecount = 0;
                int textcount = 0;
                for (int a = 0; a < clues.Count; a++)
                {
                    if (isSprite[a])
                    {
                        clues[a].GetComponent<SpriteRenderer>().sprite = SpriteClues[spritecount];
                        spritecount++;
                    }
                    else
                    {
                        clues[a].GetComponent<TextMesh>().text = ClueTexts[textcount];
                        textcount++;
                    }
                }
            }
            else
            {
                List<string> myvars = new List<string>();
                for (int b = 0; b < clues.Count; b++)
                {
                    myvars.Add(clues[b].gameObject.name);
                }
                throw new WorldValuesFalseException(myvars, "WorldPuzzle", gameObject.name);
            }
        }
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
