﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class initOnENable : MonoBehaviour {
    public GameObject[] myobject;
    public bool OptionsEnable, fightinitenable;

    void OnEnable()
    {
        if (fightinitenable)
            myobject[0].GetComponent<tutorial_miniboss>().StartFight();
        else if (OptionsEnable)
        {
            myobject[0].GetComponent<Dropdown>().value = GameObject.Find("gameController").GetComponent<UProfiler>().ActiveStats.userSettings.QLevel;
            myobject[1].GetComponent<Toggle>().isOn = GameObject.Find("gameController").GetComponent<UProfiler>().ActiveStats.userSettings.FSOn;
            Resolution res = GameObject.Find("gameController").GetComponent<UProfiler>().ActiveStats.userSettings.myresolution;
            string resStr = res.width.ToString() + "x" + res.height.ToString();
            Resolution[] resOpts = Screen.resolutions;
            int curV = 0;
            for (int a = 0; a < resOpts.Length; a++)
            {
                if (resStr == resOpts[a].width.ToString() + "x" + resOpts[a].height.ToString())
                    curV = a;
            }
            myobject[2].GetComponent<Dropdown>().value = curV;
        }
    }

	// Use this for initialization
	void Start () {
        Resolution[] resOpts = Screen.resolutions;
        List<Dropdown.OptionData> resOptsDD = new List<Dropdown.OptionData>();
        for (int a = 0; a < resOpts.Length; a++)
            resOptsDD.Add(new Dropdown.OptionData(resOpts[a].width.ToString() + "x" + resOpts[a].height.ToString()));
        myobject[2].GetComponent<Dropdown>().AddOptions(resOptsDD);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
