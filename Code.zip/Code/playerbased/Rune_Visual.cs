﻿using UnityEngine;
using System.Collections;

public class Rune_Visual : MonoBehaviour {
    private int mycurrentalpha = 0;
    [SerializeField]private int finalalpha;

		
    void Awake()
    {
        mycurrentalpha = 255;
        Color current = transform.GetComponent<MeshRenderer>().materials[0].color;
        current.a = 255;
        InvokeRepeating("Fade", 0.1F, 0.1F);
    }

    void Fade()
    {
        if (mycurrentalpha > finalalpha)
        {
            mycurrentalpha -= 2;
            Color current = transform.GetComponent<MeshRenderer>().materials[0].color;
            current.a = mycurrentalpha;
            if (mycurrentalpha <= finalalpha)
                CancelInvoke();
        }
    }

	// Update is called once per frame
	void Update () {
	    if (Input.GetButtonDown("Fire2"))
        {
            this.gameObject.SetActive(false);
        }
	}
}
