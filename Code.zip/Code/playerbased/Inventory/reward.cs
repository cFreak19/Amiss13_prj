﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using A13_theCurse_GameConst;
 

[Serializable]
public class reward
{
    public GameConstants.RewardType typeofRew;
    public int statBonus, statOrder;
    public GameConstants.itemSpecs tag;
    public int rewardedAmntorNumber;
    public invitem inventoryItem = new invitem();
}