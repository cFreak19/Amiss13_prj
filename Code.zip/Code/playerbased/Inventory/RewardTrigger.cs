﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using A13_theCurse_GameConst;
 

public class RewardTrigger : MonoBehaviour {
    public GameConstants.Unlockable rewType;
    public int rewOrder;
    public Vector3 RotateAmnt;
    
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            other.gameObject.GetComponent<player_stats>().GrantUnlock(rewType, rewOrder);
            Destroy(gameObject);
        }
    }

    
	// Use this for initialization
	void Start () {
        if (GameObject.Find("gameController").GetComponent<UnlockableBase>().SkinOwned(rewOrder))
            Destroy(gameObject);
	}
	
	// Update is called once per frame
	void Update () {
        transform.Rotate(RotateAmnt);
	}
}
