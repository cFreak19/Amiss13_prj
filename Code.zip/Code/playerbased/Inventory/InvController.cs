﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using A13_theCurse_GameConst;
 
using System;


public class InvController : MonoBehaviour {
    public invitem[] WeaponRoster = new invitem[6];
    public GameObject[] PredefEquipList = new GameObject[1];
    public List<invitem> Inventory = new List<invitem>();
    public int hoveringslot, current, cellsize, cellspace;
    public bool hovering = true;
    private bool CanAttack = true;
    private float alpha = 0;
    private Vector2 InvAnchor = new Vector2(Screen.width/16,Screen.height/24);
    public Rect BigRect;
    public Texture2D iconBG, hovericBG, selectedColBG;
    public int selectedWep;
    public GameObject invPanel, castAnchor, pickupAniObj, ThrownPrefab;
    public Animator playerAni;
    
    bool CheckforItemwithName(string itemname)
    {
        for (int a = 0; a < Inventory.Count; a++)
        {
            if (Inventory[a].itemName == itemname)
                return true;
        }
        return false;
    }

    invitem GetItemwithName(string itemname)
    {
        for (int a = 0; a < Inventory.Count; a++)
        {
            if (Inventory[a].itemName == itemname)
                return Inventory[a];
        }
        return null;
    }
    
    int GetItemIndexwithName(string itemname)
    {
        for (int a = 0; a < Inventory.Count; a++)
        {
            if (Inventory[a].itemName == itemname)
                return a;
        }
        return -1;
    }
    
    public bool CheckForItemsList(string[] itemNames)
    {
        int totalItems = itemNames.Length;
        int existscounter = 0;
        for (int a = 0; a < itemNames.Length; a++)
        {
            if (CheckforItemwithName(itemNames[a]))
                existscounter++;
        }
        if (existscounter >= totalItems)
            return true;
        else
            return false;
    }

    public void UseMaterials(string[] itemNames)
    {
        int curOrder = -1;
        for (int a = 0; a < itemNames.Length; a++)
        {
            curOrder = GetItemIndexwithName(itemNames[a]);
        }
    }

    public void InitInventory(List<invitem> loadingInv)
    {
        Inventory.Clear();
        for (int a = 0; a<loadingInv.Count; a++)
        {
            Inventory.Add(loadingInv[a]);
        }
    }

	public void InitWeapons()
	{
        if (GetComponent<player_stats>())
        {
            if (GetComponent<player_stats>().myActiveProfile.autosave.WeaponsList[0])
            {
                WeaponRoster[1].Quantity = 1;
            }
            else
                WeaponRoster[1].Quantity = 0;
            if (GetComponent<player_stats>().myActiveProfile.autosave.WeaponsList[1])
            {
                WeaponRoster[2].Quantity = 1;
            }
            else
                WeaponRoster[2].Quantity = 0;
            if (GetComponent<player_stats>().myActiveProfile.autosave.WeaponsList[2])
            {
                WeaponRoster[3].Quantity = 1;
            }
            else
                WeaponRoster[3].Quantity = 0;
        }
        //else if (GetComponent<Online_pl_stats>())
        //{
        //    WeaponRoster[1].Quantity = 1;
        //    WeaponRoster[2].Quantity = 1;
        //    WeaponRoster[3].Quantity = 1;
        //}
	}

    public void EquipItem(int a)
    {
        if (Inventory[a].iType == GameConstants.itemType.Weapon)
        {
            WeaponRoster[3].Set(Inventory[a]);
        }
    }

    public void Consume (int a)
    {
    if (Inventory[a].iType == GameConstants.itemType.Consumable)
    {
        Inventory[a].Quantity--;
            for (int b = 0; b < Inventory[a].onInvUse.Count; b++)
            {
                switch (Inventory[a].onInvUse[b].typeofRew)
                {
                    case GameConstants.RewardType.Surplus:
                        {
                            GetComponent<player_stats>().myActiveProfile.SurplusPt += Inventory[a].onInvUse[b].rewardedAmntorNumber;
                            pickupAniObj.GetComponent<simpleAniTrigger>().AniTrigger(false);
                            //GetComponent<player_stats>().myActiveProfile.autosave.AddLogEntry("Player obtained " + Inventory[a].onInvUse[b].rewardedAmntorNumber.ToString() + " surplus points.");
                        }
                        break;
                    case GameConstants.RewardType.Exp:
                        {
                            GetComponent<player_stats>().myActiveProfile.Experience += Inventory[a].onInvUse[b].rewardedAmntorNumber;
                            pickupAniObj.GetComponent<simpleAniTrigger>().AniTrigger(true);
                            //GetComponent<player_stats>().myActiveProfile.autosave.AddLogEntry("Player obtained " + Inventory[a].onInvUse[b].rewardedAmntorNumber.ToString() + "  experience points.");
                        }
                        break;
                    case GameConstants.RewardType.InvItem:
                        invitem newloot = new invitem();
                            newloot.Set(Inventory[a].onInvUse[b].inventoryItem);
                            AcquireItem(newloot);
                            //GetComponent<player_stats>().myActiveProfile.autosave.AddLogEntry("Player obtained a new item: " + Inventory[a].onInvUse[b].inventoryItem.itemName);
                        break;
                    case GameConstants.RewardType.ResourceRegen:
                        if (Inventory[a].onInvUse[b].tag == GameConstants.itemSpecs.HRegen)
                            GetComponent<player_stats>().HReg(Inventory[a].onInvUse[b].rewardedAmntorNumber);
                        else if (Inventory[a].onInvUse[b].tag == GameConstants.itemSpecs.WRegen)
                            GetComponent<player_stats>().WReg(Inventory[a].onInvUse[b].rewardedAmntorNumber);
                        break;
                    case GameConstants.RewardType.RuneRank:
                        GetComponent<RuneBase>().RankUp(Inventory[a].onInvUse[b].rewardedAmntorNumber);
                        //GetComponent<player_stats>().myActiveProfile.autosave.AddLogEntry("Player upgraded a new rune: " + GetComponent<RuneBase>().getRuneName(Inventory[a].onInvUse[b].rewardedAmntorNumber));
                        break;
                    case GameConstants.RewardType.StatBonus:
                        GetComponent<player_stats>().myActiveProfile.PlayerStats[Inventory[a].onInvUse[b].statOrder].statBonus = Inventory[a].onInvUse[b].statBonus;
                        break;
                    case GameConstants.RewardType.WeaponUnlock:
                        {
                            int weaponno = Inventory[a].onInvUse[b].rewardedAmntorNumber;
                            switch (weaponno)
                            {
                                case 1:
                                    //GameObject.Find("gameController").GetComponent<steamMethod>().UpAchiCount("obDagger");
                                    break;
                                case 2:
                                    //GameObject.Find("gameController").GetComponent<steamMethod>().UpAchiCount("obCrowbar");
                                    break;
                                case 3:
                                    //GameObject.Find("gameController").GetComponent<steamMethod>().UpAchiCount("obTorch");
                                    break;
                            }
                            //GetComponent<player_stats>().myActiveProfile.autosave.AddLogEntry("Player obtained the weapon: " + WeaponRoster[weaponno].itemName);
                            GetComponent<InvController>().WeaponRoster[weaponno].Quantity = 1;
                            GetComponent<player_stats>().myActiveProfile.autosave.WeaponsList[weaponno-1] = true;
                        }
                        break;
                    case GameConstants.RewardType.GrantCycle:
                        GetComponent<RuneBase>().UnlockCycle();
                        break;
                    case GameConstants.RewardType.TaskIncrement:
                        GameObject.Find("gameController").GetComponent<WayBase>().TaskIncrement(false);
                        break;
                }
            }
            if (Inventory[a].Quantity <= 0)
            {
                if (Inventory[a].worldprefab != null)
                    Destroy(Inventory[a].worldprefab);
                Inventory.RemoveAt(a);
            }
        }
    }


    public void UseActive(int dmgbonus, bool isCrit)
    {
        if (CanAttack)
        {
            CanAttack = false;
            StartCoroutine(AttackAni());
            RaycastHit curHit;
            if (selectedWep != 0)
            {
                if ((selectedWep == 4) && (WeaponRoster[4].CheckForTag("Bright")))
                {
                    StartCoroutine(ManualBeam());
                    SpendItem(WeaponRoster[4].itemName);
                }
                else if (WeaponRoster[4].CheckForTag("HRegen"))
                {

                }
                else if (Physics.Raycast(castAnchor.transform.position, castAnchor.transform.forward, out curHit, WeaponRoster[selectedWep].itemRange))
                {
                    if (curHit.transform.GetComponent<eventStep>())
                    {
                        curHit.transform.GetComponent<eventStep>().TriggerAction(WeaponRoster[selectedWep]);
                    }
                    if (curHit.transform.gameObject.GetComponent<automated>())
                    {
                        int damage = dmgbonus + WeaponRoster[selectedWep].dmgMod;
                        if (selectedWep == 1) //Apply enchantments
                        {
                            if (WeaponRoster[1].rank >= 1)
                            {
                                damage *= 3;
                                damage /= 2;
                            }
                            if (WeaponRoster[1].rank >= 2)
                            {
                                Applied_Effect myEnchantment = new Applied_Effect();
                                myEnchantment.basedamage = Mathf.FloorToInt(float.Parse(damage.ToString()) / 20);
                                myEnchantment.duration = 10;
                                myEnchantment.mytype = GameConstants.EffectType.Burn;
                                myEnchantment.spellLevel = 1;
                                myEnchantment.spellrank1 = 1;
                                myEnchantment.spellrank2 = 1;
                                myEnchantment.statSlot = 1;
                                myEnchantment.wisbonus = 1;
                                myEnchantment.wismult = 1;
                                curHit.transform.gameObject.GetComponent<automated>().CurrentlyApplying.Add(myEnchantment);
                            }
                        }
                        else if (selectedWep == 2)
                        {
                            Applied_Effect myEnchantment = new Applied_Effect();
                            myEnchantment.basedamage = damage / 10;
                            myEnchantment.duration = 3;
                            myEnchantment.mytype = GameConstants.EffectType.Daze;
                            myEnchantment.spellLevel = 1;
                            myEnchantment.spellrank1 = 1;
                            myEnchantment.spellrank2 = 1;
                            myEnchantment.statSlot = 1;
                            myEnchantment.wisbonus = 1;
                            myEnchantment.wismult = 1;
                            curHit.transform.gameObject.GetComponent<automated>().CurrentlyApplying.Add(myEnchantment);

                        }
                        
                        curHit.transform.gameObject.GetComponent<automated>().GetHurt(damage);
                        if ((!isCrit) && (curHit.transform.gameObject.tag == "bleeds"))
                        {
                            WeaponRoster[selectedWep].extraPrefabs[0].GetComponent<ParticleSystem>().Play();
                            WeaponRoster[selectedWep].extraPrefabs[0].GetComponent<AudioSource>().Play();
                        }

                    }
                    else if (curHit.transform.gameObject.GetComponent<itemPickup>().Destroyable)
                    {
                        curHit.transform.gameObject.GetComponent<itemPickup>().GetHit(dmgbonus + WeaponRoster[selectedWep].dmgMod);
                    }
                }
            }
        }
    }
    
    void SpendItem(string ItemName)
    {
        for (int a = 0; a < Inventory.Count; a++)
        {
            if (Inventory[a].itemName == ItemName)
            {
                Inventory[a].Quantity--;
                if (Inventory[a].Quantity <= 0)
                {
                    Inventory.RemoveAt(a);
                    RefreshInvDisplay();
                }
            }
        }
    }

    IEnumerator ManualBeam ()
    {
        if (GetComponent<player_stats>().curBeamP > 50)
        {
            GameObject mybrightThrown = Instantiate(ThrownPrefab, castAnchor.transform.position, Quaternion.identity) as GameObject;
            mybrightThrown.GetComponent<BeamReflection>().plObject = this.gameObject;
            mybrightThrown.GetComponent<Rigidbody>().AddForce(castAnchor.transform.forward *6 + new Vector3(0, 6, 0), ForceMode.Impulse);
            GetComponent<player_stats>().curBeamP -= 50;
            yield return new WaitForSeconds(0.4f);
            mybrightThrown.GetComponent<BeamReflection>().StartBeam();
            yield return new WaitForSeconds(2f);
            mybrightThrown.GetComponent<BeamReflection>().EndBeam();
            Destroy(mybrightThrown);
        }
    }

    public void GrantReward(int a)
    {
        for (int b=0; b < Inventory[a].onInvUse.Count; b++)
        {
            switch (Inventory[a].onInvUse[b].typeofRew)
            {
                case GameConstants.RewardType.Surplus:
                    {
                        GetComponent<player_stats>().myActiveProfile.SurplusPt += Inventory[a].onInvUse[b].rewardedAmntorNumber;
                        pickupAniObj.GetComponent<simpleAniTrigger>().AniTrigger(false);
                    }
                    break;
                case GameConstants.RewardType.Exp:
                    {
                        GetComponent<player_stats>().myActiveProfile.Experience += Inventory[a].onInvUse[b].rewardedAmntorNumber;
                        pickupAniObj.GetComponent<simpleAniTrigger>().AniTrigger(true);
                    }
                    break;
                case GameConstants.RewardType.InvItem:
                        AcquireItem(Inventory[a].onInvUse[b].inventoryItem);
                    break;
                case GameConstants.RewardType.ResourceRegen:
                    break;
                case GameConstants.RewardType.RuneRank:
                    for (int d = 0; d < Inventory[a].onInvUse[b].rewardedAmntorNumber; d++)
                        GetComponent<RuneBase>().RankUp(Inventory[a].onInvUse[b].rewardedAmntorNumber);
                    break;
                case GameConstants.RewardType.StatBonus:
                    for (int d = 0; d < 7; d++)
                    {
                        GetComponent<player_stats>().AddStat(Inventory[a].onInvUse[b].statOrder, Inventory[a].onInvUse[b].statBonus);
                    }
                    break;
            }
        }
    }

    public void GrantReward(reward A)
    {
        
            switch (A.typeofRew)
            {
                case GameConstants.RewardType.Surplus:
                    {
                        GetComponent<player_stats>().myActiveProfile.SurplusPt += A.rewardedAmntorNumber;
                        pickupAniObj.GetComponent<simpleAniTrigger>().AniTrigger(false);
                    }
                    break;
                case GameConstants.RewardType.Exp:
                    {
                        GetComponent<player_stats>().myActiveProfile.Experience += A.rewardedAmntorNumber;
                        pickupAniObj.GetComponent<simpleAniTrigger>().AniTrigger(true);
                    }
                    break;
                case GameConstants.RewardType.InvItem:
                    AcquireItem(A.inventoryItem);
                    break;
                case GameConstants.RewardType.ResourceRegen:
                    break;
                case GameConstants.RewardType.RuneRank:
                    for (int d = 0; d < A.rewardedAmntorNumber; d++)
                        GetComponent<RuneBase>().RankUp(A.rewardedAmntorNumber);
                    break;
                case GameConstants.RewardType.StatBonus:
                    for (int d = 0; d < 7; d++)
                    {
                        GetComponent<player_stats>().AddStat(A.statOrder, A.statBonus);
                    }
                    break;
            }
    }

    IEnumerator AttackAni()
    {
        playerAni.SetInteger("weaponselection", selectedWep);
        playerAni.SetBool("animating", true);
        CanAttack = false;
        yield return new WaitForSeconds(WeaponRoster[selectedWep].HitDelay);
        playerAni.SetBool("animating", false);
        yield return new WaitForSeconds(WeaponRoster[selectedWep].totalCD - 0.07f);
        CanAttack = true;
    }

    public void AcquireItem(invitem looted)
    {
        bool added = false;
        pickupAniObj.GetComponent<simpleAniTrigger>().AniTrigger(looted.itemIcon);
        if (Inventory.Count > 0)
        {
            for (int a = 0; a < Inventory.Count; a++)
            {
                if (Inventory[a].itemName == looted.itemName)
                {
                    Inventory[a].Quantity += looted.Quantity;
                    added = true;
                }
            }
        }
        if (!added)
            Inventory.Add(looted);
        GameObject.Find("Player_Object").GetComponent<player_stats>().RefreshSecondaryContent();
    }

    public void AcquireWeapon (int a)
    {
        WeaponRoster[a].Quantity = 1;
    }

    private void Start()
    {
        CanAttack = true;
    }

    void TicToc()
    {
        if (alpha > 0.8)
            alpha -= 0.025F;
        else
            alpha -= 0.01F;
        if (alpha <= 0)
        {
            CancelInvoke();
            hovering = false;
        }
    }

    void SelectedAction()
    {
        hoveringslot = selectedWep;
    }

	// Update is called once per frame
	void Update () {
   
        float a = Input.GetAxisRaw("Mouse ScrollWheel");
    if (a > 0)
        {
            if (hovering)
            {
                hoveringslot += 1;
                hoveringslot %= WeaponRoster.Length;
            }
            else
                hoveringslot = selectedWep;
            RefreshInvDisplay();
        }
    else if (a < 0)
        {
            if (hovering)
            {
                hoveringslot += WeaponRoster.Length;
                hoveringslot -= 1;
                hoveringslot %= WeaponRoster.Length;
            }
            else
                hoveringslot = selectedWep;
            RefreshInvDisplay();
        }

       

        if (alpha > 0.1F)
        {
            if ((hovering)&&(Input.GetButtonDown("Pickup/Interact")|| Input.GetButtonDown("Inspect")))
            {
                hovering = false;
                if (WeaponRoster[hoveringslot].Quantity > 0)
                    {
                        selectedWep = hoveringslot;
                        playerAni.SetInteger("weaponselection", selectedWep);
                    GetComponent<player_stats>().myanim.SetInteger("weaponselection", selectedWep);
                    for (int c = 1; c < WeaponRoster.Length; c++)
                    {
                        if ((c != selectedWep) && (WeaponRoster[c].worldprefab != null))
                        {
                            WeaponRoster[c].worldprefab.SetActive(false);
                        }
                    }
                    if (WeaponRoster[selectedWep].worldprefab != null)
                            WeaponRoster[selectedWep].worldprefab.SetActive(true);
                    if (selectedWep == 4)
                    {
                        
                        for (int d = 0; d < PredefEquipList.Length; d++)
                        {
                            if (d == WeaponRoster[4].rank)
                                PredefEquipList[d].SetActive(true);
                            else
                                PredefEquipList[d].SetActive(false);
                        }
                        
                    }
                }
            }
        }
	}

    void RefreshInvDisplay()
    {
        alpha = 1;
        InvokeRepeating("TicToc", 0.05F, 0.05F);
        hovering = true;
    }

    void BaseInventoryDisplay()
    {
        Color mycolor = GUI.color;
        for (int a = 0; a < WeaponRoster.Length; a++)
        {
            Rect currentRect = new Rect(InvAnchor.x + a * (cellsize + cellspace), InvAnchor.y, cellsize, cellsize);
            GUI.DrawTexture(currentRect, iconBG);
            if (WeaponRoster[a].Quantity < 1)
                mycolor = Color.HSVToRGB(88,88,88);
            else
                mycolor = Color.HSVToRGB(255,255,255);
            GUI.color = mycolor;
            GUI.DrawTexture(currentRect, WeaponRoster[a].itemIcon);
        }                                   
        mycolor = Color.HSVToRGB(255,255,255);
        GUI.color = mycolor;
    }


     void OnGUI()
    {
        Color current = GUI.color;
        current.a = alpha;
        GUI.color = current;
        BaseInventoryDisplay();
    }
}
