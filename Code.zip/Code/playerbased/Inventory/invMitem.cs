﻿using UnityEngine;
using A13_theCurse_GameConst;
using UnityEngine.UI;

public class invMitem : MonoBehaviour
{
    public invitem content;
    public Texture2D noitemimg;
    public int orderinInv;
    public GameObject itemDDisplay, playerObject;
    private GameObject inventoryObj;

    void Start()
    {
        playerObject = GameObject.Find("Player_Object");
        itemDDisplay = GameObject.Find("ItemDesc");
        inventoryObj = GameObject.Find("InventoryPanel");
    }



    void OnMouseEnter()
    {
        RefreshVisual();
    }


    public void SetValues(invitem myitem)
    {
        content.Set(myitem);
        RefreshVisual();
    }

    void OnMouseExit()
    {
        inventoryObj.GetComponent<InventoryPanelList>().itemOnHoldDisplay.GetComponent<RawImage>().texture = Texture2D.whiteTexture;
        inventoryObj.GetComponent<InventoryPanelList>().hoveredName.GetComponent<Text>().text = " ";
        inventoryObj.GetComponent<InventoryPanelList>().hoveredDesc.GetComponent<Text>().text = " ";
        inventoryObj.GetComponent<InventoryPanelList>().hoveredAmount.GetComponent<Text>().text = " ";
    }


    public void UseOne()
    {
        switch (content.iType)
        {
            case GameConstants.itemType.Weapon:
                playerObject.GetComponent<InvController>().EquipItem(orderinInv);
                break;
            case GameConstants.itemType.Consumable:
                {
                    playerObject.GetComponent<InvController>().Consume(orderinInv);
                    content.Quantity--;
                }
                break;
            case GameConstants.itemType.Junk:
                break;
            case GameConstants.itemType.Material:
                break;
            case GameConstants.itemType.Other:
                break;
            default:
                break;
        }
        RefreshVisual();
    }

    public void RefreshVisual()
    {

        if (content.Quantity <= 0)
        {
            transform.Find("ItemIcon").GetComponent<RawImage>().texture = Texture2D.whiteTexture;
            transform.Find("ItemName").GetComponent<Text>().text = " ";
            transform.Find("SItemAmountD").GetComponent<Text>().text = " ";
            transform.Find("ItemDesc").GetComponent<Text>().text = " ";
            if (inventoryObj.GetComponent<InventoryPanelList>())
                inventoryObj.GetComponent<InventoryPanelList>().RefreshList();
            Destroy(gameObject);
        }
        else
        {
            inventoryObj.GetComponent<InventoryPanelList>().itemOnHoldDisplay.GetComponent<RawImage>().texture = content.itemIcon;
            inventoryObj.GetComponent<InventoryPanelList>().hoveredName.GetComponent<Text>().text = content.itemName;
            inventoryObj.GetComponent<InventoryPanelList>().hoveredDesc.GetComponent<Text>().text = "Type: " + content.iType.ToString() + " \n D: " + content.itemDescription + " \n Value: " + content.sellValue.ToString();
            inventoryObj.GetComponent<InventoryPanelList>().hoveredAmount.GetComponent<Text>().text = content.Quantity.ToString();
        }
    }

    private void OnDisable()
    {
        Destroy(gameObject);
    }

    void Update()
    {

    }
}
