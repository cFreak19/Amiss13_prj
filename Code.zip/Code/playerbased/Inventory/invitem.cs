﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using A13_theCurse_GameConst;
 


    [Serializable]
    public class invitem
    {
    public string itemName, itemDescription;
    public GameConstants.itemSpecs[] triggerTag = new GameConstants.itemSpecs[4];
    public GameConstants.itemType iType;
    public Texture2D itemIcon;
    public List<reward> onInvUse = new List<reward>();
    public GameObject worldprefab;
    public int Quantity, dmgMod, sellValue;
    public bool isakeyitem;
    public float itemRange, HitDelay, totalCD;
    public GameObject[] extraPrefabs = new GameObject[1];
    public int rank;
    

    public void Acquire()
    {
        Quantity++;
        if (worldprefab != null)
        {
            worldprefab.SetActive(true);
        }
    }

    public bool CheckForTag (string tagString)
    {
        for (int a = 0; a < triggerTag.Length; a++)
        {
            if (triggerTag[a].ToString() == tagString)
                return true;
        }
        return false;
    }

    public void Set(invitem a)
    {
        itemName = a.itemName;
        iType = a.iType;
        itemIcon = a.itemIcon;
        worldprefab = a.worldprefab;

        onInvUse = a.onInvUse;
        Quantity = a.Quantity;
        isakeyitem = a.isakeyitem;
        for (int b = 0; b < extraPrefabs.Length; b++)
        {
            if (b <= rank)
                extraPrefabs[b].SetActive(true);
            else
                extraPrefabs[b].SetActive(false);
        }
    }


    public void RankUp()
    {
        rank++;
        if (iType == GameConstants.itemType.Weapon)
        {
            for (int b = 1; b < extraPrefabs.Length; b++)
            {
                if (b <= rank)
                    extraPrefabs[b].SetActive(true);
                else
                    extraPrefabs[b].SetActive(false);
            }
        }
    }
    

    }
