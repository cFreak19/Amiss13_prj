﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Playables;

public class WeaponUpgrade : MonoBehaviour {
    public int weaponNo;
    public bool singleUse, triggerCutscene, storyprogression;
    private bool used = false;
    public GameObject PlayerObject;

    void Start()
    {
        //PlayerObject = GameObject.FindGameObjectWithTag("Player");
    }

    public void Upgrade()
    {
        if (!used)
        {
            used = true;
            PlayerObject.GetComponent<InvController>().WeaponRoster[weaponNo].RankUp();
            if (storyprogression)
                PlayerObject.GetComponent<player_stats>().StoryC++;
            if (triggerCutscene)
            {
                GetComponent<PlayableDirector>().Play();
            }
        }
    }
}
