﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using A13_theCurse_GameConst;


[Serializable]
public class Game_Achievement
{
    public Texture2D AchiIcon;
    public string AchiName, AchiDesc;
    public bool Achieved = false;
    public List<reward> PossibleLoot = new List<reward>();

    [Header("Requirements")]
    public int argument1, argument2, argument3;

    List<reward> Achieve()
    {
        if (!Achieved)
        {
            Achieved = true;
            return PossibleLoot;
        }
        else
            return new List<reward>();
    }

    void Load(bool save)
    {
        if (save)
        {
            Achieved = true;
        }
    }
}
