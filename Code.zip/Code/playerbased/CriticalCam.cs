﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
 

[Serializable]
public class SingleAniTimerTimer
{
    public float[] InitialScaleMod;
    public float[] TargetScaleMod;
    public float[] duration;
    public float[] TimeScaleRate;
}

public class CriticalCam : MonoBehaviour {
    public Camera MainCam;
    public AudioListener MainListener;
    public GameObject playerRepModel, troubleshootModel;
    public float scaleModStartValue;
    private float scaleModValue, CurTarget;
    private GameObject curHostileTransform;
    private int weaponNo, playerAniNo;
    public bool CritEnded, TroubleshootTrial, SlowMotionCrits;
    public List<SingleAniTimerTimer> TimersByNumber;

    public GameObject Wyatt_baseMesh, metarigParent, DagObj, CrBObj, EmptyPrefab;
    public Material DefaultMat;

    void Start()
    {
        if (TroubleshootTrial)
        {
            InitiateStageCam(troubleshootModel);
        }
    }


    public void SetSkins(SkinSet[] MySkins)
    {
        GameObject emptyPrefab;
        for (int a = 0; a < MySkins[0].FileMeshList.Count; a++)
        {
            emptyPrefab = Instantiate(EmptyPrefab, Wyatt_baseMesh.transform.position, Quaternion.identity) as GameObject;
            emptyPrefab.name = "Wyatt_mesh" + a.ToString();
            emptyPrefab.AddComponent<SkinnedMeshRenderer>();
            emptyPrefab.GetComponent<SkinnedMeshRenderer>().sharedMesh = MySkins[0].FileMeshList[a];
            DefaultMat.mainTexture = MySkins[0].baseTexture;
            emptyPrefab.GetComponent<SkinnedMeshRenderer>().materials[0] = DefaultMat;
            emptyPrefab.GetComponent<SkinnedMeshRenderer>().rootBone = metarigParent.transform.Find("hips").transform;
            emptyPrefab.transform.SetParent(Wyatt_baseMesh.transform);
        }
        //dagChild.transform.SetParent(spawnRig.transform.Find("hand.R").transform);
        //cBChild.transform.SetParent(spawnRig.transform.Find("hand.R").transform);
        //tChild.transform.SetParent(spawnRig.transform.Find("hand.R").transform);
        //CustChild.transform.SetParent(spawnRig.transform.Find("hand.R").transform);
        //modelChild.transform.Find("wyatt_mesh").GetComponent<SkinnedMeshRenderer>().

    }

    IEnumerator StageCritical()
    {
        GetComponent<Animator>().SetInteger("critNumber", playerAniNo);
        GetComponent<Animator>().SetBool("critStart",true);
        MainCam.enabled = false;
        MainListener.enabled = false;
        for (int a = 0; a < TimersByNumber[playerAniNo].InitialScaleMod.Length; a++)
        {
            Time.timeScale = TimersByNumber[playerAniNo].InitialScaleMod[a];
            CurTarget = TimersByNumber[playerAniNo].TargetScaleMod[a];
            InvokeRepeating("FixScale", TimersByNumber[playerAniNo].TimeScaleRate[a], TimersByNumber[playerAniNo].TimeScaleRate[a]);
            yield return new WaitForSeconds(TimersByNumber[playerAniNo].duration[a]);
            CancelInvoke();
            Time.timeScale = CurTarget;
        }
        GetComponent<Animator>().SetBool("critStart", false);
        GameObject.Find("Player_Object").GetComponent<player_stats>().myanim.SetBool("animating", false);
        Time.timeScale = 1F;
    }

    void FixScale()
    {
        if (Time.timeScale < CurTarget)
        {
            Time.timeScale += scaleModValue;
            scaleModValue += 0.04f;
            if (Time.timeScale > CurTarget)
            {
                Time.timeScale = CurTarget;
                CancelInvoke("FixScale");
            }
        }
        else
            CancelInvoke("FixScale");
    }

    public void InitiateStageCam (GameObject hostileGObj)
    {
        if ((hostileGObj.tag == "bleeds")&&(hostileGObj.GetComponent<simple_npc>()))
        {
            GameObject.Find("Player_Object").GetComponent<player_stats>().myanim.SetBool("animating", true);
            Vector3 hostileFeetPos = hostileGObj.transform.position + hostileGObj.GetComponent<CapsuleCollider>().center * hostileGObj.transform.localScale.y - new Vector3(0, GameObject.Find("Player_Object").GetComponent<CapsuleCollider>().height / 2, 0) *hostileGObj.transform.localScale.y  ;
            transform.position = hostileFeetPos;
            transform.rotation = GameObject.Find("Player_Object").transform.rotation;
            playerAniNo = hostileGObj.GetComponent<simple_npc>().criticalAnimationNumber;
            hostileGObj.GetComponent<simple_npc>().CritCamInit();
            Time.timeScale = 1;
            curHostileTransform = hostileGObj;
            scaleModValue = scaleModStartValue;
            if (SlowMotionCrits)
                StartCoroutine(StageCritical());
            else
                StartCoroutine(ExecuteFastCr());
        }
    }
    
    IEnumerator ExecuteFastCr()
    {
        GetComponent<Animator>().SetInteger("critNumber", playerAniNo);
        GetComponent<Animator>().SetBool("critStart", true);
        MainCam.enabled = false;
        MainListener.enabled = false;
        yield return new WaitForSeconds(1.5f);
        GetComponent<Animator>().SetBool("critStart", false);
        GameObject.Find("Player_Object").GetComponent<player_stats>().myanim.SetBool("animating", false);
        Time.timeScale = 1F;
    }
	
	// Update is called once per frame
	void Update () {
		if (CritEnded)
        {
            CritEnded = false;
            MainListener.enabled = true;
            MainCam.enabled = true;
            GetComponent<Animator>().SetBool("critStart", false);
            GameObject.Find("Player_Object").GetComponent<player_stats>().myanim.SetBool("GamePlayActive", true);
            GameObject.Find("Player_Object").transform.position = playerRepModel.transform.position + new Vector3(0, GameObject.Find("Player_Object").GetComponent<CapsuleCollider>().height / 2 + 1f, 0) + GameObject.Find("Player_Object").GetComponent<CapsuleCollider>().center;
        }
	}
}
