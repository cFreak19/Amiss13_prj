﻿using UnityEngine;
using System.Collections.Generic;
using Cinemachine;
using UnityEngine.UI;

public class targetFocus : MonoBehaviour
{
    private GameObject plObj;
    private Transform DefaultTarget, CurrentTarget;
    private CinemachineTargetGroup MyViewGroup;
    private bool ForceHostileTar = false;
    List<GameObject> ObjectsInRange = new List<GameObject>();
    List<GameObject> HostilesInRange = new List<GameObject>();
    List<GameObject> BrightsInRange = new List<GameObject>();
    private bool TargetingBrights = false;

    public bool DebugOn = false;

    public Transform GetTarget()
    {
        return MyViewGroup.m_Targets[1].target;
    }

    void Start()
    {
        plObj = GameObject.Find("Player_Object");
        Init();
    }

    public void Init()
    {
        MyViewGroup = GetComponent<CinemachineTargetGroup>();
        plObj = transform.parent.gameObject;
        DefaultTarget = MyViewGroup.m_Targets[0].target;
        transform.gameObject.AddComponent<SphereCollider>();
        gameObject.GetComponent<SphereCollider>().isTrigger = true;
        gameObject.GetComponent<SphereCollider>().radius = 9;
    }

    public void Init(GameObject PlayerControlled)
    {
        plObj = PlayerControlled;
    }

    void Update()
    {
        if (((plObj.GetComponent<player_stats>()) && (plObj.GetComponent<player_stats>().myanim.GetBool("GamePlayActive")))||(DebugOn))
        {
            if ((GetComponent<CinemachineTargetGroup>().m_Targets[1].target == GameObject.Find("Player_Object").transform)|| (GetComponent<CinemachineTargetGroup>().m_Targets[1].target == transform))
            {
                if (GetNearestObject())
                    GetComponent<CinemachineTargetGroup>().m_Targets[1].target = GetNearestObject().transform;
                else if (GetNearestHostile())
                    GetComponent<CinemachineTargetGroup>().m_Targets[1].target = GetNearestHostile().transform;
                else if (GetNearestBright())
                    GetComponent<CinemachineTargetGroup>().m_Targets[1].target = GetNearestBright().transform;
            }
            if (Input.GetButtonDown("Beam") && (BrightsInRange.Count > 0))
            {
                if (!TargetingBrights)
                {
                    TargetingBrights = true;
                    RefreshFocus();
                }
                else
                {
                    plObj.GetComponent<player_stats>().StartBeam();
                    RefreshFocus();
                    TargetingBrights = false;
                }
            }
            if (TargetingBrights && Input.GetButtonUp("Fire2"))
                TargetingBrights = false;
            else if (TargetingBrights)
                plObj.GetComponent<player_stats>().RefreshTargetDisplay(GetTarget().GetComponent<worldObject>());
            if (Input.GetButtonUp("Next"))
                NextTarget();
            if (Input.GetButtonUp("Prev"))
                PrevTarget();
            if (Input.GetButtonUp("Pickup/Interact"))
            {
                plObj.GetComponent<player_stats>().myanim.SetBool("GamePlayActive", false);
                plObj.GetComponent<player_stats>().AnimateWyatt(2);
                if (Vector3.Distance(transform.position, GetTarget().position) < GetTarget().gameObject.GetComponent<worldObject>().viewRange)
                {
                    GetTarget().gameObject.GetComponent<worldObject>().OnUse();
                    if ((GetTarget().gameObject.GetComponent<interactable>().DestroyOnUse) || (GetTarget() == null))
                    {
                        RemoveCur();
                    }
                }
                else
                    GetTarget().gameObject.GetComponent<worldObject>().InfD();
            }
            if (Input.GetButtonUp("Inspect"))
            {
                plObj.GetComponent<player_stats>().myanim.SetBool("GamePlayActive", false);
                plObj.GetComponent<player_stats>().AnimateWyatt(2);
                GetTarget().gameObject.GetComponent<worldObject>().InfD();
            }
        }
        //else if (plObj.GetComponent<Online_pl_stats>())
        //{
        //    if (Input.GetButtonDown("Beam") && (BrightsInRange.Count > 0))
        //    {
        //        if (!TargetingBrights)
        //        {
        //            TargetingBrights = true;
        //            RefreshFocus();
        //        }
        //        else
        //        {
        //            plObj.GetComponent<player_stats>().StartBeam();
        //            RefreshFocus();
        //            TargetingBrights = false;
        //        }
        //    }
        //    if (TargetingBrights && Input.GetButtonUp("Fire2"))
        //        TargetingBrights = false;
        //    else if (TargetingBrights)
        //        plObj.GetComponent<player_stats>().RefreshTargetDisplay(GetTarget());
        //    if (Input.GetButtonUp("Next"))
        //        NextTarget();
        //    if (Input.GetButtonUp("Prev"))
        //        PrevTarget();
        //}
    }

    public void RefreshFocus()
    {
        if ((BrightsInRange.Count > 0) && (TargetingBrights))
        {
            SetView(BrightsInRange[0].transform);
        }
        else if (((HostilesInCombat()) && (!ForceHostileTar)) || (ForceHostileTar))
        {
            SetView(HostilesInRange[0].transform);
        }
        else
        {
            if (ObjectsInRange.Count <= 0)
                SetView(ObjectsInRange[0].transform);
        }
        if (GetTarget() == null)
        {
            if (HostilesInRange.Count > 0)
            {
                SetView(GetNearestHostile());
            } else
            {
                SetView(GetNearestObject());
            }
        }
    }

    void SetView(Transform myTarget)
    {
        MyViewGroup.m_Targets[1].target = myTarget.transform;
        plObj.GetComponent<player_stats>().RefreshTargetDisplay(myTarget.GetComponent<worldObject>());
    }

    public void NextTarget()
    {
        Transform Current = GetTarget();
        int NextIndex = 0;
        if (TargetingBrights)
        {
            if (BrightsInRange.Count > 0)
            {
                NextIndex = (GetBrightIndex(Current.gameObject.GetInstanceID()) + 1) % BrightsInRange.Count;
                int cursor = 0;
                while (!CheckLineofSight(BrightsInRange[NextIndex].transform) && (cursor < BrightsInRange.Count - 1))
                {
                    NextIndex++;
                    NextIndex %= BrightsInRange.Count;
                    cursor++;
                }
                SetView(BrightsInRange[NextIndex].transform);
            }
        }
        else
        {
            if (HostilesInCombat())
            {
                NextIndex = (GetHostileIndex(Current.gameObject.GetInstanceID()) + 1) % HostilesInRange.Count;
                int cursor = 0;
                while (!CheckLineofSight(HostilesInRange[NextIndex].transform) && (cursor < HostilesInRange.Count - 1))
                {
                    NextIndex++;
                    NextIndex %= HostilesInRange.Count;
                    cursor++;
                }
                SetView(HostilesInRange[NextIndex].transform);
            }
            else if (ObjectsInRange.Count > 0)
            {
                NextIndex = (GetObjectIndex(Current.gameObject.GetInstanceID()) + 1) % ObjectsInRange.Count;
                if (ObjectsInRange.Count > 1)
                {
                    int AimedIndex = -1;
                    float AimedDistance = Vector3.Distance(transform.position, ObjectsInRange[NextIndex].transform.position);
                    for (int a = NextIndex; a < ObjectsInRange.Count; a++)
                    {
                        if (Vector3.Distance(transform.position, ObjectsInRange[a].transform.position) < AimedDistance)
                        {
                            AimedIndex = a;
                            AimedDistance = Vector3.Distance(transform.position, ObjectsInRange[a].transform.position);
                        }
                    }
                    if (AimedIndex != -1)
                    {
                        NextIndex = AimedIndex;
                    }
                    else
                    {
                        NextIndex++;
                        NextIndex %= ObjectsInRange.Count;
                    }
                }
                SetView(ObjectsInRange[NextIndex].transform);
            }
            else
                SetView(DefaultTarget);
        }

        plObj.GetComponent<player_stats>().RefreshTargetDisplay(GetTarget().GetComponent<worldObject>());
    }

    public void PrevTarget()
    {
        Transform Current = GetTarget();
        int NextIndex = 0;
        if (TargetingBrights)
        {
            if (BrightsInRange.Count > 0)
            {
                NextIndex = (GetBrightIndex(Current.gameObject.GetInstanceID()) + BrightsInRange.Count - 1) % BrightsInRange.Count;
                int cursor = 0;
                while (!CheckLineofSight(BrightsInRange[NextIndex].transform) && (cursor < BrightsInRange.Count - 1))
                {
                    NextIndex++;
                    NextIndex %= BrightsInRange.Count;
                    cursor++;
                }
                SetView(BrightsInRange[NextIndex].transform);
            }
        }
        else
        {
            if (HostilesInCombat())
            {
                NextIndex = (GetHostileIndex(Current.gameObject.GetInstanceID()) + HostilesInRange.Count - 1) % HostilesInRange.Count;
                int cursor = 0;
                while (!CheckLineofSight(HostilesInRange[NextIndex].transform) && (cursor < HostilesInRange.Count - 1))
                {
                    NextIndex++;
                    NextIndex %= HostilesInRange.Count;
                    cursor++;
                }
                SetView(HostilesInRange[NextIndex].transform);
            }
            else if (ObjectsInRange.Count > 0)
            {
                NextIndex = (GetObjectIndex(Current.gameObject.GetInstanceID()) + 1) % ObjectsInRange.Count;
                if (ObjectsInRange.Count > 1)
                {
                    int AimedIndex = -1;
                    float AimedDistance = Vector3.Distance(transform.position, ObjectsInRange[NextIndex].transform.position);
                    for (int a = 0; a < NextIndex; a++)
                    {
                        if (Vector3.Distance(transform.position, ObjectsInRange[a].transform.position) < AimedDistance)
                        {
                            AimedIndex = a;
                            AimedDistance = Vector3.Distance(transform.position, ObjectsInRange[a].transform.position);
                        }
                    }
                    if (AimedIndex != -1)
                    {
                        NextIndex = AimedIndex;
                    }
                    else
                    {
                        if (NextIndex > 0)
                            NextIndex--;
                        else
                        {
                            NextIndex += ObjectsInRange.Count - 1;
                            NextIndex %= ObjectsInRange.Count;
                        }
                    }
                }
                SetView(ObjectsInRange[NextIndex].transform);
            }
            else
                SetView(DefaultTarget);
        }
        plObj.GetComponent<player_stats>().RefreshTargetDisplay(GetTarget().GetComponent<worldObject>());
    }

    int GetHostileIndex(int HostileID)
    {
        for (int a = 0; a < HostilesInRange.Count; a++)
        {
            if (HostilesInRange[a].GetInstanceID() == HostileID)
                return a;
        }
        return -1;
    }

    int GetObjectIndex(int ObjectID)
    {
        for (int a = 0; a < ObjectsInRange.Count; a++)
        {
            if (ObjectsInRange[a].GetInstanceID() == ObjectID)
                return a;
        }
        return -1;
    }

    int GetBrightIndex(int BrightID)
    {
        for (int a = 0; a < BrightsInRange.Count; a++)
        {
            if (BrightsInRange[a].GetInstanceID() == BrightID)
                return a;
        }
        return -1;
    }

    Transform GetNearestObject()
    {
        int NearestIndex = -1;
        float NearestDistance = 75f;
        for (int a = 0; a < ObjectsInRange.Count; a++)
        {

            if (NearestDistance > Vector3.Distance(ObjectsInRange[a].transform.position, transform.position))
            {
                NearestDistance = Vector3.Distance(ObjectsInRange[a].transform.position, transform.position);
                NearestIndex = a;
            }
        }
        return ObjectsInRange[NearestIndex].transform;
    }

    bool CheckLineofSight()
    {
        RaycastHit myAttempt;
        if (Physics.Raycast(transform.position, CurrentTarget.position - transform.position, out myAttempt, 40))
        {
            if (myAttempt.transform == CurrentTarget)
                return true;
            else
                return false;
        }
        else
            return false;
    }


    bool CheckLineofSight(Transform specTar)
    {
        RaycastHit myAttempt;
        if (Physics.Raycast(transform.position, specTar.position - transform.position, out myAttempt, 40))
        {
            if (myAttempt.transform == specTar)
                return true;
            else
                return false;
        }
        else
            return false;
    }

    bool HostilesInCombat()
    {
        if (HostilesInRange.Count > 0)
        {
            for (int a = 0; a < HostilesInRange.Count; a++)
            {
                if (CheckLineofSight(HostilesInRange[a].transform))
                    return true;
            }
            return false;
        }
        else
            return false;
    }

    Transform CheckAnySightings()
    {
        if (TargetingBrights)
        {
            for (int a = 0; a < BrightsInRange.Count; a++)
            {
                if (CheckLineofSight(BrightsInRange[a].transform))
                    return BrightsInRange[a].transform;
            }
        }
        else
        {
            if (HostilesInCombat())
            {
                for (int a = 0; a < HostilesInRange.Count; a++)
                {
                    if (CheckLineofSight(HostilesInRange[a].transform))
                        return HostilesInRange[a].transform;
                }
            }
            else
            {
                for (int a = 0; a < ObjectsInRange.Count; a++)
                {
                    if (CheckLineofSight(ObjectsInRange[a].transform))
                        return ObjectsInRange[a].transform;
                }
            }
        }
        return null;
    }

    Transform GetNearestHostile()
    {
        int NearestIndex = -1;
        float NearestDistance = 75f;
        for (int a = 0; a < HostilesInRange.Count; a++)
        {
            if (NearestDistance > Vector3.Distance(HostilesInRange[a].transform.position, transform.position))
            {
                NearestDistance = Vector3.Distance(HostilesInRange[a].transform.position, transform.position);
                NearestIndex = a;
            }
        }
        return HostilesInRange[NearestIndex].transform;
    }

    Transform GetNearestBright()
    {
        int NearestIndex = -1;
        float NearestDistance = 75f;
        for (int a = 0; a < BrightsInRange.Count; a++)
        {
            if (NearestDistance > Vector3.Distance(BrightsInRange[a].transform.position, transform.position))
            {
                NearestDistance = Vector3.Distance(BrightsInRange[a].transform.position, transform.position);
                NearestIndex = a;
            }
        }
        return BrightsInRange[NearestIndex].transform;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.transform.gameObject.tag != "Player")
        {
            if (other.transform.gameObject.GetComponent<BeamReflection>())
            {
                BrightsInRange.Add(other.transform.gameObject);
            }
            else if (other.transform.gameObject.GetComponent<automated>())
            {
                HostilesInRange.Add(other.transform.gameObject);
            }
            else if (other.transform.gameObject.GetComponent<interactable>())
            {
                ObjectsInRange.Add(other.transform.gameObject);
            }
            RefreshFocus();
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.transform.gameObject.GetComponent<BeamReflection>())
        {
            BrightsInRange.Remove(other.transform.gameObject);
        }
        else if (other.transform.gameObject.GetComponent<automated>())
        {
            int Index = GetHostileIndex(other.transform.gameObject.GetInstanceID());
            if (Index > -1)
            {
                HostilesInRange.RemoveAt(Index);
            }
        }
        else if (other.transform.gameObject.GetComponent<interactable>())
        {
            int Index = GetObjectIndex(other.transform.gameObject.GetInstanceID());
            if (Index > -1)
                ObjectsInRange.RemoveAt(Index);
        }
        RefreshFocus();
    }

    public void RemoveCur()
    {
        int tarid = GetTarget().gameObject.GetInstanceID();
        int myindex;
        if (GetHostileIndex(tarid) > -1)
        {
            myindex = GetHostileIndex(tarid);
            if (HostilesInRange.Count > 0)
                CurrentTarget = GetNearestHostile();
            else
                CurrentTarget = GetNearestObject();
            Destroy(HostilesInRange[myindex]);
            HostilesInRange.RemoveAt(myindex);
        } else if (GetObjectIndex(tarid)> -1)
        {
            myindex = GetObjectIndex(tarid);
            if (ObjectsInRange.Count > 0)
                CurrentTarget = GetNearestObject();
            Destroy(ObjectsInRange[myindex]);
            ObjectsInRange.RemoveAt(myindex);
        }
        else if (GetBrightIndex(tarid) > -1)
        {
            myindex = GetBrightIndex(tarid);
            if (BrightsInRange.Count > 0)
                CurrentTarget = GetNearestBright();
            else
                CurrentTarget = GetNearestObject();
            Destroy(BrightsInRange[myindex]);
            BrightsInRange.RemoveAt(myindex);
        }
        //GameObject mytar = GetTarget().gameObject;
        //if (mytar.transform.gameObject.GetComponent<BeamReflection>())
        //{
        //    BrightsInRange.Remove(mytar.transform.gameObject);
        //}
        //else if (mytar.transform.gameObject.GetComponent<automated>())
        //{
        //    int Index = GetHostileIndex(mytar.transform.gameObject.GetInstanceID());
        //    if (Index > -1)
        //    {
        //        HostilesInRange.RemoveAt(Index);
        //    }
        //}
        //else if (mytar.transform.gameObject.GetComponent<interactable>())
        //{
        //    int Index = GetObjectIndex(mytar.transform.gameObject.GetInstanceID());
        //    if (Index > -1)
        //        ObjectsInRange.RemoveAt(Index);
        //}
        RefreshFocus();
    }


    public void RemoveObjTarget(Transform Obj)
    {
        int a = ObjectsInRange.IndexOf(Obj.gameObject);
        ObjectsInRange.RemoveAt(a);
        RefreshFocus();
    }

    public void RemoveHosTarget(Transform Hos)
    {
        int a = HostilesInRange.IndexOf(Hos.gameObject);
        ObjectsInRange.RemoveAt(a);
        RefreshFocus();
    }
    public void RemoveBrTarget(Transform Brig)
    {
        int a = BrightsInRange.IndexOf(Brig.gameObject);
        ObjectsInRange.RemoveAt(a);
        RefreshFocus();
    }
}