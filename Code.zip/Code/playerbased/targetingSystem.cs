﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class targetingSystem : MonoBehaviour {
	[SerializeField] private List<GameObject> InRange = new List<GameObject>();
	[SerializeField] private int selected = -1;
	private GameObject controllerObj;
    public bool isMouseOver;


	void Start()
	{
		controllerObj = GameObject.Find("GameController");
	}

	public void AddInRange (GameObject newinrange)
	{
		if (!InRange.Contains(newinrange)) {
            if (selected >= 0)
                if (InRange[selected] != null)
                    InRange[selected].GetComponent<worldObject>().UnSelectThisOne();
                else
                    RemoveFromRange(InRange[selected]);
			InRange.Add(newinrange);
			selected = selected + InRange.Count - 1;
            selected %= InRange.Count;
			InRange[selected].GetComponent<worldObject>().SelectThisOne();
		}
	}

	public void RemoveFromRange (GameObject notinrange)
	{
		if (InRange.Contains(notinrange)&&(notinrange != null))
		{
			InRange[InRange.IndexOf(notinrange)].GetComponent<worldObject>().UnSelectThisOne ();
			InRange.Remove (notinrange);
			if (InRange.Count <= 0)
				selected = -1;
			else if (selected > InRange.Count - 1)
				selected = InRange.Count - 1;
			else
				selected--;
		}
	}

	public void NextNearestTarget()
	{
        int nearestindex = selected+1;
        float nearestdist = 300;
        float currentdist;
        InRange[selected].GetComponent<worldObject>().UnSelectThisOne();
        if (selected >= InRange.Count - 1)
            NextTarget();
        else
        {
            for (int a = selected; a < InRange.Count - selected; a++)
            {
                currentdist = Vector3.Distance(transform.position, InRange[selected].transform.position);
                if (currentdist < nearestdist)
                {
                    nearestdist = currentdist;
                    nearestindex = a;
                }
            }
            selected = nearestindex;
        InRange[selected].GetComponent<worldObject>().SelectThisOne();
        }
    }
	public void NextTarget()
	{
		if (InRange.Count > 0) {
			InRange[selected].GetComponent<worldObject>().UnSelectThisOne();
			selected++;
			selected %= InRange.Count;
            if (InRange[selected] != null)
                InRange[selected].GetComponent<worldObject>().SelectThisOne();
            else
            {
                InRange.RemoveAt(selected);
                NextTarget();
            }
		}
	}

    public void JustLooted()
    {
        InRange.RemoveAt(selected);
    }

	void Update()
	{
        if (!isMouseOver)
        {
            if (Input.GetButtonUp("NextTarget"))
            {
                NextTarget();
            }

            if (Input.GetButtonUp("NextNearestTarget"))
            {
                NextNearestTarget();
            }

            if (Input.GetButtonUp("Pickup/Interact"))
            {
                InRange[selected].GetComponent<worldObject>().OnUse();
            }

            if (Input.GetButtonUp("Inspect"))
            {
                string thetext = "";
                if (InRange[selected].GetComponent<worldObject>())
                    thetext = InRange[selected].GetComponent<worldObject>().OnInspect();
            }
        }
	}
}
