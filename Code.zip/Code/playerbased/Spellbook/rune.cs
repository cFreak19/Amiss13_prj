﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using A13_theCurse_GameConst;


[Serializable]
public class rune
{
    public Sprite runeIcon;
    public string RuneTag, function;
    public GameConstants.RuneType type;
    public int Rank, cost, amount;


    public string GetString()
    {
        return RuneTag + " " + type.ToString() + "\n Rank Lv." + Rank.ToString() + "\n  Function: " + function;
    }
}
