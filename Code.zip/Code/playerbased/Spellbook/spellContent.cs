﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using A13_theCurse_GameConst;
 

public class spellContent : MonoBehaviour {
    public AudioClip ExplodeSFX, ImplodeSFX, EmpowerSfX;
    public GameObject target;
    public Applied_Effect result;
    public GameObject[] particleTypes;
    public int effectAmount, schoolType, WillModAmount;
    public int SpellSchool;
    public float speedmult;
    private float magnitude;
    public float duration;
    public float dCount;
    public Vector3 relativeSpawnPos, direction;
    public bool DestroyedOnCollision, areaEffect, knocksback, hostileSpell;
    public bool partTriggers, jumptoTarget;
    private ParticleSystem psC;
    private Vector3 initialWPos = Vector3.zero;

    private void Awake()
    {
        initialWPos = transform.position;
    }

    void Start () {
        psC = GetComponent<ParticleSystem>();
        direction = new Vector3(GameObject.Find("Main Camera").transform.forward.x,0, GameObject.Find("Main Camera").transform.forward.z).normalized;
    }

    IEnumerator DestroyTimer()
    {
        yield return new WaitForSeconds(duration);
        Destroy(gameObject);
    }

    void ScaleUp()
    {
        if (GetComponent<SphereCollider>().radius < 5)
            GetComponent<SphereCollider>().radius += 1f;
    }


    private void OnParticleTrigger()
    {
        
    } 

    void OnTriggerEnter(Collider other)
    {
        if ((other.transform.gameObject.GetComponent<automated>())&&(partTriggers))
        {
            if (duration > 0)
            {
                other.transform.gameObject.GetComponent<automated>().CurrentlyApplying.Add(result);
            }
            else
            other.gameObject.GetComponent<automated>().GetHurt(result);
            if ((other.gameObject.GetComponent<Rigidbody>())&&(areaEffect))
            {
                other.gameObject.GetComponent<Rigidbody>().AddExplosionForce(4f, other.ClosestPoint(transform.position), 5);
                
            }
            else if (DestroyedOnCollision)
            {
                Destroy(transform.gameObject);
            }
        }
    }

    public void InitRitualSpell()
    {
        result.Init();
        magnitude = effectAmount / 2;
        if (areaEffect)
        {
            effectAmount /= 10;
        }
    }
    

    void DestroyAnim()
    {

    }

    void CastEffects()
    {
        StartCoroutine(DestroyTimer());
    }

    public void Activate()
    {
        if ((target.GetComponent<automated>())&&(!hostileSpell))
        {
                if ((target.GetComponent<Rigidbody>())&&(knocksback))
                target.GetComponent<Rigidbody>().AddExplosionForce(magnitude, transform.position, GetComponent<SphereCollider>().radius, 8);
            //if (!areaEffect)
            //{
            //    dCount = 0;
            //    InvokeRepeating("DotMeup", 1f, 1f);
            //}
            target.GetComponent<automated>().GetCast(result);
            target.GetComponent<automated>().CurrentlyApplying.Add(result);
            if (DestroyedOnCollision)
                Destroy(gameObject);
        }

        if ((target.gameObject.tag == "Player")&&(hostileSpell))
        {
            target.GetComponent<player_stats>().GetCast(result);
        }
    }

    void DotMeup()
    {
        if ((target != null) && (target != transform.gameObject) && (dCount <= duration) && (target.GetComponent<automated>()))
        {
            target.GetComponent<automated>().GetCast(result);
            dCount += 0.5f;
        }
    }
    
    void Update () {
        if ((!areaEffect)&&(target != null)&&(target != gameObject)&&(!jumptoTarget))
        {
            Vector3 MyDistance = target.transform.position - transform.position;
            direction = -1*MyDistance.normalized;
            transform.position += direction * speedmult / 2;
        }
        if (jumptoTarget)
            transform.position = target.transform.position;
        if (areaEffect)
        {
            if (!GetComponent<ParticleSystem>().isPlaying)
                Destroy(gameObject);
        }

        if (Vector3.Distance(initialWPos, transform.position) > result.range)
            Destroy(gameObject);

	}
}
