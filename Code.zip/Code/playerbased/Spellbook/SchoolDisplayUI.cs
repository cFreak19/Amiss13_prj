﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
 
using UnityEngine.UI;

public class SchoolDisplayUI : MonoBehaviour {
    public GameObject[] SchoolDisplays = new GameObject[5];
    //public RawImage DisplayObject;
    public int DisplayedSchool;


    public void SetSchool(int schoolNo)
    {
//        DisplayedSchool = schoolNo;
//        DisplayObject.texture = SchoolDisplays[schoolNo].GetComponent<RawImage>().texture;
        GameObject.Find("Player_Object").GetComponent<RuneBase>().SetSchool(schoolNo);
        for (int a = 0; a < SchoolDisplays.Length; a++)
        {
            SchoolDisplays[a].SetActive(false);
        }
    }

    private void OnMouseDown()
    {   
        for(int a = 0; a < SchoolDisplays.Length; a++)
        {
            SchoolDisplays[a].SetActive(true);
        }
    }

    
	
	// Update is called once per frame
	void Update () {
		
	}
}
