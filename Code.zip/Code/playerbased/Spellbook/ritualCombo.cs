﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

[Serializable]
    public class ritualCombo
{
    public int inner, outer;
    public int[] majorMultipliers = new int[4];
    public int[] minorMultipliers = new int[4];
    public bool isComplete = false;

    private int combinedValue, combinedCost;

    public void SetRunes(int first, int second)
    {
        outer = first;
        inner = second;
        isComplete = true;
    }
    
    public void SetCandV(int c, int v)
    {
        combinedCost = c;
        combinedValue = v;
    }

    public int getCost()
    {
        return combinedCost;
    }

    public void CastOut()
    {
        isComplete = false;
        outer = -1;
        inner = -1;
    }
}
