﻿using A13_theCurse_GameConst;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class RuneBase : MonoBehaviour
{
    [Header("Basic Spell Data")]
    [SerializeField]
    private List<rune> RunesList = new List<rune>();
    public GameObject AreaSpell, TarShockSpell, TarBurnSpell, EmpowerSpell, TarModifySpell;
    public Gradient PureGradient, ShadowGradient, MentalGradient, BlessedGradient;
    [SerializeField]
    private GameObject[] Runehangers = new GameObject[7];
    public ritualCombo[] thetrio = new ritualCombo[3];
    [SerializeField]
    //private List<ritualCombo> mycombolist = new List<ritualCombo>();
    private int CurrentSchool = 8;
    private int RuneComboCounter = 0;

    [Header("Secondary Requirements")]
    public GameObject conjureSource;

    [Header("Basic Stats")]
    public float spellRange;
    public Animator myanim;
    public int CycleLocks = 1;
    public GameConstants.EffectType curType;
    public bool spellsDisabled = false;

    [Header("Spell Audio")]
    public AudioClip RuneCastSFX, RitualCastSFX, SpellFailSFX;
    public AudioSource SFXSource;

    public void UnlockCycle()
    {
        if (CycleLocks < 3)
        {
            CycleLocks++;
        }
    }

    public string getRuneName(int a)
    {
        return RunesList[a].function;
    }

    public void SetSchool(int a)
    {
		if (RunesList [8 + a].Rank > 0) {
			CurrentSchool = 8 + a;
			GameObject.Find ("SchoolRuneD").GetComponent<RawImage>().texture = RunesList[8+a].runeIcon.texture;
		}
    }

    public void RankUp(int a)
    {
        RunesList[a].Rank++;
    }
    
    public void RankUp(string a)
    {
        for (int b = 0; b < RunesList.Count; b++)
        {
            if (RunesList[b].RuneTag == a)
            {
                RunesList[b].Rank++;
            }
        }
    }

    public int getRank(int order)
    {
        return RunesList[order].Rank;
    }

    public void InitRunes(int[] RuneRanks)
    {
        for (int a = 0; a < RuneRanks.Length; a++)
        {
            RunesList[a].Rank = RuneRanks[a];
        }
    }

    // Use this for initialization
    void Start()
    {
        RuneComboCounter = 0;
        myanim.SetInteger("runeorder", 0);
    }
    

    private void Fizzle()
    {
        RuneComboCounter = 0;
        myanim.SetInteger("runeorder", 0);
    }

    private IEnumerator Cooloff()
    {
        yield return new WaitForSeconds(0.6F);
    }


    void GetTrio ()
    {

    }

    Gradient GetSpellGrad(int index)
    {
        //PureGradient, ShadowGradient, MentalGradient, BlessedGradient;
        switch (index)
        {
            case 0:
                return PureGradient;
            case 1:
                return ShadowGradient;
            case 2:
                return MentalGradient;
            case 3:
                return BlessedGradient;
            default:
                return PureGradient;
        }
    }

    //public void DummyRitual(int CastSpell,int spelltype, Vector3 pos)
    //{
    //    Gradient curGr = GetSpellGrad(spelltype);
    //    if (!GetComponent<Online_pl_stats>().thisPlayer)
    //    {
    //        GameObject mysp;
    //        switch (CastSpell)//AreaSpell, TarShockSpell, TarBurnSpell, EmpowerSpell, TarModifySpell
    //        {
    //            case 0:
    //                mysp = Instantiate(AreaSpell, pos,Quaternion.identity) as GameObject;
    //                mysp.GetComponent<SphereCollider>().enabled = false;                    
    //                break;
    //            case 1:
    //                mysp = Instantiate(TarShockSpell, pos, Quaternion.identity) as GameObject;
    //                mysp.GetComponent<SphereCollider>().enabled = false;
    //                break;
    //            case 2:
    //                mysp = Instantiate(EmpowerSpell, pos, Quaternion.identity) as GameObject;
    //                mysp.GetComponent<SphereCollider>().enabled = false;
    //                break;
    //            case 3:
    //                mysp = Instantiate(TarModifySpell, pos, Quaternion.identity) as GameObject;
    //                mysp.GetComponent<SphereCollider>().enabled = false;
    //                break;
    //            default:
    //                mysp = Instantiate(AreaSpell, pos, Quaternion.identity) as GameObject;
    //                mysp.GetComponent<SphereCollider>().enabled = false;
    //                break;
    //        }
    //        mysp.GetComponent<ParticleSystem>().colorOverLifetime.color.gradient.SetKeys(curGr.colorKeys, curGr.alphaKeys);
    //    }
    //}

    void MakeNoise (AudioClip SFXv)
    {
        SFXSource.Stop();
        SFXSource.clip = SFXv;
        SFXSource.Play();
    }

    // Update is called once per frame
    void Update()
    {
        if ((!myanim.GetBool("animating"))&&(myanim.GetBool("GamePlayActive"))&&(RuneComboCounter >= 0)&&(RuneComboCounter<6))
        {
            if ((RuneComboCounter < CycleLocks*2)&&(!spellsDisabled))
            {
                if (Input.GetButtonDown("Rune 1")||((Input.GetButtonDown("RuneInterfaceToggle") && Input.GetButtonDown("Gamepad Rune 1"))))
                {
                    if ((RunesList[0].Rank > 0)&&(RuneComboCounter % 2 == 0))
                    {
                        Runehangers[RuneComboCounter].GetComponent<Image>().sprite = RunesList[0].runeIcon;
                        thetrio[(RuneComboCounter % 6) / 2].outer = 0;
                        Runehangers[RuneComboCounter].SetActive(true);
                        RuneComboCounter++;
                        MakeNoise(RuneCastSFX);
                    }
                    else if (RunesList[4].Rank > 0)
                    {
                        Runehangers[RuneComboCounter].GetComponent<Image>().sprite = RunesList[4].runeIcon;
                        thetrio[(RuneComboCounter % 6) / 2].inner = 4;
                        Runehangers[RuneComboCounter].SetActive(true);
                        RuneComboCounter++;
                        MakeNoise(RuneCastSFX);
                        thetrio[RuneComboCounter / 2-1].isComplete = true;
                    }
                }

                if (Input.GetButtonDown("Rune 2")|| ((Input.GetButtonDown("RuneInterfaceToggle") && Input.GetButtonDown("Gamepad Rune 2"))))
                {

                    if ((RunesList[1].Rank > 0)&&(RuneComboCounter % 2 == 0))
                    {
                        Runehangers[RuneComboCounter].GetComponent<Image>().sprite = RunesList[1].runeIcon;
                        thetrio[(RuneComboCounter % 6) / 2].outer = 1;
                        Runehangers[RuneComboCounter].SetActive(true);
                        RuneComboCounter++;
                        MakeNoise(RuneCastSFX);
                    }
                    else if (RunesList[5].Rank > 0)
                    {
                        Runehangers[RuneComboCounter].GetComponent<Image>().sprite = RunesList[5].runeIcon;
                        thetrio[(RuneComboCounter % 6) / 2].inner = 5;
                        Runehangers[RuneComboCounter].SetActive(true);
                        RuneComboCounter++;
                        thetrio[RuneComboCounter / 2-1].isComplete = true;
                        MakeNoise(RuneCastSFX);
                    }
                }
                if (Input.GetButtonDown("Rune 3")|| ((Input.GetButtonDown("RuneInterfaceToggle") && Input.GetButtonDown("Gamepad Rune 3"))))
                {
                    if ((RunesList[2].Rank>0)&&(RuneComboCounter % 2 == 0))
                    {
                        Runehangers[RuneComboCounter].GetComponent<Image>().sprite = RunesList[2].runeIcon;
                        thetrio[(RuneComboCounter % 6) / 2].outer = 2;
                        Runehangers[RuneComboCounter].SetActive(true);
                        RuneComboCounter++;

                        MakeNoise(RuneCastSFX);
                    }
                    else if (RunesList[6].Rank>0)
                    {
                        Runehangers[RuneComboCounter].GetComponent<Image>().sprite = RunesList[6].runeIcon;
                        thetrio[(RuneComboCounter % 6) / 2].inner = 6;
                        Runehangers[RuneComboCounter].SetActive(true);
                        RuneComboCounter++;
                        thetrio[RuneComboCounter / 2 - 1].isComplete = true;

                        MakeNoise(RuneCastSFX);
                    }
                }

                if (Input.GetButtonDown("Rune 4")|| ((Input.GetButtonDown("RuneInterfaceToggle") && Input.GetButtonDown("Gamepad Rune 4"))))
                {
                    if ((RunesList[3].Rank>0)&&(RuneComboCounter % 2 == 0))
                    {
                        Runehangers[RuneComboCounter].GetComponent<Image>().sprite = RunesList[3].runeIcon;
                        thetrio[(RuneComboCounter % 6) / 2].outer = 3;
                        Runehangers[RuneComboCounter].SetActive(true);
                        RuneComboCounter++;
                        MakeNoise(RuneCastSFX);
                    }
                    else if (RunesList[7].Rank > 0)
                    {
                        Runehangers[RuneComboCounter].GetComponent<Image>().sprite = RunesList[7].runeIcon;
                        thetrio[(RuneComboCounter % 6) / 2].inner = 7;
                        Runehangers[RuneComboCounter].SetActive(true);
                        RuneComboCounter++;
                        thetrio[RuneComboCounter / 2-1].isComplete = true;
                        MakeNoise(RuneCastSFX);
                    }
                }
            }
            if ((!spellsDisabled)&&(Input.GetButtonDown("Cast Ritual")|| ((Input.GetButtonDown("RuneInterfaceToggle")&&(Input.GetButtonDown("Fire1"))))&&(RuneComboCounter >= 2)))
            {
                if (CurrentSchool < 12)
                {
                    int totalcost = 0;
                    if (CycleLocks > 0)
                        totalcost += GetCost(0);
                    if (CycleLocks > 1)
                        totalcost += GetCost(1);
                    if (CycleLocks > 2)
                        totalcost += GetCost(2);
                    if (GetComponent<player_stats>().curWillP >= totalcost)
                    {
                        GetComponent<player_stats>().SpendWillP(totalcost);
                        MakeNoise(RitualCastSFX);
                        StartCoroutine(RitualCast());
                    }
                    else
                    {
                        MakeNoise(SpellFailSFX);
                    }
                } 
            }
        }
    }




    int GetSpecCCost(int outer, int inner)
    {
        int a = RunesList[outer].cost * RunesList[inner].Rank;
        switch (RunesList[inner].function)
        {
            case "Additive":
                a += RunesList[inner].cost * RunesList[inner].Rank;
                break;
            case "Subtractive":
                a -= RunesList[inner].cost * RunesList[inner].Rank;
                break;
            case "Multiply":
                a *= RunesList[inner].cost * RunesList[inner].Rank / 3;
                break;
            case "Pierce":
                a += RunesList[inner].cost * RunesList[inner].Rank *2; //will get modified.
                break;
        }
        return a;
    }

    int GetCost(int a)
    {
        return GetSpecCCost(thetrio[a].outer,thetrio[a].inner);
    }

    int GetSpecCValue(int outer, int inner)
    {
        int a = RunesList[outer].amount * RunesList[inner].Rank;
        switch (RunesList[inner].function)
        {
            case "Additive":
                a += RunesList[inner].amount * RunesList[inner].Rank;
                break;
            case "Subtractive":
                a -= RunesList[inner].amount * RunesList[inner].Rank;
                break;
            case "Multiply":
                a *= RunesList[inner].amount* RunesList[inner].Rank / 3;
                break;
            case "Pierce":
                a += RunesList[inner].amount * RunesList[inner].Rank; //will get fixed.
                break;
        }

        return a;
    }


    int GetValue(int a)
    {
        return GetSpecCValue(thetrio[a].outer, thetrio[a].inner);
    }

    public void CastRt()
    {

    }

    public void CastRt(ritualCombo[] trio)
    {
        thetrio = trio;
    }

    IEnumerator RitualCast()
    {
        RuneComboCounter = 0;
        for (int a = 0; a < Runehangers.Length; a++)
        {
            Runehangers[a].SetActive(false);
        }

        myanim.SetInteger("animationNumber", 3);
        myanim.SetBool("animating", true);
        if ((thetrio[0].isComplete)&&(CycleLocks > 0))
        {

            GameObject curSpell = new GameObject();
            if (thetrio[0].outer == 0)
            {
                curSpell = Instantiate(AreaSpell,conjureSource.transform.position,Quaternion.identity) as GameObject;
            }
            else if (thetrio[0].outer == 1)
            {
                GameObject thisTarget = conjureSource.GetComponent<targetFocus>().GetTarget().gameObject;
                
                if (thisTarget.transform.gameObject.GetComponent<automated>())
                {
                     thisTarget = thisTarget.transform.gameObject;
                }
                if (thisTarget != null)
                {
                    curSpell = Instantiate(TarShockSpell, thisTarget.transform.position, Quaternion.identity) as GameObject;
                    curSpell.GetComponent<spellContent>().target = thisTarget;
                }
                else
                    curSpell = Instantiate(TarShockSpell, conjureSource.transform.position, Quaternion.identity) as GameObject;
            }
            else if (thetrio[0].outer == 2)
            {
                curSpell = Instantiate(EmpowerSpell, transform.position, Quaternion.identity);
            } else 
            {
                GameObject thisTarget = conjureSource.GetComponent<targetFocus>().GetTarget().gameObject;
                
                    if (thisTarget.transform.gameObject.GetComponent<automated>())
                    {
                        thisTarget = thisTarget.transform.gameObject;
                    }
                if (thisTarget != null)
                {
                    curSpell = Instantiate(TarModifySpell, thisTarget.transform.position, Quaternion.identity) as GameObject;
                }
            }
            Gradient particleColor = new Gradient();
            switch (CurrentSchool)
            {
                case 8:
                    curSpell.GetComponent<spellContent>().result.mytype = GameConstants.EffectType.Burn;
                    curSpell.GetComponent<spellContent>().result.duration += 3;
                    curSpell.GetComponent<ParticleSystem>().colorOverLifetime.color.gradient.SetKeys(PureGradient.colorKeys,PureGradient.alphaKeys);
                    break;
                case 9:
                    curSpell.GetComponent<spellContent>().result.mytype = GameConstants.EffectType.Curse;
                    curSpell.GetComponent<spellContent>().result.duration += 6;
                    curSpell.GetComponent<ParticleSystem>().colorOverLifetime.color.gradient.SetKeys(ShadowGradient.colorKeys, ShadowGradient.alphaKeys);
                    break;
                case 10:
                    curSpell.GetComponent<spellContent>().result.mytype = GameConstants.EffectType.Daze;
                    curSpell.GetComponent<spellContent>().result.duration += 2;
                    curSpell.GetComponent<ParticleSystem>().colorOverLifetime.color.gradient.SetKeys(MentalGradient.colorKeys, MentalGradient.alphaKeys);
                    break;
                case 11:
                    curSpell.GetComponent<spellContent>().result.mytype = GameConstants.EffectType.Modify;
                    curSpell.GetComponent<ParticleSystem>().colorOverLifetime.color.gradient.SetKeys(BlessedGradient.colorKeys, BlessedGradient.alphaKeys);
                    curSpell.GetComponent<spellContent>().result.duration += 6;
                    break;
                default:
                    break;
            }
            //GameObject curSpell = Instantiate(spellPrefab, conjureSource.transform.position, Quaternion.identity) as GameObject;
            //GameObject curPart = Instantiate(Particles[(CurrentSchool - 8) + (4*(thetrio[0].inner -4))], Vector3.zero, Quaternion.identity) as GameObject;
            curSpell.GetComponent<spellContent>().SpellSchool = CurrentSchool;
            curSpell.GetComponent<spellContent>().result.wisbonus = (GetComponent<player_stats>().myActiveProfile.PlayerStats[3].statAmount + GetComponent<player_stats>().myActiveProfile.PlayerStats[3].statBonus);
            curSpell.GetComponent<spellContent>().result.spellrank1 = RunesList[thetrio[0].outer].Rank;
            curSpell.GetComponent<spellContent>().result.spellrank2 = RunesList[thetrio[0].inner].Rank;
            curSpell.GetComponent<spellContent>().result.spellLevel = GetComponent<player_stats>().myActiveProfile.Level;
            curSpell.GetComponent<spellContent>().effectAmount += GetValue(0);
            curSpell.GetComponent<spellContent>().WillModAmount += GetCost(0);
            yield return new WaitForSeconds(0.1f);
            
            if ((thetrio[1].isComplete) && (CycleLocks > 1))
            {
                curSpell = new GameObject();
                curSpell.GetComponent<spellContent>().result.wisbonus += (GetComponent<player_stats>().myActiveProfile.PlayerStats[3].statAmount + GetComponent<player_stats>().myActiveProfile.PlayerStats[3].statBonus);
                curSpell.GetComponent<spellContent>().result.spellrank1 += RunesList[thetrio[1].outer].Rank;
                curSpell.GetComponent<spellContent>().result.spellrank2 += RunesList[thetrio[1].inner].Rank;
                curSpell.GetComponent<spellContent>().result.spellLevel += GetComponent<player_stats>().myActiveProfile.Level;
                curSpell.GetComponent<spellContent>().effectAmount += GetValue(1);
                curSpell.GetComponent<spellContent>().WillModAmount += GetCost(1);

                switch (CurrentSchool)
                {
                    case 8:
                        curSpell.GetComponent<spellContent>().result.mytype = GameConstants.EffectType.Burn;
                        curSpell.GetComponent<spellContent>().result.duration += 3;
                        break;
                    case 9:
                        curSpell.GetComponent<spellContent>().result.mytype = GameConstants.EffectType.Curse;
                        curSpell.GetComponent<spellContent>().result.duration += 6;
                        break;
                    case 10:
                        curSpell.GetComponent<spellContent>().result.mytype = GameConstants.EffectType.Daze;
                        curSpell.GetComponent<spellContent>().result.duration += 2;
                        break;
                    case 11:
                        curSpell.GetComponent<spellContent>().result.mytype = GameConstants.EffectType.Modify;
                        curSpell.GetComponent<spellContent>().result.duration += 6;
                        break;
                    default:
                        break;
                }

                yield return new WaitForSeconds(0.1f);
                if ((thetrio[2].isComplete) && (CycleLocks > 2))
                {
                    curSpell.GetComponent<spellContent>().SpellSchool = CurrentSchool;
                    curSpell.GetComponent<spellContent>().result.wisbonus += (GetComponent<player_stats>().myActiveProfile.PlayerStats[3].statAmount + GetComponent<player_stats>().myActiveProfile.PlayerStats[3].statBonus);
                    curSpell.GetComponent<spellContent>().result.spellrank1 += RunesList[thetrio[2].outer].Rank;
                    curSpell.GetComponent<spellContent>().result.spellrank2 += RunesList[thetrio[2].inner].Rank;
                    curSpell.GetComponent<spellContent>().result.spellLevel = GetComponent<player_stats>().myActiveProfile.Level;
                    curSpell.GetComponent<spellContent>().effectAmount += GetValue(2);
                    curSpell.GetComponent<spellContent>().WillModAmount += GetCost(2);
                    switch (CurrentSchool)
                    {
                        case 8:
                            curSpell.GetComponent<spellContent>().result.mytype = GameConstants.EffectType.Burn;
                            curSpell.GetComponent<spellContent>().result.duration += 3;
                            break;
                        case 9:
                            curSpell.GetComponent<spellContent>().result.mytype = GameConstants.EffectType.Curse;
                            curSpell.GetComponent<spellContent>().result.duration += 6;
                            break;
                        case 10:
                            curSpell.GetComponent<spellContent>().result.mytype = GameConstants.EffectType.Daze;
                            curSpell.GetComponent<spellContent>().result.duration += 2;
                            break;
                        case 11:
                            curSpell.GetComponent<spellContent>().result.mytype = GameConstants.EffectType.Modify;
                            curSpell.GetComponent<spellContent>().result.duration += 6;
                            break;
                        default:
                            break;
                    }
                }
            }
            if (curSpell.GetComponent<spellContent>())
                curSpell.GetComponent<spellContent>().InitRitualSpell();
            yield return new WaitForSeconds(0.1f);
            thetrio[0].CastOut();
            thetrio[1].CastOut();
            thetrio[2].CastOut();
            myanim.SetInteger("animationNumber", 0);
            myanim.SetBool("animating", false);
        }
    }       
}
