﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SetASchool : MonoBehaviour {
    public GameObject parent;
    public int schooltoSet;

	void OnMouseDown()
    {
        parent.GetComponent<SchoolDisplayUI>().SetSchool(schooltoSet);
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
