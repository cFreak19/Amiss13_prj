﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
using A13_theCurse_GameConst;
 

[Serializable]
public class Applied_Effect{
    public int spellrank1, spellrank2, basedamage, statSlot;
    public float wisbonus, wismult;
    public GameConstants.EffectType mytype;
    public int duration, remTurns, spellLevel, WCost;
    public float range;

    public void Init()
    {
        wismult = 1;
        remTurns = duration;
    }


    public int GetDamage()
    {
        Debug.Log("Sent damage: " + (spellrank1 * spellrank2 * (basedamage + wisbonus) * wismult * spellLevel).ToString());
        return Mathf.FloorToInt((float.Parse((spellrank1 * spellrank2).ToString()) * (float.Parse(basedamage.ToString()) + wisbonus)) * wismult);
    }




}
