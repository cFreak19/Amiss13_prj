﻿using UnityEngine;
using System.Collections;

public class Applied_Effect_Knockback : MonoBehaviour {
    public bool IsAlliedEffect = true;
    public float magnitude;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    void OnCollision(Collider thecollider)
    {
        if (IsAlliedEffect)
        {
            if ((thecollider.gameObject.GetComponent<Rigidbody>())&&(thecollider.gameObject.GetComponent<interactable>()))
            {
                thecollider.gameObject.GetComponent<Rigidbody>().AddForce(magnitude*(transform.position - thecollider.gameObject.transform.position));
                thecollider.gameObject.GetComponent<interactable>().GetHit(int.Parse(magnitude.ToString()));
            }
        }
    }
}
