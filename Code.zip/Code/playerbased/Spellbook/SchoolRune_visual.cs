﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class SchoolRune_visual : MonoBehaviour
{
    private Vector3 rotationVector = new Vector3(1,1,1);
    public float rotationFactor;

    void Start()
    {
        InvokeRepeating("Refactor", 10f, 10f);
    }

    void Refactor()
    {
        rotationVector = new Vector3(UnityEngine.Random.Range(0, rotationFactor), UnityEngine.Random.Range(0, rotationFactor), UnityEngine.Random.Range(0, rotationFactor));
    }

    void Update()
    {
        transform.localRotation *= Quaternion.Euler(rotationVector);
    }
}
