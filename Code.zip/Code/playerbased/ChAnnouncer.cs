﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChAnnouncer : MonoBehaviour {
    public GameObject ActChInfoObj, ChNameObj;


    public void Announce(string actChInf, string chName)
    {
        ActChInfoObj.GetComponent<Text>().text = actChInf;
        ChNameObj.GetComponent<Text>().text = chName;
        GetComponent<Animator>().SetBool("animate", true);
        GetComponent<Animator>().SetBool("animate", false);
    }
}
