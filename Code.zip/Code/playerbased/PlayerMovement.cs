﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public GameObject vertRotObj, theCamera;
    public float movementspeed, jumpforce, rotSensitivity;
    public float cameraDistanceDefault;
    private float cameraDistance;
    [SerializeField] private Animator myani;
    [SerializeField] private Rigidbody myrigb;
    public bool rotateOnStrafe, fourdirmovement;
    [SerializeField] private GameObject pivotObj;

	// Use this for initialization
    void Start()
    {
        cameraDistance = cameraDistanceDefault;
        UpdateCameraDistance();
    }

    void UpdateCameraDistance()
    {
        Vector3 curDir = Vector3.Normalize(theCamera.transform.localPosition - vertRotObj.transform.localPosition);
        theCamera.transform.localPosition = vertRotObj.transform.localPosition + curDir * cameraDistance;
    }

    // Update is called once per frame
    void Update()
    {
        RaycastHit thehit;

        vertRotObj.transform.Rotate(new Vector3(-1 * Input.GetAxis("Mouse Y") * rotSensitivity, 0, 0));
        transform.Rotate(new Vector3(0, Input.GetAxis("Mouse X") * rotSensitivity, 0));
        vertRotObj.transform.Rotate(new Vector3(-1 * Input.GetAxis("Ver2") * rotSensitivity, 0, 0));
        transform.Rotate(new Vector3(0, Input.GetAxis("Hor2") * rotSensitivity, 0));
        if (Physics.Raycast(transform.position, transform.up * -1, out thehit, 1.75F))
        {
            myani.SetBool("midair", false);
            if ((Input.GetAxis("Horizontal") != 0) || (Input.GetAxis("Vertical") != 0))
            {
                myani.SetBool("dirM", true);
            }
            else
            {
                myani.SetBool("dirM", false);
            }
            if ((Input.GetButtonDown("Jump")) && (!myani.GetBool("midair")))
            {
                GetComponent<Rigidbody>().AddRelativeForce(new Vector3(Input.GetAxis("Horizontal") * movementspeed * 500, jumpforce, Input.GetAxis("Vertical") * movementspeed * 500));
                myani.SetBool("midair", true);
            }
        }
    }
}