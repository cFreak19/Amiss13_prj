﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.Timeline;
using UnityEngine.Playables;

using A13_theCurse_GameConst;
//using Cinemachine;

public class player_stats : MonoBehaviour {//add UICtrl script in between UI interactions


    [Header("Visual Preferences")]
    [SerializeField]
    private Unlockable defaultChSkin, defaultDSkin, defaultCSkin, defaultTSkin;
    [SerializeField] private GameObject modelChild, dagChild, cBChild, tChild, CustChild;
    //[SerializeField] private GameObject stabParticles, flameParticles;
    [SerializeField] private GameObject metarigPrefab, EmptyPrefab, canvasObj, beamObj;
    public Material DefaultMat;
    public GameConstants.ActiveGameMode currentMode;
    

    [Header("Relevant Game Objects")]
    public GameObject beamselection;
    [SerializeField] public Animator myanim;
    public GUISkin myuiskin;
    public GameObject interactiveMessageObject, MusicCtrlObj, LevelUPAniObj, reincDust; //pickupRangeAnchor

    [Header("Initial Triggerables")]
    public bool initialComment;
    public PlayableDirector initialCutscene;
    public int combatantCount = 0;
    
    [Header("AudioSource")]
    public AudioClip[] FaintSoundVariations;
    public AudioClip[] GetHurtSoundVariations;
    public AudioClip ReincarnationFussle,CurMusic;

    [Header("Hidden Objects")]
    private GameObject ControllerObj;
    [SerializeField] private UICtrl UIControlObj;
    public Camera mycam;

    [Header("Stat Definers")]
    public UserProfile myActiveProfile = new UserProfile();
    public List<Applied_Effect> InEffect = new List<Applied_Effect>();
    public int StoryC = 0;

    private int maxHealthP = 4;
    private int maxWillP = 4;
    private int curXP = 0;
    public int curHealthP, curWillP;
    public float meleeRange, observeRange, detectRange, maxBeamP, curBeamP;

    private bool isDazed = false;
    private Vector3 activeBeamTarget;

    public bool BeamWaiting = false;
    public bool Beaming = false;

    public SkinSet[] activeSkinsets = new SkinSet[4];
    public GameObject plMesh1, plMesh2;

    public void AddStat(int inList, int amnt)
    {
        myActiveProfile.PlayerStats[inList].statBonus += amnt;
    }

    public void GrantUnlock(GameConstants.Unlockable type, int order)
    {
        switch (type)
        {
            case GameConstants.Unlockable.SkinSet:
                myActiveProfile.SkinUnlocks[order] = true;
                break;
            case GameConstants.Unlockable.CharSkin:
                myActiveProfile.SkinUnlocks[order] = true;
                break;
            case GameConstants.Unlockable.DagSkin:
                myActiveProfile.SkinUnlocks[order] = true;
                break;
            case GameConstants.Unlockable.CrBSkin:
                myActiveProfile.SkinUnlocks[order] = true;
                break;
            case GameConstants.Unlockable.TrchSkin:
                myActiveProfile.SkinUnlocks[order] = true;
                break;
            case GameConstants.Unlockable.Avatar:
                break;
            case GameConstants.Unlockable.JournalEntry:
                break;
        }
    }

    IEnumerator Dazed()
    {
        isDazed = true;
        myanim.SetBool("dazed", true);
        yield return new WaitForSeconds(0.5f);
        myanim.SetBool("dazed", false);
        isDazed = false;
    }

    public void GetDazed()
    {
        StartCoroutine(Dazed());
    }

    public void GainXP(int Amount)
    {
        bool leveled = false;
        myActiveProfile.AddXP(Amount, out leveled);
        if (leveled)
        {
            LevelUPAniObj.GetComponent<ParticleSystem>().Stop();
            LevelUPAniObj.GetComponent<ParticleSystem>().Play();
            CalcStats();
            MakeNoise(ReincarnationFussle);
        }
        RefreshBars();
    }

    public void AdvanceChP(bool travel)
    {
        ControllerObj.GetComponent<WayBase>().WarpNextChP(travel);
    }

    public int getDamageOp()
    {
        int algnbonus = 1 + myActiveProfile.PlayerStats[2].statAmount;
        int dmg = myActiveProfile.PlayerStats[1].statAmount + myActiveProfile.PlayerStats[1].statBonus;
        if (UnityEngine.Random.Range(0, 100) < myActiveProfile.PlayerStats[3].statAmount + myActiveProfile.PlayerStats[3].statBonus + 3)
        {
            dmg *= algnbonus;
        }
        return dmg;
    }

    public bool DetectionCheck(Vector3 enPos, float range)
    {
        float distance = Mathf.Abs(Vector3.Distance(transform.position, enPos));
        if (distance > range)
            return false;
        else
            return true;
    }

    public void RefreshSecondaryContent()
    {
        for (int a = 0; a < GetComponent<InvController>().Inventory.Count; a++)
        {
            if (a < myActiveProfile.autosave.Inventory.Count)
                myActiveProfile.autosave.Inventory[a].Set(GetComponent<InvController>().Inventory[a]);
            else
                myActiveProfile.autosave.Inventory.Add(GetComponent<InvController>().Inventory[a]);
        }
    }

    public void BackOn()
    {
        myanim.SetBool("GamePlayActive", true);
    }

    public void AnimateWyatt (int aniNo)
    {
        StartCoroutine(AnimateChoice(aniNo));
    }

    void OnParticleCollision(GameObject other)
    {
        if (other.transform.tag == "projectile")
            curHealthP--;
    }

    IEnumerator CharacterStatsInitRoute()
    {
        myActiveProfile = ControllerObj.GetComponent<UProfiler>().ActiveStats;
        transform.position = ControllerObj.GetComponent<WayBase>().GetChPos();
        Time.timeScale = 1F;
        if (initialCutscene != null)
        {
            myanim.SetBool("GamePlayActive",false);
            initialCutscene.Play();
            yield return (initialCutscene.state == PlayState.Paused);
            mycam.enabled = true;
            myanim.SetBool("initial", true);
            myanim.SetBool("GamePlayActive", true);
            MusicCtrlObj.GetComponent<AudioSource>().Play();
            if (initialComment && (myActiveProfile.autosave.LatestCheckpoint == 0))
                transform.Find("In-gameSpeechBubble").GetComponent<StorySpeech>().Comment(0);
        }
        else
        {
            myanim.SetInteger("animationNumber", 0);
            reincDust.GetComponent<ParticleSystem>().Play();
            yield return new WaitForSeconds(0.01f);
            myanim.SetBool("GamePlayActive", true);
            MusicCtrlObj.GetComponent<AudioSource>().Play();
            if (initialComment && (myActiveProfile.autosave.LatestCheckpoint == 0))
                transform.Find("In-gameSpeechBubble").GetComponent<StorySpeech>().Comment(0);
        }
        RefreshBars();
    }

    public void BattleOn()
    {
        combatantCount++;
    }
    public void BattleOff()
    {
        if (combatantCount > 0)
            combatantCount--;
    }

    public string GetHPValues()
    {
        return curHealthP.ToString() + "/" + maxHealthP.ToString();
    }
    public string GetWPValues()
    {
        return curWillP.ToString() + "/" + maxWillP.ToString();
    }
    void BaseRegen()
    {
        if (curHealthP > 0)
        {
            if (curHealthP < maxHealthP)
            {
                curHealthP += myActiveProfile.PlayerStats[0].getTotalStat() / 4 + myActiveProfile.PlayerStats[3].getTotalStat() / 8;
                if (curHealthP > maxHealthP)
                    curHealthP = maxHealthP;
            }

            if (curWillP < maxWillP)
            {
                curWillP += myActiveProfile.PlayerStats[3].getTotalStat() / 2 + myActiveProfile.PlayerStats[4].getTotalStat() / 4;
                if (curWillP > maxWillP)
                    curWillP = maxWillP;
            }

            if (curBeamP < maxBeamP)
            {
                curBeamP++;
            }
        }
        RefreshBars();
    }

    private void SetULSkin(SkinSet mySkin)
    {
        switch (mySkin.ULtype)
        {
            case GameConstants.Unlockable.CharSkin:
                plMesh1.GetComponent<SkinnedMeshRenderer>().sharedMesh = mySkin.FileMeshList[0];
                plMesh1.GetComponent<SkinnedMeshRenderer>().materials[0].mainTexture = mySkin.baseTexture;
                if (mySkin.FileMeshList.Count > 1)
                {
                    plMesh2.GetComponent<SkinnedMeshRenderer>().sharedMesh = mySkin.FileMeshList[1];
                    plMesh2.GetComponent<SkinnedMeshRenderer>().materials[0].mainTexture = mySkin.baseTexture;
                }
                break;
            case GameConstants.Unlockable.DagSkin:
                dagChild.GetComponent<MeshFilter>().mesh = mySkin.FileMeshList[0];
                dagChild.GetComponent<MeshRenderer>().materials[0].mainTexture = mySkin.baseTexture;
                break;
            case GameConstants.Unlockable.CrBSkin:
                cBChild.GetComponent<MeshFilter>().mesh = mySkin.FileMeshList[0];
                cBChild.GetComponent<MeshRenderer>().materials[0].mainTexture = mySkin.baseTexture;
                break;
            case GameConstants.Unlockable.TrchSkin:
                tChild.GetComponent<MeshFilter>().mesh = mySkin.FileMeshList[0];
                tChild.GetComponent<MeshRenderer>().materials[0].mainTexture = mySkin.baseTexture;
                break;
            default:
                break;
        }
    }

    public void Init(GameObject Contr, UserProfile Update, SkinSet[] charSkins)
    {
        myActiveProfile = Update;
        activeSkinsets = charSkins;
        SetULSkin(charSkins[0]);
        ControllerObj = Contr;
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        myActiveProfile = new UserProfile();
        myActiveProfile.SetDetails(Update.UserName, Update.AvatarNo);
        myActiveProfile.UpdateDetails(Update);
        //if (currentMode == GameConstants.ActiveGameMode.Story)
        //{
            CalcStats();
        GetComponent<InvController>().InitWeapons();
            GetComponent<InvController>().InitInventory(myActiveProfile.autosave.Inventory);
            GetComponent<RuneBase>().InitRunes(Update.autosave.RuneRanks);
        //}
        StartCoroutine(CharacterStatsInitRoute());
        InvokeRepeating("BaseRegen", 3f, 3f);
        InvokeRepeating("EffectCheck", 4f, 4f);
    }

    public void HReg(int a)
    {
        curHealthP += a;
        if (curHealthP > maxHealthP)
            curHealthP = maxHealthP;
    }
    public void WReg(int a)
    {
        curWillP += a;
        if (curWillP > maxWillP)
            curWillP = maxWillP;
    }

    void UseWeapon()
    {
        myanim.SetInteger("animationNumber", 0);
        bool critCheck = false;
        if (UnityEngine.Random.Range(0, 100) > (100 - (myActiveProfile.PlayerStats[4].statAmount + myActiveProfile.PlayerStats[4].statBonus + myActiveProfile.PlayerStats[3].statAmount + myActiveProfile.PlayerStats[3].statBonus) / 2))
        {
            critCheck = true;
        }
        GetComponent<InvController>().UseActive(myActiveProfile.PlayerStats[1].statAmount + myActiveProfile.PlayerStats[1].statBonus, critCheck);
    }

    void CalcStats()
    {
        maxHealthP = (myActiveProfile.PlayerStats[0].statAmount + myActiveProfile.PlayerStats[0].statBonus) * 4;
        maxWillP = (myActiveProfile.PlayerStats[4].statAmount + myActiveProfile.PlayerStats[4].statBonus) * 4 + (myActiveProfile.PlayerStats[3].statAmount + myActiveProfile.PlayerStats[3].statBonus);
        curHealthP = maxHealthP;
        curWillP = maxWillP;
    }

    private IEnumerator Cooloff()
    {
        yield return new WaitForSeconds(2.5F);
        myanim.SetBool("physicalAtk", false);
    }
    void EffectCheck()
    {
        if (InEffect.Count > 0)
        {
            for (int a = 0; a < InEffect.Count; a++)
            {
                if ((InEffect[a] != null) && (InEffect[a].remTurns > 0))
                {
                    switch (InEffect[a].mytype)
                    {
                        case GameConstants.EffectType.Burn:
                            GetCast(InEffect[a]);
                            break;
                        case GameConstants.EffectType.Curse:
                            myActiveProfile.PlayerStats[InEffect[a].statSlot].statBonus = -1 * InEffect[a].GetDamage() / 5;
                            break;
                        case GameConstants.EffectType.Daze:
                            GetComponent<ThirdP_ctrl>().mMult = InEffect[a].GetDamage();
                            break;
                        case GameConstants.EffectType.Modify:
                            // Regenerate, Burn willpower etc.
                            break;
                        default:
                            break;
                    }
                    InEffect[a].remTurns--;
                    if (InEffect[a].remTurns <= 0)
                        InEffect.RemoveAt(a);
                }
                else
                {
                    InEffect.RemoveAt(a);
                }
            }
            StartCoroutine(Revert());
        }
    }

    IEnumerator Revert()
    {
        yield return new WaitForSeconds(1.5f);
        for (int a = 0; a < myActiveProfile.PlayerStats.Length; a++)
        {
            myActiveProfile.PlayerStats[a].statBonus = 0;
        }
        GetComponent<ThirdP_ctrl>().mMult = 0;
    }
    private IEnumerator CooloffB()
    {
        yield return new WaitForSeconds(2F);
        BeamWaiting = true;
    }

    void ObserveMessage(string line)
    {
        interactiveMessageObject.transform.Find("MessageText").GetComponent<Text>().text = line;
        interactiveMessageObject.SetActive(true);
    }

    public void MakeNoise(AudioClip mysound)
    {
        transform.Find("In-gameSpeechBubble").GetComponent<StorySpeech>().Comment(mysound);
    }

    public void GetHurt(int attempteddamage)
    {
        curHealthP -= attempteddamage * (100 - myActiveProfile.PlayerStats[5].statAmount - myActiveProfile.PlayerStats[5].statBonus) / 100;
        Debug.Log("Player received " + (attempteddamage * (100 - myActiveProfile.PlayerStats[5].statAmount - myActiveProfile.PlayerStats[5].statBonus) / 100).ToString() + " physical damage.");
        transform.Find("In-gameSpeechBubble").GetComponent<StorySpeech>().Comment(GetHurtSoundVariations[UnityEngine.Random.Range(0, GetHurtSoundVariations.Length)]);
        RefreshBars();
    }

    public void GetCast(Applied_Effect attemptedEffect)
    {
        curHealthP -= attemptedEffect.GetDamage() * ((100 - myActiveProfile.PlayerStats[5].statAmount * 2) / 100);
        if (attemptedEffect.mytype == GameConstants.EffectType.Burn)
        {
            curWillP -= attemptedEffect.GetDamage() * ((100 - myActiveProfile.PlayerStats[5].statAmount) / 50);
            InEffect.Add(attemptedEffect);
        }
        if (curHealthP <= 0)
        {
            curHealthP = 0;
            StartCoroutine(GetKnockedOut());
        }
        if (attemptedEffect.mytype == GameConstants.EffectType.Modify)
        {
            InEffect.Add(attemptedEffect);
        }
    }
    IEnumerator GetKnockedOut() //EndSession to reload and/or return to title screen.
    {
        CancelInvoke();
        myanim.SetBool("KnockedOut", true);
        MakeNoise(FaintSoundVariations[UnityEngine.Random.Range(0, FaintSoundVariations.Length)]);
        yield return new WaitForSeconds(1f);
        ControllerObj.GetComponent<WayBase>().ReSpawn();
    }

    private void OnTriggerEnter(Collider other)
    {
        GetComponent<Rigidbody>().AddExplosionForce(3, transform.position, 2);
    }
    public void ResetTabs()
    {
        myanim.SetBool("animating", false);
        myanim.SetInteger("animationNumber", 0);
        myanim.SetBool("GamePlayActive", true);
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        GetComponent<ThirdP_ctrl>().enabled = true;
    }
    public void SpendWillP(int amount)
    {
        if (curWillP >= amount)
            curWillP -= amount;
        RefreshBars();
    }

    void RefreshBars()
    {
        if (maxBeamP > curBeamP)
            curBeamP += 0.001F;
        if ((curHealthP <= 0) && (!myanim.GetBool("KnockedOut")))
        {
            StartCoroutine(GetKnockedOut());
        } else
        {
            float hratio = 0;
            float wratio = 0;
            hratio = float.Parse(curHealthP.ToString()) / float.Parse(maxHealthP.ToString());
            wratio = float.Parse(curWillP.ToString()) / float.Parse(maxWillP.ToString());
            UIControlObj.UpdateWyattStats(hratio,wratio,myActiveProfile.Level);
        }
    }

    public void StartBeam()
    {
        Beaming = true;
        if (curBeamP > 3)
        {
            myanim.SetBool("animating", true);
            GetComponent<CapsuleCollider>().enabled = false;
            GetComponent<ThirdP_ctrl>().enabled = false;
            beamselection.GetComponent<BeamReflection>().StartBeam();
            Time.timeScale = 0.4F;
        }
    }

    public void RefreshTargetDisplay(worldObject target)
    {
        UIControlObj.UpdateTarget(target.OnGaze(),target.getHitRatio());
        if (target == null)
        {
            UIControlObj.UpdateTarget(" ", 0);
        } else
        {
            if (target.gameObject.GetComponent<interactable>())
            {
                string tName = target.gameObject.GetComponent<interactable>().GObjectName;

                UIControlObj.UpdateTarget(tName, 0);
            } else if (target.gameObject.GetComponent<automated>())
            {
                string hName = target.gameObject.GetComponent<automated>().name;
                float myratio = float.Parse(target.gameObject.GetComponent<automated>().curHP.ToString()) / float.Parse(target.gameObject.GetComponent<automated>().maxHP.ToString());
                UIControlObj.UpdateTarget(hName,myratio);
            }
            if (target.gameObject.tag == "Bright")
            {
                beamselection = target.gameObject;
            }
            
        }
    }

    void Update()
    {
       if ((Beaming)&&(Input.GetButtonDown("Jump")))
        {
            beamselection.GetComponent<BeamReflection>().EndBeam();
        }
       
        if (beamselection != null)
            beamselection.GetComponent<BeamReflection>().DrawBeamPath(beamselection.transform.position);
        
            if (myanim.GetBool("GamePlayActive"))
            {
                if (Input.GetButtonDown("Toggle Inventory"))
                {
                    myanim.SetBool("GamePlayActive", false);
                    myanim.SetBool("animating", true);
                    myanim.SetInteger("animationNumber", 1);
                UIControlObj.TriggerInventory();
                    Cursor.lockState = CursorLockMode.None;
                    Cursor.visible = true;
                }
                if (Input.GetButtonDown("Toggle Runebook"))
                {
                    myanim.SetBool("GamePlayActive", false);
                    myanim.SetBool("animating", true);
                    myanim.SetInteger("animationNumber", 1);
                UIControlObj.TriggerRuneObj();
                Cursor.lockState = CursorLockMode.None;
                    Cursor.visible = true;
                }
                if (Input.GetButtonDown("Toggle Charsheet"))
                {
                    myanim.SetBool("GamePlayActive", false);
                    myanim.SetBool("animating", true);
                    myanim.SetInteger("animationNumber", 1);
                UIControlObj.TriggerCharShObj();
                Cursor.lockState = CursorLockMode.None;
                    Cursor.visible = true;
                }
                if (Input.GetButtonDown("Fire1") && (!myanim.GetBool("animating")))
                {
                    UseWeapon();
                }
                //if (Input.GetButtonDown("Inspect"))
                //{
                //    Transform CurTarget = targetingSrc.GetComponent<targetFocus>().GetTarget();
                //    if (CurTarget != targetingSrc.transform)
                //    {
                        
                //        if (CurTarget.gameObject.GetComponent<interactable>())
                //        {
                //            CurTarget.gameObject.GetComponent<interactable>().InfPrompt();
                //        }

                //        if (CurTarget.gameObject.GetComponent<povNPC>())
                //        {
                //            CurTarget.gameObject.GetComponent<povNPC>().Engage();
                //        }
                //    }
                //}
                if (Input.GetButton("Beam"))
                    curBeamP -= 0.01F;

            if (Input.GetButtonUp("Beam") && BeamWaiting)
            {
                BeamWaiting = false;
                myanim.SetBool("animating", false);
                modelChild.SetActive(true);
                beamObj.SetActive(false);
                GetComponent<CapsuleCollider>().enabled = true;
                GetComponent<ThirdP_ctrl>().enabled = true;
                Time.timeScale = 1F;
                StartCoroutine(CooloffB());
                if (beamselection != null)
                    beamselection.GetComponent<BeamReflection>().EndBeam();
            }

            //if (Input.GetButtonDown("Pickup/Interact"))
            //{
            //        Transform CurTarget = targetingSrc.GetComponent<targetFocus>().GetTarget();
            //        if (CurTarget != targetingSrc.transform)
            //        { 
            //            if (CurTarget.gameObject.GetComponent<interactable>())
            //            {
            //                if (Vector3.Distance(targetingSrc.transform.position, CurTarget.gameObject.transform.position) < observeRange)
            //                {
            //                    if (CurTarget.gameObject.GetComponent<interactable>().animate)
            //                        StartCoroutine(AnimateChoice(2));
            //                    CurTarget.gameObject.GetComponent<interactable>().Use();
            //                }
            //                else
            //                    CurTarget.gameObject.GetComponent<interactable>().InfPrompt();
            //            }
            //            if (CurTarget.gameObject.GetComponent<povNPC>())
            //            {
            //                CurTarget.gameObject.GetComponent<povNPC>().Engage();
            //            }
            //            if (CurTarget.gameObject.GetComponent<automated>())
            //                CurTarget.gameObject.GetComponent<automated>().Interact();
                        
            //        }
            //}
        }
        else
        {
            if (Input.GetButtonDown("Toggle Inventory"))
            {
                myanim.SetBool("GamePlayActive", true);
                myanim.SetBool("animating", false);
                myanim.SetInteger("animationNumber", 0);
                UIControlObj.TriggerInventory();
                Cursor.lockState = CursorLockMode.Locked;
                Cursor.visible = false;
            }
            if (Input.GetButtonDown("Toggle Runebook"))
            {
                myanim.SetBool("GamePlayActive", true);
                myanim.SetBool("animating", false);
                myanim.SetInteger("animationNumber", 0);
                UIControlObj.TriggerRuneObj();
                Cursor.lockState = CursorLockMode.Locked;
                Cursor.visible = false;
            }
            if (Input.GetButtonDown("Toggle Charsheet"))
            {
                myanim.SetBool("GamePlayActive", true);
                myanim.SetBool("animating", false);
                myanim.SetInteger("animationNumber", 0);
                UIControlObj.TriggerCharShObj();
                Cursor.lockState = CursorLockMode.Locked;
                Cursor.visible = false;
            }
         }
            if (Input.GetButtonDown("Cancel / Pause Menu"))
            {
                if (myanim.GetBool("GamePlayActive"))
                {
                    myanim.SetBool("GamePlayActive", false);
                UIControlObj.PauseMenu();
                Cursor.lockState = CursorLockMode.None;
                    Cursor.visible = true;
                }
            }
    }

    IEnumerator AnimateChoice(int a)
    {
        myanim.SetInteger("animationNumber", a);
        myanim.SetBool("animating", true);
        yield return new WaitForSeconds(0.05f);
        myanim.SetBool("animating", false);
    }


    void OnGUI()
    {
        GUI.skin = myuiskin;
        if (myanim.GetBool("GamePlayActive"))
        {
            GUI.Label(new Rect(Screen.width / 2 - 150, Screen.height - 80, 400, 60), myActiveProfile.Experience.ToString() + " / " + myActiveProfile.GetXPReq().ToString());
        }
    }
    
}
