﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class console : MonoBehaviour {
    public GameObject displayObj, playerObj;
    private int activeComb;

	// Use this for initialization
	void Start () {
		
	}
	
    void EnterNewComb(string input)
    {

    }

	// Update is called once per frame
	void Update () {
		
	}

    void OnGUI()
    {

    }
}
