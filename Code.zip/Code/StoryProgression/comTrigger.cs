﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class comTrigger : MonoBehaviour {
    public GameObject speechObj;
    public int commentNo;

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            speechObj.GetComponent<StorySpeech>().Comment(commentNo);
            GetComponent<BoxCollider>().enabled = false;
        }
    }

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
