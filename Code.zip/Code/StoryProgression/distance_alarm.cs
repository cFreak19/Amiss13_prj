﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class distance_alarm : MonoBehaviour
{
    public int storyReq;
    public float alarmRange;
    public bool onetimeAlarm,progressStory;
    private bool alarmStarted = false;
    private GameObject thePlObj;

    void Start()
    {
        thePlObj = GameObject.Find("Player_Object");
    }
    


    void Update()
    {
        if ((Vector3.Distance(transform.position,thePlObj.transform.position)>= alarmRange)&&(thePlObj.GetComponent<player_stats>().StoryC >= storyReq))
        {
            if (((onetimeAlarm)&&(!alarmStarted))||(!onetimeAlarm))
                GetComponent<alarm_Trigger>().Eligible(true);
            if (onetimeAlarm)
                alarmStarted = true;
        } else
        {
            if (!onetimeAlarm)
                GetComponent<alarm_Trigger>().Eligible(false);
        }
    }
}
