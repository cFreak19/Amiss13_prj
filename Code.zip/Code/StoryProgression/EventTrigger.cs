﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class EventTrigger : MonoBehaviour
{
    public int EventSteps;
    public List<GameObject> TriggerObj;
    private int CurrentStep;
    public reward OnUse;

    public void Advance()
    {
        if (TriggerObj[CurrentStep].GetComponent<eventStep>())
            TriggerObj[CurrentStep].GetComponent<eventStep>().TriggerAction(new global::invitem());
        CurrentStep++;
    }
}
