﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using A13_theCurse_GameConst;
using System;

[Serializable]
public class CheckPoint_Task
{
    public string name, description;
    public int curSteps, maxSteps;
}


public class WayBase : MonoBehaviour
{
    public Resolution[] resolutions;
    public List<Act> ActsList = new List<Act>();
    public int curCh, curAct, curChP;
    public int AvailableAct, AvailableChapter;
    bool LoadingDone = true;
    public Texture2D[] myloadingimages = new Texture2D[5];
    public Texture2D loadingBarTxt, steamAvatar;
    private Texture2D mycurLoadingImage;
    public string GameEndSceneName;
    private AsyncOperation mysync;
    public CombatLog GameLog;
    //private bool isInGame;
    public GameObject TaskDisplay;
    public CheckPoint_Task currentTask;

    public SkinSet[] MySkins = new SkinSet[4];

    public bool isAPK;

    public void TaskIncrement(bool travelIsOK)
    {
        currentTask.curSteps++;
        if (currentTask.curSteps >= currentTask.maxSteps)
        {
            if (curChP >= ActsList[curAct].chapterList.Length)
                AdvanceCh();
            else
                WarpNextChP(travelIsOK);
        }
        TaskDisplay.GetComponent<Text>().text = "Task: " + currentTask.description + "| " + currentTask.curSteps.ToString() + "/" + currentTask.maxSteps.ToString();
    }

    public void AdvanceCh()
    {
        curCh++;
        curChP = 0;
        if (!isAPK)
        if (curCh >= ActsList[curAct].chapterList.Length)
        {
            curAct++;
            if (((curAct == AvailableAct) && (curCh <= AvailableChapter)) || (curAct < AvailableAct))
            {
                curCh = 0;
                if (curAct >= ActsList.Count)
                {
                    StartCoroutine(InitiateGameEnd());
                }
                else
                {
                    StartCoroutine(InitiateMap());
                }
            }
            else
            {
                StartCoroutine(BackToTitleWithSave());
            }
        }
        //    GetComponent<UProfiler>().ActiveStats.autosave.ChapterNo = curCh;
        //    GetComponent<UProfiler>().ActiveStats.autosave.ActNo = curAct;
        //GetComponent<UProfiler>().ActiveStats.autosave.LatestCheckpoint = curChP;
        GetComponent<UProfiler>().Autosave(curAct, curCh, curChP);
    }
    public void ReturnTitleScreen()
    {
        StartCoroutine(BackToTitleWithSave());
    }

    public void ConcludeSteamGame(bool LeaveLobby)
    {
         StartCoroutine(BacktoTitleWithVenture());
    }

    IEnumerator BacktoTitleWithVenture()
    {
        GetComponent<UProfiler>().Autosave(curAct, curCh, curChP);
        LoadingDone = false;
        mysync = SceneManager.LoadSceneAsync("title");
        yield return mysync;
        LoadingDone = true;
        Destroy(gameObject);
    }

    IEnumerator BackToTitleWithSave()
    {
        GetComponent<UProfiler>().Autosave(curAct, curCh, curChP);
        LoadingDone = false;
        mysync = SceneManager.LoadSceneAsync("title");
        yield return mysync;
        LoadingDone = true;

        Destroy(gameObject);
    }

    public IEnumerator InitiateGameEnd()
    {
        // Initiate the End Scene
        Cursor.lockState = CursorLockMode.Locked;
        LoadingDone = false;
        GetComponent<UProfiler>().Autosave(curAct, curCh, curChP);
        mycurLoadingImage = myloadingimages[UnityEngine.Random.Range(0, myloadingimages.Length)];
        mysync = SceneManager.LoadSceneAsync(GameEndSceneName);
        yield return mysync;
        LoadingDone = true;
        Cursor.lockState = CursorLockMode.None;
        Destroy(this.gameObject);
    }

    public void WarpNextChP(bool travel)
    {
        curChP++;
        if (curChP < ActsList[curAct].chapterList[curCh].checkPointsList.Length)
        {
            if (travel)
            {
                GameObject.Find("Player_Object").transform.position = ActsList[curAct].chapterList[curCh].checkPointsList[curChP].PlworldPos;
                GameObject.Find("Player_Object").transform.rotation = Quaternion.Euler(ActsList[curAct].chapterList[curCh].checkPointsList[curChP].PlworldRot);
            }
        }
        else
        {
            curChP = 0;
            curCh++;
            if (curCh >= ActsList[curAct].chapterList.Length)
            {
                curAct++;
                curCh = 0;
            }
            if (curAct < ActsList.Count)
                StartCoroutine(InitiateMap());
            else
                StartCoroutine(InitiateGameEnd());
        }
        GetComponent<UProfiler>().ActiveStats.autosave.LatestCheckpoint = curChP;
        if (curAct < ActsList.Count)
            GetComponent<UProfiler>().Autosave(curAct, curCh, curChP);
        currentTask = ActsList[curAct].chapterList[curCh].checkPointsList[curChP].mytask;
        if (GameObject.Find("TaskNotifier"))
            GameObject.Find("TaskNotifier").GetComponent<Text>().text = currentTask.description + " " + currentTask.curSteps.ToString() + " / " + currentTask.maxSteps.ToString();
    }

    public void WarpLastChP()
    {
        Vector3 worldPos = ActsList[curAct].chapterList[curCh].checkPointsList[curChP].PlworldPos;
        GameObject.Find("Player_Object").transform.position = new Vector3(worldPos.x, worldPos.y, worldPos.z);
        GameObject.Find("Player_Object").transform.rotation = Quaternion.Euler(ActsList[curAct].chapterList[curCh].checkPointsList[curChP].PlworldRot);
    }

    public void ReSpawn()
    {
        StartCoroutine(InitiateMap());
    }


    IEnumerator InitiateMap()
    {
        Cursor.lockState = CursorLockMode.Locked;
        mycurLoadingImage = myloadingimages[UnityEngine.Random.Range(0, myloadingimages.Length)];
        LoadingDone = false;
        mysync = SceneManager.LoadSceneAsync(ActsList[curAct].chapterList[curCh].mapName);
        yield return mysync;
        RenderSettings.skybox = ActsList[curAct].chapterList[curCh].skybox;
        currentTask = ActsList[curAct].chapterList[curCh].checkPointsList[curChP].mytask;
        if (GameObject.Find("TaskNotifier"))
        {
            GameObject.Find("TaskNotifier").GetComponent<Text>().text = currentTask.description + " " + currentTask.curSteps.ToString() + " / " + currentTask.maxSteps.ToString();
        }
        LoadingDone = true;
        GameObject.Find("Player_Object").GetComponent<player_stats>().CurMusic = ActsList[curAct].chapterList[curCh].MapMusic;
        GameObject.Find("Player_Object").GetComponent<player_stats>().Init(gameObject, GetComponent<UProfiler>().ActiveStats, MySkins);
        yield return new WaitForSeconds(1f);
        Time.timeScale = 1f;
        WarpLastChP();
        if (GameObject.Find("ChapterNameAnnouncer"))
        {
            GameObject.Find("ChapterNameAnnouncer").GetComponent<ChAnnouncer>().Announce("Act " + (curAct + 1).ToString() + "- Ch " + (curCh + 1).ToString(), ActsList[curAct].chapterList[curCh].ChName);
        }
    }

    void OnGUI()
    {
        if (mysync != null)
            if ((!mysync.isDone) || (!LoadingDone))
            {
                GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), mycurLoadingImage);
                GUI.DrawTexture(new Rect(0, Screen.height - 65, Screen.width * mysync.progress, 65), loadingBarTxt);
            }
    }

    public void UpdateChP(int a)
    {
        curChP = a;
    }

    void Update()
    {

    }

    public Vector3 GetChPos()
    {
        return ActsList[curAct].chapterList[curCh].checkPointsList[curChP].PlworldPos;
    }

    public void FreshSaveRun()
    {
        curAct = 0;
        curCh = 0;
        curChP = 0;
        StartCoroutine(InitiateMap());
    }
    void Awake()
    {
        resolutions = Screen.resolutions;
        DontDestroyOnLoad(transform.gameObject);
    }

    public void ResumeOldRun()
    {
        curCh = GetComponent<UProfiler>().ActiveStats.autosave.ChapterNo;
        curAct = GetComponent<UProfiler>().ActiveStats.autosave.ActNo;
        curChP = GetComponent<UProfiler>().ActiveStats.autosave.LatestCheckpoint;
        StartCoroutine(InitiateMap());
    }

    public void EndVenture()
    {
        StartCoroutine(EndVentureRoutine());
    }

    IEnumerator EndVentureRoutine()
    {
        LoadingDone = false;
        mysync = SceneManager.LoadSceneAsync("ConclusionScreen");
        yield return mysync;
        LoadingDone = true;
    }


}
