﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
 

public class SingleCommentTrig : MonoBehaviour {
    public AudioClip[] comment = new AudioClip[1];
    private List<AudioClip> specific = new List<AudioClip>();
    public List<string> subtitles = new List<string>();
    public int order = 0;
    public GameObject bubble;
    public bool progressing = false;
    private bool isReady = true;
    public bool SpillOnInspect, onetimeUse, unravel, spillNextProgress;
    private bool unraveled = false;
    private bool granted = false;
    public GameObject[] toDeactivate;
    public int xpRew, surplusRew;
    public bool useBubbles, useSubs;
    private string currentSubt = "";

    public GUIStyle subStyle = new GUIStyle();

	// Use this for initialization
	void Start () {
        subStyle.fontSize = 32;
        subStyle.normal.textColor = Color.white;
	}

    public void Reset()
    {
        order = 0;
    }

    public void ExternalSpCall(List<AudioClip> NPC_audio)
    {
        specific.Clear();
        specific = NPC_audio;
        if (specific.Count > 0)
        StartCoroutine(SpecificAudioList());
    }

    public void CommentRandom()
    {
        order = UnityEngine.Random.Range(0, comment.Length * 20);
        StartCoroutine(PointItOut());
    }

    public void ExternalSpCall(List<AudioClip> NPC_audio,string subt)
    {
        currentSubt = subt;
        specific.Clear();
        specific = NPC_audio;
        if (specific.Count > 0)
            StartCoroutine(SpecificAudioList());
    }
    
    IEnumerator SpecificAudioList()
    {
        progressing = false;
        for (int a = 0; a < specific.Count; a++)
        {
            bubble.GetComponent<SpriteRenderer>().enabled = true;
            bubble.GetComponent<AudioSource>().clip = specific[a];
            bubble.GetComponent<AudioSource>().Play();
            yield return new WaitForSeconds(float.Parse(specific[a].length.ToString()) * 20);
            isReady = true;
            bubble.GetComponent<SpriteRenderer>().enabled = false;
            yield return new WaitForSeconds(0.25f);
        }
        yield return new WaitForSeconds(0.1f);
        if (useSubs)
            currentSubt = "";
    }

    public bool IsDone()
    {
        if (order > comment.Length)
            return true;
        else
            return false;
    }

    public IEnumerator SpillEverythingOut() //D:
    {
        progressing = false;
        for (int a = 0; a < comment.Length; a++)
        {
            if (useSubs)
                currentSubt = subtitles[a];
            if (useBubbles)
            {
                bubble.GetComponent<AudioSource>().clip = comment[a];
                bubble.GetComponent<AudioSource>().Play();
            }
            else
            {
                GetComponent<AudioSource>().clip = comment[a];
                GetComponent<AudioSource>().Play();
            }
            yield return new WaitForSeconds(comment[a].length * 20);//(progressing && isReady);
            if (useSubs)
                currentSubt = "";
            GetComponent<AudioSource>().Stop();
        }
    }

    public IEnumerator PointItOut()
    {
        progressing = false;
        if (order < comment.Length)
        {
            if (useSubs)
                currentSubt = subtitles[order];
            if (useBubbles)
                bubble.GetComponent<SpriteRenderer>().enabled = true;
            bubble.GetComponent<AudioSource>().clip = comment[order];
            order++;
            bubble.GetComponent<AudioSource>().Play();
        }
        yield return new WaitForSeconds(comment[order].length * 20); // !GetComponent<AudioSource>().isPlaying;
        if (useBubbles)
            bubble.GetComponent<SpriteRenderer>().enabled = false;
        if (useSubs)
            currentSubt = "";
        bubble.GetComponent<AudioSource>().Stop();
    }

    public void Use()
    {
        if (SpillOnInspect)
        {
            if (onetimeUse)
            {
                GetComponent<BoxCollider>().enabled = false;

            }
            if (!granted)
            {
                granted = true;
                GameObject.Find("Player_Object").GetComponent<player_stats>().myActiveProfile.SurplusPt += surplusRew;
                GameObject.Find("Player_Object").GetComponent<player_stats>().myActiveProfile.Experience += xpRew;
            }

            if (!unraveled)
            {
                //if (unravel)
                //    GameObject.FindGameObjectWithTag("GameController").GetComponent<steamMethod>().UpAchiCount("Unravel");
                unraveled = true;
            }
            for (int a = 0; a < toDeactivate.Length; a++)
            {
                toDeactivate[a].SetActive(false);
            }
            StartCoroutine(SpillEverythingOut());
        }
    }

	// Update is called once per frame
	void Update () {
		if (progressing)
        {
            progressing = false;
            if (!spillNextProgress)
                StartCoroutine(PointItOut());
            else
            {
                spillNextProgress = false;
                StartCoroutine(SpillEverythingOut());
            }
        }
	}

    void OnGUI()
    {
        if (useSubs)
            GUI.Label(new Rect(25, Screen.height - 140, Screen.width - 50, 120), currentSubt, subStyle);
    }
}
