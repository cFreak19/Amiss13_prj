﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WayTracker : MonoBehaviour {
	private GameObject mycontrollerMain;
    public int CheckPointToWr;

	// Use this for initialization
	void Start () {
		mycontrollerMain = GameObject.FindGameObjectWithTag ("GameController");	
	}

	public void NextChP(bool warp)
	{
		mycontrollerMain.GetComponent<WayBase> ().WarpNextChP (warp);
	}

    public void SaveNextChP()
    {
        mycontrollerMain.GetComponent<WayBase>().UpdateChP(CheckPointToWr);
    }

	// Update is called once per frame
	void Update () {
		
	}
}
