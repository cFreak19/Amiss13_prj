﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
 

public enum SelectFunction {canDamage, isInstantLoss, justDisable, followWP};

public class movingPlatform : MonoBehaviour {
    public string[] eligibleTags = new string[1];
    public SelectFunction triggerFunction;
    public int AmountArgument = 0;
    public float MovementSpeed;
    public bool dealsPercentage = false;
    public GameObject[] WayPointObjs = new GameObject[1];
    public bool destroyedOnWPEnd = false;
    
    private int WPOrder = -1;
    private Vector3 nextPos = Vector3.zero;

    void OnEnable()
    {
        if (triggerFunction == SelectFunction.followWP)
        {
            if (GetComponent<Collider>())
                GetComponent<Collider>().enabled = false;
            WPOrder++;
        }
    }
 
    void SetNextMov()
    {
        if (MovementSpeed > 0)
        {
            if (WPOrder < WayPointObjs.Length - 1)
            {
                WPOrder++;
                nextPos = WayPointObjs[WPOrder].transform.position;
            } else if (WPOrder == WayPointObjs.Length)
            {
                if (destroyedOnWPEnd)
                {
                    Destroy(gameObject);
                }
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        bool isEligible = false;
        for (int a = 0; a < eligibleTags.Length; a++)
        {
            if (other.transform.gameObject.tag == eligibleTags[a])
            {
                isEligible = true;
                break;
            }
        }
        if (isEligible)
        {
            switch(triggerFunction)
            {
                case SelectFunction.canDamage:
                        if (dealsPercentage)
                        {

                        }
                        else
                        {

                        }
                    break;
                case SelectFunction.isInstantLoss:
                    GameObject.Find("gameController").GetComponent<WayBase>().ReSpawn();
                    break;
                case SelectFunction.justDisable:
                    other.transform.gameObject.SetActive(false);
                    break;
                default:
                    break;
            }
             
            }
        }

    // Update is called once per frame
    void Update () {
        if (WPOrder > -1)
        {
            if (Vector3.Distance(transform.position, nextPos) < 2)
            {
                SetNextMov();
            }
        }
	}
}
