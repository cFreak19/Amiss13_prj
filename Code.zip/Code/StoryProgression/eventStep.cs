﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using A13_theCurse_GameConst;
 

public class eventStep : MonoBehaviour
{
    public string ani;
    public bool Animate, TurnOff, EmitParticles,Spawn, ProgressStory, PlayCutscene, requireItem, requireSpecOnly, Remove, requireDistance, TaskInc;
    public List<GameObject> theObjects;
    public List<GameObject> spawnObjs;
    public List<GameObject> removeObjs;
    public GameObject targetObj;
    public int ReqStory;
    public string requiredSpecificItem;
    public GameConstants.itemSpecs requiredSpec;
    public float RequiredDistance;

    
    public void TriggerAction(invitem equipped)
    {
        bool isValid = true;
        if (requireItem)
        {
            if ((requireDistance && (Vector3.Distance(transform.position, targetObj.transform.position) < RequiredDistance)) || !requireDistance)
            {
                if (requireSpecOnly)
                {
                    if (equipped.CheckForTag(requiredSpec.ToString()))
                        isValid = true;
                    else
                        isValid = false;
                }
                else
                {
                    if (requiredSpecificItem == equipped.itemName)
                        isValid = true;
                    else
                        isValid = false;
                }
            } else
            {
                isValid = false;
            }
        }
        if (isValid)
        {
            if (GameObject.Find("Player_Object").GetComponent<player_stats>().StoryC >= ReqStory)
            {
                if (PlayCutscene)
                {
                    GetComponent<cutscene>().InitiateScene();
                }
                if (Animate)
                {
                    for (int a = 0; a < theObjects.Count; a++)
                        theObjects[a].GetComponent<Animator>().SetBool(ani, true);
                }
                if (TurnOff)
                {
                    for (int a = 0; a < theObjects.Count; a++)
                        theObjects[a].gameObject.SetActive(false);
                }
                if (EmitParticles)
                {
                    for (int a = 0; a < theObjects.Count; a++)
                        theObjects[a].GetComponent<ParticleSystem>().Play();
                }
                if (Spawn)
                {
                    for (int a = 0; a < spawnObjs.Count; a++)
                        Instantiate(spawnObjs[a], transform.position, Quaternion.identity);
                }
                if (Remove)
                {
                    for (int a = 0; a < removeObjs.Count; a++)
                        removeObjs[a].SetActive(false);
                }
                if (ProgressStory)
                    GameObject.Find("Player_Object").GetComponent<player_stats>().StoryC++;
                if (TaskInc)
                    GameObject.Find("gameController").GetComponent<WayBase>().TaskIncrement(true);
            }
        }
    }
}
