﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Playables; 

public class cutscene : MonoBehaviour {
    [Header("Basic Objects")]
    public GameObject PlModelObj, meshObj1;
    public PlayableDirector mycs;
    public GameObject playerObj, MainSrc, PCSpeech, CSspeech;
    public GameObject[] ToDestroy = new GameObject[0];
    public GameObject[] ToDeactivate = new GameObject[0];
    public GameObject[] ToActivate = new GameObject[0];
    public GameObject[] ToInitialize = new GameObject[0];
    public GameObject mainCanvas;

    public List<string> TriggerTag = new List<string>();

    private SkinSet[] myskins = new SkinSet[4];

    [Header("Checklist")]
    public bool DestroyWhenEnd, Notify, taskInc, CommentOnEnd, WarpAtEnd;
    public int CommentNumber;
    public bool overrideCanvas;


    public void SetModelMeshes(SkinSet mySkin)
    {
        if (meshObj1 != null)
        {
            meshObj1.GetComponent<SkinnedMeshRenderer>().sharedMesh = mySkin.FileMeshList[0];
            meshObj1.GetComponent<SkinnedMeshRenderer>().materials[0].mainTexture = mySkin.baseTexture;
        }
    }

    public void InitiateScene()
    {
            if (overrideCanvas)
            {
                mainCanvas.GetComponent<Canvas>().enabled = false;
            }
            if (playerObj != null)
            {
                myskins = playerObj.GetComponent<player_stats>().activeSkinsets;
                SetModelMeshes(myskins[0]);
            }
            playerObj.GetComponent<player_stats>().myanim.SetBool("GamePlayActive", false);
        StartCoroutine(PlayScene());
    }

    IEnumerator PlayScene()
    {
        GetComponent<PlayableDirector>().Play();
        yield return GetComponent<PlayableDirector>().state == PlayState.Paused;
        Resolve();
    }


    void Update () {
	if (Input.GetButtonDown("Close Window / Next")&&(mycs.state == PlayState.Playing))
        {
            StopCoroutine(PlayScene());
            CancelInvoke();
            mycs.Stop();
			playerObj.SetActive(true);
			Resolve();
            playerObj.GetComponent<player_stats>().myanim.SetBool("GamePlayActive", true);
        }
	}

    public void Resolve()
    {
        GameObject[] TagDList;
        for (int b = 0; b < TriggerTag.Count; b++)
        {
            TagDList = GameObject.FindGameObjectsWithTag(TriggerTag[b]);
            for (int a = 0; a < TagDList.Length; a++)
            {
                TagDList[a].SetActive(!TagDList[a].activeInHierarchy);
            }
        }
        TagDList = new GameObject[1];
        if (overrideCanvas)
        {
            mainCanvas.GetComponent<Canvas>().enabled = true;
        }
        GetComponent<PlayableDirector>().Pause();
        if (taskInc)
            GameObject.Find("gameController").GetComponent<WayBase>().TaskIncrement(WarpAtEnd);
        if (CommentOnEnd)
        {
            PCSpeech.GetComponent<StorySpeech>().Comment(CommentNumber);
        }
        if (ToActivate.Length > 0)
        {
            for (int a = 0; a < ToActivate.Length; a++)
                ToActivate[a].SetActive(true);
        }
        if (ToDeactivate.Length > 0)
        {
            for (int a = 0; a < ToDeactivate.Length; a++)
                ToDeactivate[a].SetActive(false);
        }
        if (ToDestroy.Length > 0)
        {
            for (int a = 0; a < ToDestroy.Length; a++)
                Destroy(ToDestroy[a]);
        }
        if (ToInitialize.Length > 0)
        {
            for (int a = 0; a < ToInitialize.Length; a++)
            {
                if (ToInitialize[a].GetComponent<automated>())
                    ToInitialize[a].GetComponent<automated>().Init();
            }
        }
        GetComponent<PlayableDirector>().Stop();
        if (!MainSrc.activeInHierarchy)
            MainSrc.SetActive(true);
        if (DestroyWhenEnd)
        {
            Destroy(gameObject);
        }else
			enabled = false;
    }

    private void OnGUI()
    {
        if (mycs.state == PlayState.Playing)
        {
            GUI.color = Color.white;
            GUI.Label(new Rect(5, Screen.height - 40, 345, 30), "Hit the proceed button to skip cutscene.");
        }
    }

}
