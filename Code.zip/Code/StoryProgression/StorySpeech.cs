﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class StorySpeech : MonoBehaviour {
	public List<AudioClip> MapSpeechList = new List<AudioClip> ();
	public AudioSource mysrc;

	// Use this for initialization
	void Start () {
		mysrc = GetComponent<AudioSource> ();
	}

    public void RandComm()
    {
        mysrc.clip = MapSpeechList[UnityEngine.Random.Range(0,MapSpeechList.Count)];
        StartCoroutine(Speak());
    }

    public void Comment(AudioClip Ext)
    {
        mysrc.clip = Ext;
        StartCoroutine(Speak());
    }

	public void Comment(int order)
	{
		mysrc.clip = MapSpeechList[order];
		StartCoroutine (Speak ());
	}

	IEnumerator Speak()
	{
		mysrc.Play ();
		GetComponent<SpriteRenderer> ().enabled = true;
		yield return !mysrc.isPlaying;
		GetComponent<SpriteRenderer>().enabled = false;
	}

	// Update is called once per frame
	void Update () {
		
	}
}
