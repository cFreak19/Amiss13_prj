﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

public class alarm_Trigger : MonoBehaviour
{
    public bool isEligible, animationTrig, objTrig, progressStory;
    public string AniTurnOn;
    public List<GameObject> TriggerEventObjs;


     public void Eligible(bool b)
    {
        isEligible = b;
    }

    public void Activated()
    {
        if (animationTrig)
            GetComponent<Animator>().SetBool(AniTurnOn, true);
        if (objTrig)
        {
            for (int a = 0; a < TriggerEventObjs.Count; a++)
            {
                if (TriggerEventObjs[a].GetComponent<eventStep>())
                    TriggerEventObjs[a].GetComponent<eventStep>().TriggerAction(new global::invitem());
            }
        }
    }

    void Update()
    {
        if (isEligible)
        {

        }
    }
}
