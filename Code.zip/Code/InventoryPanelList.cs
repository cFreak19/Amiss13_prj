﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using A13_theCurse_GameConst;
 

public class InventoryPanelList : MonoBehaviour {
    public GameObject samplePrefab, ListDisplayParent, hoveredAmount, itemOnHoldDisplay, hoveredName, hoveredDesc, CurrencyDisp, plPortrait, plName, heldItem;
    public Texture2D cellBG;
    public Vector2 scrollPos = Vector2.zero;
    public Vector2 displayAnchor = new Vector2(Screen.width/2 + 150, Screen.height/3);
    private List<invitem> theupdatedInventory;
    private List<Transform> InventoryButtons = new List<Transform>();
    public int cellsperrow, cellsize, cellspacing;
    private invitem Holding;

    void OnEnable()
    {
        RefreshList();
    }

    void OnDisable()
    {
        ClearList();
        Cursor.lockState = CursorLockMode.Confined;
        Cursor.visible = false;
        if (GameObject.Find("Player_Object"))
            GameObject.Find("Player_Object").GetComponent<player_stats>().myanim.SetBool("GamePlayActive", true);
    }
    
    public void ClearList()
    {
        for (int a = 0; a < InventoryButtons.Count; a++)
        {
            Destroy(InventoryButtons[a].transform.gameObject);
        }
        InventoryButtons.Clear();
    }

    public void RefreshList()
    {
        ClearList();
        plName.GetComponent<Text>().text = GameObject.Find("Player_Object").GetComponent<player_stats>().myActiveProfile.UserName;
        CurrencyDisp.GetComponent<Text>().text = GameObject.Find("Player_Object").GetComponent<player_stats>().myActiveProfile.SurplusPt.ToString();
        theupdatedInventory = GameObject.Find("Player_Object").GetComponent<InvController>().Inventory;
        if (theupdatedInventory.Count > 0)
        {
            for (int a = 0; a < theupdatedInventory.Count; a++)
            {
                GameObject newone = Instantiate(samplePrefab, Vector3.zero, Quaternion.identity, ListDisplayParent.transform) as GameObject;
                newone.GetComponent<RectTransform>().localPosition = new Vector3(0, - 72.5f * a,0);
                newone.GetComponent<invMitem>().SetValues(theupdatedInventory[a]);
                newone.GetComponent<invMitem>().orderinInv = a;
                InventoryButtons.Add(newone.transform);
            }
        }
        CurrencyDisp.GetComponent<Text>().text = GameObject.Find("Player_Object").GetComponent<player_stats>().myActiveProfile.SurplusPt.ToString();
    }

	// Use this for initialization
	void Start ()
    {
        RefreshList();
    }

    void Update ()
    {

    }
}
