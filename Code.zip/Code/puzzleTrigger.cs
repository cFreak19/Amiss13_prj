﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class puzzleTrigger : MonoBehaviour{
    public string ObjectN, ObjectD;
    public GameObject PuzzleParent, worldNotfObj;
    public int stepN = -1; //if defines a set trigger order, the correct step the trigger holds.
    public char specD = ' '; //if defines a set character, the base definition character holds.

    public bool OncePerTurn = false;
    public bool Used = false;
    public string RequiredColliderName;


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnTriggerEnter(Collider other)
    {
        if (other.transform.gameObject.name == RequiredColliderName)
        {

        }
    }

    void TriggerCollision()
    {

    }

    public void OnInspect()
    {
        GameObject.Find("Player_Object").GetComponent<player_stats>().myanim.SetBool("GamePlayActive", false);
        worldNotfObj.transform.Find("Text").gameObject.GetComponent<Text>().text = ObjectN;
        worldNotfObj.transform.Find("MessageText").gameObject.GetComponent<Text>().text = ObjectD;
        worldNotfObj.SetActive(true);
    }

    public void Use()
    {
        if ((OncePerTurn && !Used) && (!OncePerTurn))
        {
            if (stepN > -1)
                PuzzleParent.GetComponent<WorldPuzzle>().TriggerDefine(stepN);
            else
                PuzzleParent.GetComponent<WorldPuzzle>().DefineSpecific(specD);
            Used = true;
        }
    }
}
