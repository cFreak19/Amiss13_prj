﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cutsceneColTrig : MonoBehaviour {
    public GameObject cutsObj;
    public int storyReq;

    void OnCollisionEnter(Collision mycol)
    {
        if ((mycol.transform.gameObject.tag == "Player")&&(GameObject.Find("Player_Object").GetComponent<player_stats>().StoryC >= storyReq))
        {
            cutsObj.GetComponent<cutscene>().InitiateScene();
        }
    }
    void OnTriggerEnter(Collider mycol)
    {
        if ((mycol.transform.gameObject.tag == "Player") && (GameObject.Find("Player_Object").GetComponent<player_stats>().StoryC >= storyReq))
        {
            cutsObj.GetComponent<cutscene>().InitiateScene();
        }
    }
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
