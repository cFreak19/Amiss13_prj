﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
 

public class ThirdP_ctrl : MonoBehaviour {
    public Animator myanimator;
    public Rigidbody myrb;
    public float jumpP, m_GroundCheckDistance, m_OrigGroundCheckDistance;
    Vector3 m_GroundNormal;
    [Range(1f, 3f)]    [SerializeField] float m_GravityMultiplier = 2f;
    private bool IsGrounded, jump, sprinting;
    private bool isDazed = false;
    private bool isCrippled = false;
    private Vector3 m_Move, m_CamForward;
    public Transform m_Cam;
    private float m_ForwardAmount, m_TurnAmount, orgmspeedmp;
    public float m_RunCycleLegOffset = 0.2f;
    public float mSpeedAccRMultiplier, m_WalkSLimit, m_SprintSLimit;
    private float m_SpeedL;
    public float mMult = 0;
    public GameObject Dazedparticles;
    
        
    // Use this for initialization
    void Start () {
        orgmspeedmp = mSpeedAccRMultiplier;
        m_SpeedL = m_WalkSLimit;
        Cursor.lockState = CursorLockMode.Locked;
    }
	
    public void SetDaze(float a)
    {
        mMult = a;
        if (a == 0)
        {
            isDazed = false;
            Dazedparticles.SetActive(false);
        }
        else
        {
            isDazed = true;
            Dazedparticles.SetActive(true);
        }
    }

   
    
	void Update ()
    {
        float h = 0;
        float v = 0;
        if (!isDazed)
        {
            if (Input.GetButtonDown("Jump"))
                jump = true;

            if (Input.GetButtonDown("Sprint"))
            {
                sprinting = true;
                mSpeedAccRMultiplier = orgmspeedmp * 1.25f;
            }
            else if (Input.GetButtonUp("Sprint"))
            {
                sprinting = false;
                mSpeedAccRMultiplier = orgmspeedmp;
            }

        h = Input.GetAxis("Horizontal");
        v = Input.GetAxis("Vertical");
        }

        if (m_Cam != null)
        {
            m_Move = v * m_Cam.forward.normalized + h * m_Cam.right.normalized;
        }

        if ((myanimator.GetBool("GamePlayActive")) && (!myanimator.GetBool("animating")) &&(!myanimator.GetBool("KnockedOut")))
        {
            Move(m_Move, jump);
        }

        jump = false;
    }

    public void Move(Vector3 move, bool jump)
    {
        if (move.magnitude > 1f) move.Normalize();
        Vector3 move2 = transform.InverseTransformDirection(move) * (1-mMult);

        m_TurnAmount = Mathf.Atan2(move2.x, move2.z);
        RaycastHit hitInfo;

        if (Physics.Raycast(transform.position + new Vector3(0, GetComponent<CapsuleCollider>().center.y - GetComponent<CapsuleCollider>().height / 2, 0), Vector3.down, out hitInfo, m_GroundCheckDistance))
        {
                m_GroundNormal = hitInfo.normal;
                IsGrounded = true;
                myanimator.applyRootMotion = true;
        }

        move = Vector3.ProjectOnPlane(move, m_GroundNormal);
        m_ForwardAmount = Mathf.Abs(move.z);

        if (new Vector3(move.x, 0, move.z).magnitude > 0)
        {
            if (!isCrippled)
            {
                if (sprinting)
                {
                    m_SpeedL = m_SprintSLimit;
                }
                else
                {
                    m_SpeedL = m_WalkSLimit;
                }
            }
            else
                m_SpeedL = m_WalkSLimit;
        }

        move = move.normalized * orgmspeedmp;
        float turnSpeed = Mathf.Lerp(180, 360, m_ForwardAmount);
        transform.Rotate(0, m_TurnAmount * turnSpeed * Time.deltaTime, 0);
        
        if (IsGrounded &&(!myanimator.GetBool("animating"))&&(!myanimator.GetBool("KnockedOut")))
        {
            if (jump && myanimator.GetCurrentAnimatorStateInfo(0).IsName("Grounded"))
            {
                myrb.AddForce(new Vector3(move.x, jumpP * 2, move.z) * mSpeedAccRMultiplier / 4, ForceMode.Impulse);
                IsGrounded = false;
                myanimator.applyRootMotion = false;
                m_GroundCheckDistance = 0.6f;
            }
            else if ((myrb.velocity.magnitude < m_SpeedL) && !jump)
            {
                myrb.AddForce(new Vector3(move.x, 0, move.z) * mSpeedAccRMultiplier /3, ForceMode.Impulse);
                myanimator.SetFloat("Forward", myrb.velocity.magnitude);
            }
        }
        else
        {
            Vector3 extraGravityForce = (Physics.gravity * m_GravityMultiplier) - Physics.gravity;
            myrb.AddForce(extraGravityForce);
        }
        
        myanimator.SetBool("OnGround", IsGrounded);

        if (!IsGrounded)
        {
            myanimator.SetFloat("Jump", myrb.velocity.y);
        }
    }
}
