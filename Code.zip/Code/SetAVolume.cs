﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SetAVolume : MonoBehaviour {
    GameObject masterObj, playerObj;

	// Use this for initialization
	void Start () {
        masterObj = GameObject.Find("gameController");
        playerObj = GameObject.Find("Player_Object");
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
