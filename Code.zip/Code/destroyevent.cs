﻿using System.Collections;

using System.Collections.Generic;

using UnityEngine;


public class destroyevent : MonoBehaviour {


	public Vector3 LocToWarp, RotOnWarp;
    public bool warp;
    public GameObject plObj;

	// Use this for initialization
	
	void Start () {
	
	}

	



	// Update is called once per frame
	
	void Update () {
		


	}

}
