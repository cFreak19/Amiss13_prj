﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

[Serializable]
    public class stat
    {
       public string statName = "";
    public int statAmount = 0;
    public int statBonus = 0;

    public int getTotalStat()
    {
        return statAmount + statBonus;
    }
        //public stat()
        //{
        //    statName = "NONE";
        //    statAmount = 0;
        //}
        //public stat(string n, int baseamn)
        //{
        //    statName = n;
        //    statAmount = baseamn;
        //}
    }