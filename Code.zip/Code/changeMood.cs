﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System;

[Serializable]
public class ChapterMood
{
    public float fogD, sunIntensity;
    public Color fogC;
    public GameObject sunSource;
}

public class changeMood : MonoBehaviour {
    public ChapterMood[] moodsList;


    public void SetMood(int a)
    {
        RenderSettings.fogDensity = moodsList[a].fogD;
        RenderSettings.fogColor = moodsList[a].fogC;
        moodsList[a].sunSource.GetComponent<Light>().intensity = moodsList[a].sunIntensity;

    }
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
