﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class CombatLog
{
    public Dictionary<string, List<string>> SessionLog = new Dictionary<string, List<string>>();
    public List<string> CurrentSession = new List<string>();
    private string SteamUN, currentSessionKey;
    public GameObject gameCtrlObj;


    public void SaveSession()
    {
        if (SessionLog[currentSessionKey] != null)
        {
            SessionLog[currentSessionKey] = CurrentSession;
        }
        else
        {
            SessionLog.Add(currentSessionKey, CurrentSession);
        }
    }

    public void NewSession() //save last session by default
    {
        if ((CurrentSession.Count > 0)&&(currentSessionKey != null))
            SaveSession();
        currentSessionKey = DateTime.Now.ToString();
        CurrentSession = new List<string>();
    }

    public void NewSession(bool SaveLastSess)
    {
        if (SaveLastSess)
            SaveSession();
        CurrentSession = new List<string>();

    }


}

