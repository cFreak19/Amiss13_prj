﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using A13_theCurse_GameConst;
using System;

[Serializable]
public abstract class Unlockable
{
    public string ULName, ULDescription;
    public int UpdatedPrice, ReqSc;
    public bool hasScoreReq;
    public bool isUnlocked = false;
    public GameConstants.Unlockable ULtype;

    public void SetBasics(Unlockable mynew)
    {
        ULName = mynew.ULName;
        ULDescription = mynew.ULDescription;
        UpdatedPrice = mynew.UpdatedPrice;
        ReqSc = mynew.ReqSc;
        hasScoreReq = mynew.hasScoreReq;
        ULtype = mynew.ULtype;
        isUnlocked = mynew.isUnlocked;
    }
}

[Serializable]
public class UISet : Unlockable
{
    public Sprite[] RequiredSprites = new Sprite[10];
}

[Serializable]
public class SkinSet : Unlockable
{
    public List<Mesh> FileMeshList = new List<Mesh>();
    public Texture2D baseTexture;
    public Vector3 ObjPos, ObjRot, ObjScale;
    
}

public class UnlockableBase : MonoBehaviour {
    [SerializeField] private List<SkinSet> PreDefSkinULs = new List<SkinSet>();
    private List<SkinSet> WorkbenchUploads = new List<SkinSet>();
    private List<bool> UnlockedPredefSkins = new List<bool>(); 

    public SkinSet getSkin (int index)
    {
        return PreDefSkinULs[index];
    }

    public void SetSkins(List<bool> unlocks)
    {
        for (int a = 0; a <PreDefSkinULs.Count; a++)
        {
            PreDefSkinULs[a].isUnlocked = unlocks[a];
        }
    }

    public bool SkinOwned(int index)
    {
        if (index < UnlockedPredefSkins.Count)
            return UnlockedPredefSkins[index];
        else
            return false;
    }

    public int GetSkinOrder(string SkinName)
    {
        for (int a = 0; a < PreDefSkinULs.Count; a++)
        {
            if (PreDefSkinULs[a].ULName == SkinName)
            {
                return a;
            }
        }
        return -1;
    }
    
    public List<SkinSet> GetSkinList ()
    {
        return PreDefSkinULs;
    }
  

	
}
