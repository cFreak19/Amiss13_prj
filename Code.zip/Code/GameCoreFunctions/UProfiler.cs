﻿using UnityEngine;
using UnityEngine.UI;
using System;
using System.Collections.Generic;
using A13_theCurse_GameConst;

public class GameSave
{
    public int ActNo, ChapterNo, LatestCheckpoint;
    public Vector3 playerObjLocation = new Vector3();
    public DateTime saveDate = new DateTime();
    public Texture2D screenshot;
    public List<invitem> Inventory = new List<invitem>();
    public bool[] WeaponsList = new bool[3];
    public int[] RuneRanks = new int[13];

   
    public void InitialSave()
    {
        ActNo = 0;
        ChapterNo = 0;
        LatestCheckpoint = 0;
        saveDate = DateTime.Now;
        WeaponsList[0] = false;
        WeaponsList[1] = false;
        WeaponsList[2] = false;
        for (int a = 0; a < 12; a++)
        {
            RuneRanks[a] = 0;
        }
    }

    public void OverwriteSave(GameSave update)
    {
        ActNo = update.ActNo;
        ChapterNo = update.ChapterNo;
        LatestCheckpoint = update.LatestCheckpoint;
        playerObjLocation = update.playerObjLocation;
        saveDate = DateTime.Now;
        screenshot = update.screenshot;
        Inventory = update.Inventory;
        WeaponsList[0] = update.WeaponsList[0];
        WeaponsList[1] = update.WeaponsList[1];
        WeaponsList[2] = update.WeaponsList[2];
    }

}

[Serializable]
public class CheckPoint
{
    public Vector3 PlworldPos;
    public Vector3 PlworldRot;
    public string ZoneName = "tutorialLevel";
    public CheckPoint_Task mytask;
}

[Serializable]
public class Chapter
{
    public string ChName, mapName;
    public CheckPoint[] checkPointsList = new CheckPoint[4];
    public Material skybox;
    public AudioClip MapMusic;
}

[Serializable]
public class Act
{
    public string ActName;
    public Chapter[] chapterList = new Chapter[3];
}


[Serializable]
public class GameSettingPreset
{
    public int QLevel = 3;
    public Resolution myresolution;
    public bool FSOn = true;


    public void Set(GameSettingPreset thepreset)
    {
        QLevel = thepreset.QLevel;
        FSOn = thepreset.FSOn;
        myresolution = thepreset.myresolution;
    }

    public void SetRes(string MyResStr)
    {
        string value = "";
        int cursor = 0;
        while (MyResStr[cursor] != 'x')
        {
            value += MyResStr[cursor];
            cursor++;
        }
        myresolution.width = int.Parse(value);
        cursor++;
        value = "";
        while (cursor < MyResStr.Length)
        {
            value += MyResStr[cursor];
            cursor++;
        }
        myresolution.height = int.Parse(value);
    }

    public void ApplyPreset()
    {
        QualitySettings.SetQualityLevel(QLevel);
        Screen.SetResolution(myresolution.width, myresolution.height, FSOn);
    }
}

public class UserProfile
{
    public string UserName;
    public int AvatarNo = -2;
    public int Level, Experience, SurplusPt, InfluencePt;
    public GameSave autosave;
    public List<bool> SkinUnlocks = new List<bool>();
    private DateTime created, lastlogged;
    public List<GameSave> savesList = new List<GameSave>();
    public int[] RuneRanks = new int[14];
    private int GamePoints;
    public GameSettingPreset userSettings = new GameSettingPreset();
    public stat[] PlayerStats = new stat[7];

   

   
    public void PawnAllItems()
    {
        if (autosave.Inventory.Count > 0)
        {
            List<int> tobeRemoved = new List<int>();
            for (int a = 0; a < autosave.Inventory.Count; a++)
            {
                if ((!autosave.Inventory[a].isakeyitem) && (autosave.Inventory[a].iType != GameConstants.itemType.Material))
                {
                    SurplusPt += autosave.Inventory[a].sellValue;
                    tobeRemoved.Add(a);
                }
            }
            if (tobeRemoved.Count > 0)
            {
                for (int b = 0; b < tobeRemoved.Count; b++)
                {
                    autosave.Inventory.RemoveAt(tobeRemoved[b]);
                }
            }
        }
    }

    public void MakeFresh(bool isSteamBased)
    {
        Level = 0;
        Experience = 0;
        SurplusPt = 0;
        autosave.InitialSave();
        PlayerStats[0] = new stat();
        PlayerStats[0].statName = "Endurance";
        PlayerStats[0].statAmount = 8;
        PlayerStats[1] = new stat();
        PlayerStats[1].statName = "Strength";
        PlayerStats[1].statAmount = 5;
        PlayerStats[2] = new stat();
        PlayerStats[2].statName = "Alignment";
        PlayerStats[2].statAmount = 1;
        PlayerStats[3] = new stat();
        PlayerStats[3].statName = "Wisdom";
        PlayerStats[3].statAmount = 12;
        PlayerStats[4] = new stat();
        PlayerStats[4].statName = "Dexterity";
        PlayerStats[4].statAmount = 16;
        PlayerStats[5] = new stat();
        PlayerStats[5].statName = "Fortification";
        PlayerStats[5].statAmount = 10;
        PlayerStats[6] = new stat();
        PlayerStats[6].statName = "Denial";
        PlayerStats[6].statAmount = 20;
    }

    public int GetXPReq()
    {
        return (150 + Level * 15) * Level;
    }

    public void AddXP(int xpGained, out bool isLvUp) // Required Xp amount for level 'n'; (150 + n * 15)* n 
    {
        Experience += xpGained;
        int CurXPReq = (150 + Level * 15) * Level;
        if ((Experience >= CurXPReq) && (Level < 15))
        {
            Experience -= CurXPReq;
            Level++;
            PlayerStats[0].statAmount += 2;
            PlayerStats[1].statAmount += 1;
            PlayerStats[3].statAmount += 5;
            PlayerStats[4].statAmount += 3;
            isLvUp = true;
        }
        else
        {
            Debug.Log("Not enough experience to level up!");
            isLvUp = false;
        }
    }


    public void SetDetails(string na, int av)
    {
        UserName = na;
        AvatarNo = av;
        Level = 0;
        Experience = 0;
        SurplusPt = 0;
        created = DateTime.Now;
        autosave = new global::GameSave();
        PlayerStats[0] = new stat();
        PlayerStats[0].statName = "Endurance";
        PlayerStats[0].statAmount = 8;
        PlayerStats[1] = new stat();
        PlayerStats[1].statName = "Strength";
        PlayerStats[1].statAmount = 5;
        PlayerStats[2] = new stat();
        PlayerStats[2].statName = "Alignment";
        PlayerStats[2].statAmount = 1;
        PlayerStats[3] = new stat();
        PlayerStats[3].statName = "Wisdom";
        PlayerStats[3].statAmount = 12;
        PlayerStats[4] = new stat();
        PlayerStats[4].statName = "Dexterity";
        PlayerStats[4].statAmount = 16;
        PlayerStats[5] = new stat();
        PlayerStats[5].statName = "Fortification";
        PlayerStats[5].statAmount = 10;
        PlayerStats[6] = new stat();
        PlayerStats[6].statName = "Denial";
        PlayerStats[6].statAmount = 20;
    }

    public void UpdateDetails(UserProfile updated)
    {
        Level = updated.Level;
        SurplusPt = updated.SurplusPt;
        Experience = updated.Experience;
        for (int a = 0; a < updated.savesList.Count; a++)
        {
            savesList[a].OverwriteSave(updated.savesList[a]);
        }
        SkinUnlocks = updated.SkinUnlocks;
        UpdateStats(updated.PlayerStats);
    }

    public void UpdateStats(stat[] newstats)
    {
        PlayerStats[0] = new stat();
        PlayerStats[0].statAmount = newstats[0].statAmount;
        PlayerStats[1] = new stat();
        PlayerStats[1].statAmount = newstats[1].statAmount;
        PlayerStats[2] = new stat();
        PlayerStats[2].statAmount = newstats[2].statAmount;
        PlayerStats[3] = new stat();
        PlayerStats[3].statAmount = newstats[3].statAmount;
        PlayerStats[4] = new stat();
        PlayerStats[4].statAmount = newstats[4].statAmount;
        PlayerStats[5] = new stat();
        PlayerStats[5].statAmount = newstats[5].statAmount;
        PlayerStats[6] = new stat();
        PlayerStats[6].statAmount = newstats[6].statAmount;
    }

}

public abstract class ExtraContent
{
    public string ItemName, ItemCategory;
    public int ItemCost;
    public Texture2D ItemThumbnail;
}

public class ExtraSkin : ExtraContent
{
    public Texture2D Albedo, Spec, Nrm;
    public Mesh model;
    public string appliedobject;
}

public class ExtraVisual : ExtraContent
{
    public Texture2D Visual;
}

public class ExtraAudio : ExtraContent
{
    public AudioClip Audio;
}


public class UProfiler : MonoBehaviour
{
    private List<UserProfile> MyUsers = new List<UserProfile>();
    [SerializeField] private List<GameSettingPreset> SavedPresets = new List<GameSettingPreset>();
    public Texture2D GameLoadScreen;
    public int MaxLevel = 15;
    public GameSettingPreset tempSettings = new GameSettingPreset();
    public int ActiveProfileNumber = -1;
    public GameObject[] updateObjects = new GameObject[1];
    public UserProfile ActiveStats = new UserProfile();
    public bool isSaving, isLoading;
    //public GameObject autoSaveAnim;
    public Texture2D[] AvaBase;
    public bool isaCheater = false;
    private List<int> ExtraC_List = new List<int>();
    private Resolution platformRes;

    public void GainXP(int AmountGained)
    {
        bool success;
        ActiveStats.AddXP(AmountGained, out success);
    }

    public void UnlockSkin(string SkinName)
    {
        ActiveStats.SkinUnlocks[GetComponent<UnlockableBase>().GetSkinOrder(SkinName)] = true;
        WriteData();
    }

    void Start()
    {
        GameObject[] ControllerInstances = GameObject.FindGameObjectsWithTag("GameController");
        if (ControllerInstances.Length > 1)
            Destroy(this.gameObject);
    }

    
    public void LabelAsCheater()
    {
        isaCheater = true;
        WriteData();
    }

    public void RemoveUser(string Uname)
    {
        int order = -1;
        for (int a = 0; a < MyUsers.Count; a++)
        {
            if (MyUsers[a].UserName == Uname)
                order = a;
        }
        if (order > -1)
            MyUsers.RemoveAt(order);
    }

    public Texture2D getAvatar(int order)
    {
        return AvaBase[order];
    }

    public bool FirstTime()
    {
        if (MyUsers.Count > 0)
            return false;
        else
            return true;
    }

    void Awake()
    {
        platformRes = new Resolution();
        platformRes.width = 1024;
        platformRes.height = 768;
        DontDestroyOnLoad(transform.gameObject);
    }

    public void LoadProgress()
    {
        GetComponent<WayBase>().curAct = ActiveStats.autosave.ActNo;
        GetComponent<WayBase>().curCh = ActiveStats.autosave.ChapterNo;
        GetComponent<WayBase>().curChP = ActiveStats.autosave.LatestCheckpoint;
    }

    public bool CheckForUsername(string uname)
    {
        if (MyUsers.Count > 0)
        {
            for (int a = 0; a < MyUsers.Count; a++)
            {
                if (MyUsers[a].UserName == uname)
                    return true;
            }
        }
        return false;
    }

  

    
    public void NewRegularUser(int avatar, string name)
    {
        if (!CheckForUsername(name))
        {
            ActiveStats = new UserProfile();
            ActiveStats.SetDetails(name, avatar);
            ActiveStats.MakeFresh(false);
            ActiveStats.autosave.InitialSave();
            ActiveStats.userSettings.myresolution = platformRes;
            if (ActiveStats.userSettings.myresolution.width < 800)
            {
                ActiveStats.userSettings.myresolution.width = 800;
                ActiveStats.userSettings.myresolution.height = 600;
            }
            MyUsers.Add(ActiveStats);
            ActiveProfileNumber = MyUsers.Count - 1;
            WriteData();
        }
        else
        {
            Debug.Log("Username already exists, try another one.");
        }
    }

    public void LoadUser(int ui)
    {
        ActiveStats = new UserProfile();
        ActiveProfileNumber = ui;
        ActiveStats.SetDetails(MyUsers[ActiveProfileNumber].UserName, MyUsers[ActiveProfileNumber].AvatarNo);
        ActiveStats.UpdateDetails(MyUsers[ActiveProfileNumber]);
       
    }

    public void LoadUser(string un)
    {
        ActiveStats = new UserProfile();

        bool Found = false;
        for (int a = 0; a < MyUsers.Count; a++)
        {
            if (MyUsers[a].UserName == un)
            {
                ActiveProfileNumber = a;
                ActiveStats.SetDetails(MyUsers[a].UserName, MyUsers[a].AvatarNo);
                ActiveStats.UpdateDetails(MyUsers[a]);
                if (ActiveStats.userSettings.myresolution.width < 800)
                {
                    ActiveStats.userSettings.myresolution.width = 800;
                    ActiveStats.userSettings.myresolution.height = 600;
                }
                ActiveStats.userSettings.ApplyPreset();
                
                Found = true;
                break;
            }
            if (Found)
                break;
        }
    }

    public void LoadData()
    {
        isLoading = true;
        MyUsers.Clear();
        int a = 0;
        while (PlayerPrefs.HasKey("uname" + a.ToString()))
        {
            if (!PlayerPrefs.HasKey("uW1" + a.ToString()) && PlayerPrefs.HasKey("uname" + a.ToString()))
            {
                PlayerPrefs.SetString("uW0" + a.ToString(), false.ToString());
                PlayerPrefs.SetString("uW1" + a.ToString(), false.ToString());
                PlayerPrefs.SetString("uW2" + a.ToString(), false.ToString());
            }
            if (!PlayerPrefs.HasKey("uR0" + a.ToString()) && PlayerPrefs.HasKey("uname" + a.ToString()))
            {
                for (int e = 0; e < 12; e++)
                {
                    PlayerPrefs.SetInt("uR" + e.ToString() + a.ToString(), 0);
                }
                PlayerPrefs.SetInt("uR8" + a.ToString(), 1);
            }
            UserProfile NextProfile = new UserProfile();
            NextProfile.SetDetails(PlayerPrefs.GetString("uname" + a.ToString()), PlayerPrefs.GetInt("uavn" + a.ToString()));
                //NextProfile.MakeFresh(bool.Parse(PlayerPrefs.GetString("uSteam" + a.ToString())));
            NextProfile.SurplusPt = PlayerPrefs.GetInt("usurp" + a.ToString());
            NextProfile.Level = PlayerPrefs.GetInt("ulevel" + a.ToString());
            NextProfile.Experience = PlayerPrefs.GetInt("uexp" + a.ToString());
            NextProfile.AvatarNo = PlayerPrefs.GetInt("uavn" + a.ToString());
            if (PlayerPrefs.HasKey("uFS" + a.ToString()))
            {
                NextProfile.userSettings.FSOn = bool.Parse(PlayerPrefs.GetString("uFS" + a.ToString()));
                NextProfile.userSettings.myresolution.width = PlayerPrefs.GetInt("uRslW" + a.ToString());
                if (NextProfile.userSettings.myresolution.width < 800)
                    NextProfile.userSettings.myresolution.width = 800;
                NextProfile.userSettings.myresolution.height = PlayerPrefs.GetInt("uRslH" + a.ToString());
                if (NextProfile.userSettings.myresolution.height < 600)
                    NextProfile.userSettings.myresolution.height = 600;
                NextProfile.userSettings.QLevel = PlayerPrefs.GetInt("uQLv" + a.ToString());
            }
            NextProfile.autosave.WeaponsList[0] = bool.Parse(PlayerPrefs.GetString("uW0" + a.ToString()));
            NextProfile.autosave.WeaponsList[1] = bool.Parse(PlayerPrefs.GetString("uW1" + a.ToString()));
            NextProfile.autosave.WeaponsList[2] = bool.Parse(PlayerPrefs.GetString("uW2" + a.ToString()));
          
            NextProfile.SkinUnlocks.Clear();
            for (int d = 0; d < NextProfile.SkinUnlocks.Count; d++)
            {
                NextProfile.SkinUnlocks.Add(bool.Parse(PlayerPrefs.GetString("uUL" + a.ToString() + "_" + d.ToString())));
            }
            NextProfile.autosave.Inventory.Clear();
            int b = 0;
            while (PlayerPrefs.HasKey("uInv.Name" + a.ToString() + "_" + b.ToString()))
            {
                invitem nextitem = new invitem();
                nextitem.itemName = PlayerPrefs.GetString("uInv.Name" + a.ToString() + "_" + b.ToString());
                nextitem.itemDescription = PlayerPrefs.GetString("uInv.Desc" + a.ToString() + "_" + b.ToString());
                nextitem.Quantity = PlayerPrefs.GetInt("uInv.Qnt" + a.ToString() + "_" + b.ToString());
                switch (PlayerPrefs.GetString("uInv.iType" + a.ToString() + "_" + b.ToString()))
                {
                    case "Consumable":
                        nextitem.iType = GameConstants.itemType.Consumable;
                        break;
                    case "Junk":
                        nextitem.iType = GameConstants.itemType.Junk;
                        break;
                    case "Material":
                        nextitem.iType = GameConstants.itemType.Material;
                        break;
                    case "Weapon":
                        nextitem.iType = GameConstants.itemType.Weapon;
                        break;
                    case "Other":
                        nextitem.iType = GameConstants.itemType.Other;
                        break;
                    default:
                        nextitem.iType = GameConstants.itemType.Other;
                        break;
                }
                nextitem.sellValue = PlayerPrefs.GetInt("uInv.Value" + a.ToString() + "_" + b.ToString());
                nextitem.isakeyitem = bool.Parse(PlayerPrefs.GetString("uInv.isKey" + a.ToString() + "_" + b.ToString()));
                nextitem.itemRange = PlayerPrefs.GetFloat("uInv.Range" + a.ToString() + "_" + b.ToString());
                if (NextProfile.autosave.Inventory[b].onInvUse.Count > 0)
                {
                    for (int c = 0; c < NextProfile.autosave.Inventory[b].onInvUse.Count; c++)
                    {
                        string rewStr = PlayerPrefs.GetString("uInv.Use.rType" + a.ToString() + "_" + b.ToString());
                        switch (rewStr)
                        {
                            case "Exp":
                                nextitem.onInvUse[c].typeofRew = GameConstants.RewardType.Exp;
                                break;
                            case "Surplus":
                                nextitem.onInvUse[c].typeofRew = GameConstants.RewardType.Surplus;
                                break;
                            case "InvItem":
                                nextitem.onInvUse[c].typeofRew = GameConstants.RewardType.InvItem;
                                break;
                            case "WeaponUnlock":
                                nextitem.onInvUse[c].typeofRew = GameConstants.RewardType.WeaponUnlock;
                                break;
                            case "RuneRank":
                                nextitem.onInvUse[c].typeofRew = GameConstants.RewardType.RuneRank;
                                break;
                            default:
                                break;
                        }

                        PlayerPrefs.SetInt("uInv.Use.rAmnt" + a.ToString() + "_" + b.ToString(), MyUsers[a].autosave.Inventory[b].onInvUse[c].rewardedAmntorNumber);
                    }
                }
                for (int c = 0; c < 13; c++)
                {
                    PlayerPrefs.SetInt("uR" + c.ToString() + a.ToString(), NextProfile.autosave.RuneRanks[c]);
                }
                NextProfile.autosave.Inventory.Add(nextitem);
                b++;
            }
            MyUsers.Add(NextProfile);
            a++;
        }

        isLoading = false;
    }

    public void Autosave(int ActN, int ChN, int ChPN)
    {
        if (GameObject.Find("Player_Object"))
        {
            isSaving = true;
            ActiveStats.UpdateDetails(GameObject.Find("Player_Object").GetComponent<player_stats>().myActiveProfile);
            ActiveStats.autosave.ActNo = ActN;
            ActiveStats.autosave.ChapterNo = ChN;
            ActiveStats.autosave.LatestCheckpoint = ChPN;
            int Index = -1;
            for (int a = 0; a < MyUsers.Count; a++)
            {
                if (MyUsers[a].UserName == ActiveStats.UserName)
                {
                    Index = a;
                }
            }
            MyUsers[Index].UpdateDetails(ActiveStats);
           
            PlayerPrefs.SetInt("uAct" + Index.ToString(), GetComponent<WayBase>().curAct);
            PlayerPrefs.SetInt("uChapter" + Index.ToString(), GetComponent<WayBase>().curCh);
            PlayerPrefs.SetInt("usurp" + Index.ToString(), MyUsers[Index].SurplusPt);
            PlayerPrefs.SetInt("uCheckP" + Index.ToString(), GetComponent<WayBase>().curChP);
            PlayerPrefs.SetString("uname" + Index.ToString(), MyUsers[Index].UserName);
            PlayerPrefs.SetInt("ulevel" + Index.ToString(), MyUsers[Index].Level);
            PlayerPrefs.SetInt("uexp" + Index.ToString(), MyUsers[Index].Experience);
            PlayerPrefs.SetInt("uavn" + Index.ToString(), MyUsers[Index].AvatarNo);
            PlayerPrefs.SetString("uFS" + Index.ToString(), MyUsers[Index].userSettings.FSOn.ToString());
            if (MyUsers[Index].userSettings.myresolution.width < 800)
                MyUsers[Index].userSettings.myresolution.width = 800;
            PlayerPrefs.SetInt("uRslW" + Index.ToString(), MyUsers[Index].userSettings.myresolution.width);
            if (MyUsers[Index].userSettings.myresolution.height < 600)
                MyUsers[Index].userSettings.myresolution.height = 600;
            PlayerPrefs.SetInt("uRslH" + Index.ToString(), MyUsers[Index].userSettings.myresolution.height);
            PlayerPrefs.SetInt("uQLv" + Index.ToString(), MyUsers[Index].userSettings.QLevel);
            for (int b = 0; b < MyUsers[Index].SkinUnlocks.Count; b++)
            {
                PlayerPrefs.SetString("uUL" + Index.ToString() + "_" + b.ToString(), MyUsers[Index].SkinUnlocks[b].ToString());
            }
            for (int b = 0; b < MyUsers[Index].autosave.Inventory.Count; b++)
            {
                PlayerPrefs.SetString("uInv.Name" + Index.ToString() + "_" + b.ToString(), MyUsers[Index].autosave.Inventory[b].itemName);
                PlayerPrefs.SetString("uInv.Desc" + Index.ToString() + "_" + b.ToString(), MyUsers[Index].autosave.Inventory[b].itemDescription);
                PlayerPrefs.SetInt("uInv.Qnt" + Index.ToString() + "_" + b.ToString(), MyUsers[Index].autosave.Inventory[b].Quantity);
                PlayerPrefs.SetString("uInv.iType" + Index.ToString() + "_" + b.ToString(), MyUsers[Index].autosave.Inventory[b].iType.ToString());
                PlayerPrefs.SetInt("uInv.Value" + Index.ToString() + "_" + b.ToString(), MyUsers[Index].autosave.Inventory[b].sellValue);
                PlayerPrefs.SetString("uInv.isKey" + Index.ToString() + "_" + b.ToString(), MyUsers[Index].autosave.Inventory[b].isakeyitem.ToString());
                PlayerPrefs.SetFloat("uInv.Range" + Index.ToString() + "_" + b.ToString(), MyUsers[Index].autosave.Inventory[b].itemRange);
                if (MyUsers[Index].autosave.Inventory[b].onInvUse.Count > 0)
                {
                    for (int c = 0; c < MyUsers[Index].autosave.Inventory[b].onInvUse.Count; c++)
                    {
                        PlayerPrefs.SetString("uInv.Use.rType" + Index.ToString() + "_" + b.ToString(), MyUsers[Index].autosave.Inventory[b].onInvUse[c].typeofRew.ToString());
                        PlayerPrefs.SetInt("uInv.Use.rAmnt" + Index.ToString() + "_" + b.ToString(), MyUsers[Index].autosave.Inventory[b].onInvUse[c].rewardedAmntorNumber);
                    }
                }
                for (int c = 0; c < 13; c++)
                {
                    PlayerPrefs.SetInt("uR" + c.ToString() + Index.ToString(), MyUsers[Index].autosave.RuneRanks[c]);
                }
                PlayerPrefs.SetString("uW0" + Index.ToString(), MyUsers[Index].autosave.WeaponsList[0].ToString());
                PlayerPrefs.SetString("uW1" + Index.ToString(), MyUsers[Index].autosave.WeaponsList[1].ToString());
                PlayerPrefs.SetString("uW2" + Index.ToString(), MyUsers[Index].autosave.WeaponsList[2].ToString());
            }
            isSaving = false;
        }
    }

    public void WriteData()
    {
        isSaving = true;
        for (int a = 0; a < MyUsers.Count; a++)
        {
            if (MyUsers[a].UserName == ActiveStats.UserName)
            {
                MyUsers[a].UpdateDetails(ActiveStats);
            }
        }
        for (int a = 0; a < MyUsers.Count; a++)
        {
            
            PlayerPrefs.SetString("uFS" + a.ToString(), MyUsers[a].userSettings.FSOn.ToString());
            PlayerPrefs.SetInt("uRslW" + a.ToString(), MyUsers[a].userSettings.myresolution.width);
            PlayerPrefs.SetInt("uRslH" + a.ToString(), MyUsers[a].userSettings.myresolution.height);
            PlayerPrefs.SetInt("uQLv" + a.ToString(), MyUsers[a].userSettings.QLevel);
            PlayerPrefs.SetInt("uAct" + a.ToString(), GetComponent<WayBase>().curAct);
            PlayerPrefs.SetInt("uChapter" + a.ToString(), GetComponent<WayBase>().curCh);
            PlayerPrefs.SetInt("usurp" + a.ToString(), MyUsers[a].SurplusPt);
            PlayerPrefs.SetInt("uCheckP" + a.ToString(), GetComponent<WayBase>().curChP);
            PlayerPrefs.SetString("uname" + a.ToString(), MyUsers[a].UserName);
            PlayerPrefs.SetInt("ulevel" + a.ToString(), MyUsers[a].Level);
            PlayerPrefs.SetInt("uexp" + a.ToString(), MyUsers[a].Experience);
            PlayerPrefs.SetInt("uavn" + a.ToString(), MyUsers[a].AvatarNo);
            PlayerPrefs.SetString("uFS" + a.ToString(), "true");
            PlayerPrefs.SetInt("uRslW" + a.ToString(), Screen.currentResolution.width);
            PlayerPrefs.SetInt("uRslH" + a.ToString(), Screen.currentResolution.height);
            PlayerPrefs.SetInt("uQLv" + a.ToString(), 3);
            //List<SkinSet> unlockedSkins = GetComponent<UnlockableBase>().GetSkinList();
            for (int b = 0; b < MyUsers[a].SkinUnlocks.Count; a++)
            {
                PlayerPrefs.SetString("uUL" + a.ToString() + "_" + b.ToString(), MyUsers[a].SkinUnlocks[b].ToString());
            }
            for (int b = 0; b < MyUsers[a].autosave.Inventory.Count; b++)
            {
                PlayerPrefs.SetString("uInv.Name" + a.ToString() + "_" + b.ToString(), MyUsers[a].autosave.Inventory[b].itemName);
                PlayerPrefs.SetString("uInv.Desc" + a.ToString() + "_" + b.ToString(), MyUsers[a].autosave.Inventory[b].itemDescription);
                PlayerPrefs.SetInt("uInv.Qnt" + a.ToString() + "_" + b.ToString(), MyUsers[a].autosave.Inventory[b].Quantity);
                PlayerPrefs.SetString("uInv.iType" + a.ToString() + "_" + b.ToString(), MyUsers[a].autosave.Inventory[b].iType.ToString());
                PlayerPrefs.SetInt("uInv.Value" + a.ToString() + "_" + b.ToString(), MyUsers[a].autosave.Inventory[b].sellValue);
                PlayerPrefs.SetString("uInv.isKey" + a.ToString() + "_" + b.ToString(), MyUsers[a].autosave.Inventory[b].isakeyitem.ToString());
                PlayerPrefs.SetFloat("uInv.Range" + a.ToString() + "_" + b.ToString(), MyUsers[a].autosave.Inventory[b].itemRange);
                if (MyUsers[a].autosave.Inventory[b].onInvUse.Count > 0)
                {
                    for (int c = 0; c < MyUsers[a].autosave.Inventory[b].onInvUse.Count; c++)
                    {
                        PlayerPrefs.SetString("uInv.Use.rType" + a.ToString() + "_" + b.ToString(), MyUsers[a].autosave.Inventory[b].onInvUse[c].typeofRew.ToString());
                        PlayerPrefs.SetInt("uInv.Use.rAmnt" + a.ToString() + "_" + b.ToString(), MyUsers[a].autosave.Inventory[b].onInvUse[c].rewardedAmntorNumber);
                    }
                }
                for (int c = 0; c < 13; c++)
                {
                    PlayerPrefs.SetInt("uR" + c.ToString() + a.ToString(), MyUsers[a].autosave.RuneRanks[c]);
                }
                PlayerPrefs.SetString("uW0" + a.ToString(), MyUsers[a].autosave.WeaponsList[0].ToString());
                PlayerPrefs.SetString("uW1" + a.ToString(), MyUsers[a].autosave.WeaponsList[1].ToString());
                PlayerPrefs.SetString("uW2" + a.ToString(), MyUsers[a].autosave.WeaponsList[2].ToString());
            }
        }
        PlayerPrefs.Save();
        isSaving = false;
    }

    public void DeleteProfile(string un)
    {
        int a = 0;
        for (int b = 0; b < MyUsers.Count; b++)
        {
            if (MyUsers[b].UserName == un)
            {
                a = b;
            }
        }
        isSaving = true;
        PlayerPrefs.DeleteKey("uAct" + a.ToString());
        PlayerPrefs.DeleteKey("uChapter" + a.ToString());
        PlayerPrefs.DeleteKey("usurp" + a.ToString());
        PlayerPrefs.DeleteKey("uCheckP" + a.ToString());
        PlayerPrefs.DeleteKey("uname" + a.ToString());
        PlayerPrefs.DeleteKey("ulevel" + a.ToString());
        PlayerPrefs.DeleteKey("uexp" + a.ToString());
        PlayerPrefs.DeleteKey("uavn" + a.ToString());
        PlayerPrefs.DeleteKey("ustory" + a.ToString());
        PlayerPrefs.DeleteKey("uFS" + a.ToString());
        PlayerPrefs.DeleteKey("uRslW" + a.ToString());
        PlayerPrefs.DeleteKey("uRslH" + a.ToString());
        PlayerPrefs.DeleteKey("uQLv" + a.ToString());
        for (int b = 0; b < MyUsers[a].autosave.Inventory.Count; b++)
        {
            PlayerPrefs.DeleteKey("uInv.Name" + a.ToString() + "_" + b.ToString());
            PlayerPrefs.DeleteKey("uInv.Desc" + a.ToString() + "_" + b.ToString());
            PlayerPrefs.DeleteKey("uInv.Qnt" + a.ToString() + "_" + b.ToString());
            PlayerPrefs.DeleteKey("uInv.iType" + a.ToString() + "_" + b.ToString());
            PlayerPrefs.DeleteKey("uInv.Value" + a.ToString() + "_" + b.ToString());
            PlayerPrefs.DeleteKey("uInv.isKey" + a.ToString() + "_" + b.ToString());
            PlayerPrefs.DeleteKey("uInv.Range" + a.ToString() + "_" + b.ToString());
            if (MyUsers[a].autosave.Inventory[b].onInvUse.Count > 0)
            {
                for (int c = 0; c < MyUsers[a].autosave.Inventory[b].onInvUse.Count; c++)
                {
                    PlayerPrefs.DeleteKey("uInv.Use.rType" + a.ToString() + "_" + b.ToString());
                    PlayerPrefs.DeleteKey("uInv.Use.rAmnt" + a.ToString() + "_" + b.ToString());
                }
            }
            for (int c = 0; c < 12; c++)
            {
                PlayerPrefs.DeleteKey("uR" + c.ToString() + a.ToString());
            }
            PlayerPrefs.DeleteKey("uW0" + a.ToString());
            PlayerPrefs.DeleteKey("uW1" + a.ToString());
            PlayerPrefs.DeleteKey("uW2" + a.ToString());
        }
        MyUsers.RemoveAt(a);
        PlayerPrefs.Save();
    }


    public List<string> getUserNames()
    {
        List<string> uNames = new List<string>();
        for (int a = 0; a < MyUsers.Count; a++)
            uNames.Add(MyUsers[a].UserName);
        return uNames;
    }

    public UserProfile getUserDetails(string uName)
    {
        for (int a = 0; a < MyUsers.Count; a++)
        {
            if (MyUsers[a].UserName == uName)
            {
                return MyUsers[a];
            }
        }
        return new UserProfile();
    }

    public UserProfile getActiveUserDetails()
    {
        return ActiveStats;
    }


    public void ApplySelection(GameSettingPreset latest)
    {
        if (latest.myresolution.width < 800)
        {
            latest.myresolution.width = 800;
            latest.myresolution.height = 600;
        }
        tempSettings.Set(latest);
        ActiveStats.userSettings.Set(latest);
        tempSettings.ApplyPreset();
    }


    void OnGUI()
    {
        if (isSaving)
            GUI.Label(new Rect(10, 100, 90, 24), "Saving...");
        else if (isLoading)
            GUI.Label(new Rect(10, 100, 90, 24), "Loading...");
    }
}
