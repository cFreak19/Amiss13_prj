﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine.Networking;

public class WorldValuesFalseException : Exception 
{
    private string ErrorStr, activeUserId, ListedVar;
    List<string> Vars = new List<string>();

    public WorldValuesFalseException (List<string> unmatched, string classTag, string objectName)
    {
        Vars = unmatched;
        ErrorStr = "Unidentified variable values on:" + classTag + " in object " + objectName;
        ListedVar = "::";
        for (int a = 0; a < Vars.Count; a++)
        {
            ListedVar += Vars[a].ToString() + ",";
        }
        ReportException();
    }

    void ReportException()
    {
        List<IMultipartFormSection> ReportData = new List<IMultipartFormSection>();
        ReportData.Add(new MultipartFormDataSection("gameN=A13_theC"));
        ReportData.Add(new MultipartFormDataSection("userID=" + activeUserId));
        ReportData.Add(new MultipartFormDataSection("Error=" + ErrorStr));
        ReportData.Add(new MultipartFormDataSection("FalseVars= " + ListedVar));
        UnityWebRequest SendReport = UnityWebRequest.Post("http://www.sim-plistic.com/exception-reports/", ReportData);

    }
}
namespace A13_theCurse_GameConst
{
    

    [Serializable]
    public class MapPreset
    {
        public string MapName;
        public GameConstants.OnlineMapType MapType;
        public Texture2D MapThumbnail;
        public int minWaves, maxWaves, maxPlayers, LevelReq;
        public string SceneString;
        public float TimeLimit;
        public GameConstants.MapDifficulty diffLevel;
        public int SurplusRew, XPRew;
    }

    public static class GameConstants
    {
        public enum ActiveGameMode { Story, Venture };
        public enum MapDifficulty { Casual, Regular, Hardcore };
        public enum RuneType { Outer, Inner, School, Stationary, Forbidden };
        public enum RewardType { RuneRank, InvItem, Exp, Surplus, StatBonus, ResourceRegen, WeaponUnlock, GrantCycle, TaskIncrement };
        public enum Unlockable { CGArtwork, Avatar, SkinSet, DagSkin, CrBSkin, TrchSkin, CharSkin, AniMovie, AnimationSet, JournalEntry }
        public enum SkinTarget { PlayerModel, DaggerModel, CrowbarModel, TorchModel, UserInterface, RuneSet };//public enum CreatureType { Humanoid, Reptile, Beast, Cyber, Mystical, Evolved, Undead, Unknown }; // old design
        public enum CreatureType { Humanoid, Ancient, Wild, Mystical, Unknown };
        public enum itemType { Weapon, Consumable, Junk, Material, Other };
        public enum itemSpecs { Flamable, FireSource, Bright, HRegen, WRegen, Valuable, HeavyArms, Sharp, Piercing };
        public enum EffectType { Daze, Summon, Snare, Curse, Burn, Modify }; // Modify: regenerate/degenerate
        public enum TargetingType { Area, Self, Directional, Will };
        public enum OnlineMapType { Endurance, RelicDefense, Survival, Arena, TimedVenture };
        public enum MapWinCondition { ReachFinalWave, BeatFinalEnemy, DefendRelic, SurviveTime };
        public enum ChatType { Lobby, Match, Log };
    }

}